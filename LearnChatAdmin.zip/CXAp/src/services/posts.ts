// import { 
//   collection, 
//   addDoc, 
//   getDocs, 
//   doc, 
//   updateDoc,
//   deleteDoc,
//   query,
//   orderBy,
//   where,
//   arrayUnion,
//   arrayRemove,
//   increment
// } from 'firebase/firestore';
// import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
// import { db, storage } from '../../firebase.config';
// import { Post } from '../types';

// export const createPost = async (
//   userId: string,
//   username: string,
//   content: string,
//   type: 'text' | 'image' | 'video',
//   visibility: 'public' | 'friends' | 'private',
//   mediaUri?: string
// ): Promise<Post> => {
//   let mediaUrl = undefined;

//   // Upload media if provided
//   if (mediaUri) {
//     const filename = `posts/${userId}/${Date.now()}.jpg`;
//     const storageRef = ref(storage, filename);
//     const response = await fetch(mediaUri);
//     const blob = await response.blob();
//     await uploadBytes(storageRef, blob);
//     mediaUrl = await getDownloadURL(storageRef);
//   }

//   const post: Omit<Post, 'id'> = {
//     userId,
//     username,
//     type,
//     content,
//     mediaUrl,
//     visibility,
//     likes: 0,
//     likedBy: [],
//     comments: [],
//     createdAt: new Date().toISOString()
//   };

//   const docRef = await addDoc(collection(db, 'posts'), post);

//   return { ...post, id: docRef.id };
// };

// export const getPosts = async (
//   visibility: 'public' | 'all' = 'public'
// ): Promise<Post[]> => {
//   let q;
  
//   if (visibility === 'public') {
//     q = query(
//       collection(db, 'posts'),
//       where('visibility', '==', 'public'),
//       orderBy('createdAt', 'desc')
//     );
//   } else {
//     q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
//   }

//   const querySnapshot = await getDocs(q);
//   const posts: Post[] = [];

//   querySnapshot.forEach((doc) => {
//     posts.push({ id: doc.id, ...doc.data() } as Post);
//   });

//   return posts;
// };

// export const likePost = async (
//   postId: string, 
//   userId: string
// ): Promise<void> => {
//   const postRef = doc(db, 'posts', postId);
  
//   await updateDoc(postRef, {
//     likes: increment(1),
//     likedBy: arrayUnion(userId)
//   });
// };

// export const unlikePost = async (
//   postId: string, 
//   userId: string
// ): Promise<void> => {
//   const postRef = doc(db, 'posts', postId);
  
//   await updateDoc(postRef, {
//     likes: increment(-1),
//     likedBy: arrayRemove(userId)
//   });
// };

// export const deletePost = async (postId: string): Promise<void> => {
//   await deleteDoc(doc(db, 'posts', postId));
// };




import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  arrayUnion,
  arrayRemove,
  increment,
  limit,
  Timestamp
} from 'firebase/firestore';
import { db } from '../../firebase.config';
import { Post } from '../types';

// Convert Firestore Timestamp or string to ISO string
const toISOString = (val: any): string => {
  if (!val) return new Date().toISOString();
  if (val.toDate) return val.toDate().toISOString(); // Firestore Timestamp
  if (typeof val === 'string') return val;
  return new Date().toISOString();
};

// Convert local image URI to base64 data URL
const uriToBase64 = async (uri: string): Promise<string> => {
  const response = await fetch(uri);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// Create a new post (auto-expires after 24 hours)
// Stores image as base64 in Firestore (no Firebase Storage needed)
export const createPost = async (
  userId: string,
  username: string,
  content: string,
  visibility: 'public' | 'friends' | 'private',
  profileImage?: string,
  mediaUri?: string
): Promise<Post> => {
  let mediaUrl: string | undefined;
  const postType: 'text' | 'image' = mediaUri ? 'image' : 'text';

  // Convert image to base64 and store directly in Firestore
  if (mediaUri) {
    mediaUrl = await uriToBase64(mediaUri);
  }

  const now = Timestamp.now();
  const expiresAt = Timestamp.fromMillis(now.toMillis() + 24 * 60 * 60 * 1000);

  const post: any = {
    userId,
    username,
    type: postType,
    content: content || '',
    visibility,
    likes: 0,
    likedBy: [],
    comments: [],
    expiresAt,
    createdAt: now
  };

  // Only add optional fields if they have values (Firestore rejects undefined)
  if (profileImage) post.profileImage = profileImage;
  if (mediaUrl) post.mediaUrl = mediaUrl;

  const docRef = await addDoc(collection(db, 'posts'), post);

  return {
    ...post,
    id: docRef.id,
    createdAt: now.toDate().toISOString(),
    expiresAt: expiresAt.toDate().toISOString(),
  } as Post;
};

// Delete expired posts from Firestore
const cleanupExpiredPosts = async (posts: { id: string; expiresAt?: string }[]) => {
  const now = new Date().toISOString();
  const expiredIds: string[] = [];

  for (const post of posts) {
    if (post.expiresAt && post.expiresAt < now) {
      expiredIds.push(post.id);
    }
  }

  // Delete expired posts in background
  for (const id of expiredIds) {
    try {
      await deleteDoc(doc(db, 'posts', id));
    } catch (e) {
      console.error('Failed to delete expired post:', id, e);
    }
  }

  return expiredIds;
};

// Get posts - SIMPLIFIED to avoid index issues
// When userId and friends are provided, returns public + own posts + friends' posts with 'friends' visibility
export const getPosts = async (
  visibility: 'public' | 'all' = 'public',
  userId?: string,
  friends?: string[]
): Promise<Post[]> => {
  try {
    // Fetch all posts and filter in code to avoid compound index issues
    const q = query(
      collection(db, 'posts'),
      orderBy('createdAt', 'desc'),
      limit(50)
    );

    const querySnapshot = await getDocs(q);

    const allPosts: Post[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      allPosts.push({
        id: docSnap.id,
        userId: data.userId || '',
        username: data.username || 'Unknown',
        profileImage: data.profileImage,
        type: data.type || 'text',
        content: data.content || '',
        mediaUrl: data.mediaUrl,
        visibility: data.visibility || 'public',
        likedBy: data.likedBy || [],
        likes: (data.likedBy || []).length,
        comments: data.comments || [],
        expiresAt: toISOString(data.expiresAt),
        createdAt: toISOString(data.createdAt)
      } as Post);
    });

    // Cleanup expired posts from DB and filter them out
    const now = new Date().toISOString();
    const expiredIds = await cleanupExpiredPosts(allPosts);
    let activePosts = allPosts.filter(
      p => !expiredIds.includes(p.id) && (!p.expiresAt || p.expiresAt > now)
    );

    // Filter by visibility
    if (visibility === 'public' && userId && friends) {
      const friendIds = friends || [];
      activePosts = activePosts.filter(p => {
        if (p.visibility === 'public') return true;
        if (p.userId === userId) return true; // user sees own posts
        if (p.visibility === 'friends' && friendIds.includes(p.userId)) return true;
        return false;
      });
    } else if (visibility === 'public') {
      activePosts = activePosts.filter(p => p.visibility === 'public');
    }

    return activePosts;
  } catch (error) {
    console.error('Error getting posts:', error);
    return [];
  }
};

// Get user's posts
export const getUserPosts = async (userId: string): Promise<Post[]> => {
  try {
    const q = query(
      collection(db, 'posts'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    const posts: Post[] = [];

    const allPosts: Post[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      allPosts.push({
        id: docSnap.id,
        userId: data.userId,
        username: data.username,
        profileImage: data.profileImage,
        type: data.type,
        content: data.content,
        mediaUrl: data.mediaUrl,
        visibility: data.visibility,
        likedBy: data.likedBy || [],
        likes: (data.likedBy || []).length,
        comments: data.comments || [],
        expiresAt: toISOString(data.expiresAt),
        createdAt: toISOString(data.createdAt)
      } as Post);
    });

    const now = new Date().toISOString();
    const expiredIds = await cleanupExpiredPosts(allPosts);
    return allPosts.filter(
      p => !expiredIds.includes(p.id) && (!p.expiresAt || p.expiresAt > now)
    );
  } catch (error) {
    console.error('Error getting user posts:', error);
    return [];
  }
};

// Like a post
export const likePost = async (
  postId: string,
  userId: string
): Promise<void> => {
  const postRef = doc(db, 'posts', postId);

  await updateDoc(postRef, {
    likedBy: arrayUnion(userId)
  });
};

// Unlike a post
export const unlikePost = async (
  postId: string,
  userId: string
): Promise<void> => {
  const postRef = doc(db, 'posts', postId);

  await updateDoc(postRef, {
    likedBy: arrayRemove(userId)
  });
};

// Delete a post
export const deletePost = async (postId: string): Promise<void> => {
  await deleteDoc(doc(db, 'posts', postId));
};

// Add a comment to a post
export const addComment = async (
  postId: string,
  userId: string,
  username: string,
  content: string,
  profileImage?: string
): Promise<void> => {
  const postRef = doc(db, 'posts', postId);
  
  const comment = {
    id: Date.now().toString(),
    userId,
    username,
    profileImage,
    content,
    createdAt: new Date().toISOString()
  };

  await updateDoc(postRef, {
    comments: arrayUnion(comment)
  });
};