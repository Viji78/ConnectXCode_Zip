import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Alert,
  Image,
  Share,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system/legacy';
import { User, Post, Story } from '../types';
import { getPosts, likePost, unlikePost } from '../services/posts';
import { getStories } from '../services/stories';
import { getReceivedRequests } from '../services/friends';
import { getChats } from '../services/messages';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface Props {
  navigation: any;
  user: User;
}

const getTimeRemaining = (expiresAt: string): string => {
  const now = new Date().getTime();
  const expiry = new Date(expiresAt).getTime();
  const diff = expiry - now;
  if (diff <= 0) return 'Expiring soon';
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  if (hours > 0) return `${hours}h ${minutes}m remaining`;
  return `${minutes}m remaining`;
};

const getTimeAgo = (createdAt: string): string => {
  const now = new Date().getTime();
  const created = new Date(createdAt).getTime();
  const diff = now - created;
  const minutes = Math.floor(diff / (1000 * 60));
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

export default function HomeScreen({ navigation, user }: Props) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [requestCount, setRequestCount] = useState(0);
  const [messageCount, setMessageCount] = useState(0);

  const loadRequestCount = async () => {
    try {
      const requests = await getReceivedRequests(user.id);
      setRequestCount(requests.length);
    } catch {}
  };

  const loadMessageCount = async () => {
    try {
      const chats = await getChats(user.id);
      const total = chats.reduce((sum, chat) => sum + (chat.unreadCount[user.id] || 0), 0);
      setMessageCount(total);
    } catch {}
  };

  useEffect(() => {
    loadFeed();
    loadRequestCount();
    loadMessageCount();
  }, []);

  // Reload request count and message count on screen focus
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadRequestCount();
      loadMessageCount();
      loadFeed();
    });
    return unsubscribe;
  }, [navigation]);

  const loadFeed = async () => {
    try {
      const fetchedPosts = await getPosts('public', user.id, user.friends);
      setPosts(fetchedPosts);
      try {
        const fetchedStories = await getStories();
        setStories(fetchedStories);
      } catch {
        setStories([]);
      }
    } catch (error) {
      console.error('Error loading feed:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadFeed();
    setRefreshing(false);
  };

  const handleLike = async (post: Post) => {
    const isLiked = post.likedBy?.includes(user.id);
    setPosts(prev => prev.map(p => {
      if (p.id === post.id) {
        const newLikedBy = isLiked
          ? p.likedBy.filter(id => id !== user.id)
          : [...p.likedBy, user.id];
        return {
          ...p,
          likes: newLikedBy.length,
          likedBy: newLikedBy
        };
      }
      return p;
    }));
    try {
      if (isLiked) {
        await unlikePost(post.id, user.id);
      } else {
        await likePost(post.id, user.id);
      }
    } catch {
      loadFeed();
    }
  };

  const handleShare = async (post: Post) => {
    try {
      await Share.share({
        message: post.content
          ? `${post.username}: ${post.content}`
          : `Check out ${post.username}'s post on ConnectX!`,
      });
    } catch {}
  };

  const handleDownload = async (post: Post) => {
    if (!post.mediaUrl) {
      Alert.alert('Info', 'No image to download');
      return;
    }
    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please allow access to save images.');
        return;
      }
      const fileUri = FileSystem.documentDirectory + `connectx_${Date.now()}.jpg`;
      const download = await FileSystem.downloadAsync(post.mediaUrl, fileUri);
      await MediaLibrary.saveToLibraryAsync(download.uri);
      Alert.alert('Saved', 'Image saved to your gallery!');
    } catch {
      Alert.alert('Error', 'Failed to download image');
    }
  };

  const handleCreateStory = () => {
    Alert.alert('Create Story', 'Story feature coming soon.', [{ text: 'OK' }]);
  };

  const groupStoriesByUser = () => {
    const grouped: { [userId: string]: Story[] } = {};
    stories.forEach(story => {
      if (!grouped[story.userId]) grouped[story.userId] = [];
      grouped[story.userId].push(story);
    });
    return Object.values(grouped).map(s => s[0]);
  };

  const renderPost = ({ item }: { item: Post }) => {
    const isLiked = item.likedBy?.includes(user.id);

    return (
      <View style={styles.postCard}>
        {/* Header - avatar, name, time, menu */}
        <View style={styles.postHeader}>
          <View style={styles.postUserInfo}>
            {item.profileImage && item.profileImage.length > 2 ? (
              <Image source={{ uri: item.profileImage }} style={styles.avatarImage} />
            ) : (
              <View style={styles.avatarCircle}>
                <Text style={styles.avatarLetter}>
                  {item.username.charAt(0).toUpperCase()}
                </Text>
              </View>
            )}
            <View>
              <Text style={styles.postUsername}>{item.username}</Text>
              <View style={styles.postMetaRow}>
                <Text style={styles.postTime}>{getTimeAgo(item.createdAt)}</Text>
                {item.expiresAt ? (
                  <Text style={styles.expiryText}> · ⏳ {getTimeRemaining(item.expiresAt)}</Text>
                ) : null}
              </View>
            </View>
          </View>
          <TouchableOpacity>
            <Ionicons name="ellipsis-horizontal" size={20} color={colors.textMuted} />
          </TouchableOpacity>
        </View>

        {/* Image (full width like Instagram) */}
        {item.type === 'image' && item.mediaUrl && (
          <Image
            source={{ uri: item.mediaUrl }}
            style={styles.postImage}
            resizeMode="cover"
          />
        )}

        {/* Action buttons row */}
        <View style={styles.actionsRow}>
          <View style={styles.actionsLeft}>
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleLike(item)}>
              <Ionicons
                name={isLiked ? 'heart' : 'heart-outline'}
                size={26}
                color={isLiked ? '#EF4444' : colors.textDark}
              />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionBtn}>
              <Ionicons name="chatbubble-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleShare(item)}>
              <Ionicons name="paper-plane-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
          </View>
          {item.type === 'image' && item.mediaUrl && (
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleDownload(item)}>
              <Ionicons name="download-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
          )}
        </View>

        {/* Likes count */}
        {item.likes > 0 && (
          <Text style={styles.likesText}>
            {item.likes} {item.likes === 1 ? 'like' : 'likes'}
          </Text>
        )}

        {/* Caption */}
        {item.content ? (
          <View style={styles.captionRow}>
            <Text style={styles.captionUsername}>{item.username}</Text>
            <Text style={styles.captionText}> {item.content}</Text>
          </View>
        ) : null}

        {/* Comments count */}
        {item.comments.length > 0 && (
          <Text style={styles.viewComments}>
            View all {item.comments.length} comments
          </Text>
        )}
      </View>
    );
  };

  const ListHeaderComponent = () => (
    <View style={styles.storiesContainer}>
      <View style={styles.storiesScrollContainer}>
        <TouchableOpacity style={styles.addStoryCircle} onPress={handleCreateStory}>
          <View style={styles.addStoryButton}>
            <Ionicons name="add" size={28} color={colors.textWhite} />
          </View>
          <Text style={styles.storyUsername}>Your Story</Text>
        </TouchableOpacity>
        {groupStoriesByUser().map((story) => (
          <TouchableOpacity key={story.id} style={styles.storyCircle}>
            <View style={styles.storyRing}>
              <View style={styles.storyAvatar}>
                <Text style={styles.storyAvatarText}>
                  {story.username.charAt(0).toUpperCase()}
                </Text>
              </View>
            </View>
            <Text style={styles.storyUsername} numberOfLines={1}>{story.username}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={common.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={common.loadingText}>Loading feed...</Text>
      </View>
    );
  }

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>ConnectX</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Search', { openTab: 'requests' })}
          >
            <Ionicons name="notifications-outline" size={24} color={colors.textDark} />
            {requestCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{requestCount}</Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Messages')}
          >
            <Ionicons name="paper-plane-outline" size={24} color={colors.textDark} />
            {messageCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{messageCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Feed */}
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={renderPost}
        ListHeaderComponent={ListHeaderComponent}
        contentContainerStyle={styles.feedList}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
        }
        ListEmptyComponent={
          <View style={common.emptyContainer}>
            <Text style={common.emptyIcon}>📱</Text>
            <Text style={common.emptyTitle}>No posts yet</Text>
            <Text style={common.emptyText}>Be the first to share something!</Text>
            <TouchableOpacity style={common.buttonPrimary} onPress={() => navigation.navigate('CreatePost')}>
              <Text style={common.buttonPrimaryText}>Create Post</Text>
            </TouchableOpacity>
          </View>
        }
      />

      <BottomNav navigation={navigation} active="Home" />
    </View>
  );
}

const styles = StyleSheet.create({
  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
    paddingTop: 50,
  },
  logo: {
    fontSize: 26,
    fontWeight: 'bold',
    color: colors.textDark,
    fontStyle: 'italic',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 18,
  },
  headerButton: {
    padding: 4,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -6,
    backgroundColor: colors.error,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: colors.textWhite,
    fontSize: 11,
    fontWeight: 'bold',
  },

  // Stories
  storiesContainer: {
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
    paddingVertical: 10,
  },
  storiesScrollContainer: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    gap: 14,
  },
  addStoryCircle: {
    alignItems: 'center',
    width: 68,
  },
  addStoryButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  storyCircle: {
    alignItems: 'center',
    width: 68,
  },
  storyRing: {
    padding: 2,
    borderRadius: 34,
    borderWidth: 2.5,
    borderColor: '#E1306C',
    marginBottom: 4,
  },
  storyAvatar: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.bgWhite,
  },
  storyAvatarText: {
    fontSize: 22,
    fontWeight: '600',
    color: colors.textBody,
  },
  storyUsername: {
    fontSize: 11,
    color: colors.textBody,
    textAlign: 'center',
    width: 68,
  },

  // Feed
  feedList: {
    paddingBottom: 8,
  },

  // Post Card
  postCard: {
    backgroundColor: colors.bgWhite,
    marginBottom: 6,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  postUserInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  avatarImage: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 10,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  avatarLetter: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  postUsername: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textDark,
  },
  postMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  postTime: {
    fontSize: 12,
    color: colors.textPlaceholder,
  },
  expiryText: {
    fontSize: 11,
    color: colors.textPlaceholder,
  },

  // Post image - full width Instagram style
  postImage: {
    width: SCREEN_WIDTH,
    height: SCREEN_WIDTH,
    backgroundColor: colors.bgInputLight,
  },

  // Action buttons
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 6,
  },
  actionsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  actionBtn: {
    padding: 2,
  },

  // Likes
  likesText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textDark,
    paddingHorizontal: 14,
    marginBottom: 4,
  },

  // Caption
  captionRow: {
    flexDirection: 'row',
    paddingHorizontal: 14,
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  captionUsername: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textDark,
  },
  captionText: {
    fontSize: 14,
    color: colors.textBody,
    flexShrink: 1,
  },

  // Comments
  viewComments: {
    fontSize: 13,
    color: colors.textPlaceholder,
    paddingHorizontal: 14,
    paddingBottom: 10,
  },

});
