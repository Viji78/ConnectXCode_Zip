import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { User, Chat } from '../types';
import { getChats, findChat, createChat } from '../services/messages';
import { getFriends } from '../services/friends';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';

interface Props {
  navigation: any;
  user: User;
}

export default function MessagesScreen({ navigation, user }: Props) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [friends, setFriends] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [fetchedChats, fetchedFriends] = await Promise.all([
        getChats(user.id),
        getFriends(user.id),
      ]);
      setChats(fetchedChats);
      setFriends(fetchedFriends);
    } catch (error) {
      console.error('Error loading messages data:', error);
    } finally {
      setLoading(false);
    }
  }, [user.id]);

  // Reload on screen focus
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadData();
    });
    return unsubscribe;
  }, [navigation, loadData]);

  const getOtherParticipantName = (chat: Chat) => {
    const otherUserId = chat.participants.find(id => id !== user.id);
    return chat.participantNames[otherUserId || ''] || 'Unknown';
  };

  const filteredChats = chats.filter(chat =>
    getOtherParticipantName(chat).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const startChatWithFriend = async (friend: User) => {
    const existing = await findChat(user.id, friend.id);
    if (existing) {
      navigation.navigate('Chat', { chatId: existing.id, friendName: friend.username });
    } else {
      const newChat = await createChat(
        [user.id, friend.id],
        { [user.id]: user.username, [friend.id]: friend.username }
      );
      navigation.navigate('Chat', { chatId: newChat.id, friendName: friend.username });
    }
  };

  const renderChatItem = ({ item }: { item: Chat }) => {
    const otherParticipantName = getOtherParticipantName(item);
    const unread = item.unreadCount[user.id] || 0;

    return (
      <TouchableOpacity
        style={styles.chatItem}
        onPress={() => navigation.navigate('Chat', { chatId: item.id, friendName: otherParticipantName })}
      >
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {otherParticipantName.charAt(0).toUpperCase()}
          </Text>
        </View>
        <View style={styles.chatInfo}>
          <View style={styles.chatHeader}>
            <Text style={styles.chatName}>{otherParticipantName}</Text>
            <Text style={styles.chatTime}>
              {new Date(item.lastMessageTime).toLocaleDateString()}
            </Text>
          </View>
          <View style={styles.lastMessageRow}>
            <Text
              style={[styles.lastMessage, unread > 0 && styles.lastMessageUnread]}
              numberOfLines={1}
            >
              {item.lastMessage || 'Tap to start chatting'}
            </Text>
            {unread > 0 && (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadText}>{unread}</Text>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  // Friends horizontal list header for FlatList
  const ListHeaderComponent = () => (
    <>
      {/* Friends row */}
      {friends.length > 0 && (
        <View style={styles.friendsSection}>
          <Text style={styles.friendsSectionTitle}>Friends</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.friendsRow}>
            {friends.map((friend) => (
              <TouchableOpacity
                key={friend.id}
                style={styles.friendCircle}
                onPress={() => startChatWithFriend(friend)}
              >
                <View style={styles.friendAvatar}>
                  <Text style={styles.friendAvatarText}>
                    {friend.username.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <Text style={styles.friendName} numberOfLines={1}>
                  {friend.username}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      {/* Chats section label */}
      {filteredChats.length > 0 && (
        <Text style={styles.chatsSectionTitle}>Chats</Text>
      )}
    </>
  );

  if (loading) {
    return (
      <View style={common.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.headerContainer}>
        <View style={styles.headerTop}>
          <Text style={styles.headerTitle}>Messages</Text>
        </View>

        <View style={styles.searchContainer}>
          <Ionicons name="search" size={18} color={colors.textPlaceholder} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search conversations..."
            placeholderTextColor={colors.textPlaceholder}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      {/* Content */}
      {friends.length === 0 && chats.length === 0 ? (
        <View style={[common.emptyContainer, { flex: 1 }]}>
          <Ionicons name="people-outline" size={56} color={colors.textPlaceholder} />
          <Text style={common.emptyTitle}>No friends yet</Text>
          <Text style={common.emptyText}>Search and add friends to start chatting</Text>
          <TouchableOpacity style={common.buttonPrimary} onPress={() => navigation.navigate('Search')}>
            <Text style={common.buttonPrimaryText}>Find Friends</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredChats}
          keyExtractor={(item) => item.id}
          renderItem={renderChatItem}
          ListHeaderComponent={ListHeaderComponent}
          contentContainerStyle={styles.chatList}
          ListEmptyComponent={
            friends.length > 0 ? (
              <View style={styles.noChatYet}>
                <Text style={styles.noChatText}>No conversations yet. Tap a friend above to start!</Text>
              </View>
            ) : null
          }
        />
      )}

      <BottomNav navigation={navigation} active="Messages" />
    </View>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
    paddingTop: 50,
  },
  headerTop: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgInputLight,
    marginHorizontal: 16,
    marginBottom: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: colors.textDark,
  },

  // Friends horizontal section
  friendsSection: {
    backgroundColor: colors.bgWhite,
    paddingTop: 12,
    paddingBottom: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  friendsSectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textMuted,
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  friendsRow: {
    paddingHorizontal: 12,
    gap: 16,
  },
  friendCircle: {
    alignItems: 'center',
    width: 62,
  },
  friendAvatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  friendAvatarText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  friendName: {
    fontSize: 11,
    color: colors.textBody,
    textAlign: 'center',
    width: 62,
  },

  // Chats
  chatsSectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textMuted,
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 6,
  },
  chatList: {
    paddingBottom: 8,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    fontSize: 22,
    color: colors.textWhite,
    fontWeight: 'bold',
  },
  chatInfo: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  chatName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textDark,
  },
  chatTime: {
    fontSize: 12,
    color: colors.textPlaceholder,
  },
  lastMessageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  lastMessage: {
    fontSize: 14,
    color: colors.textMuted,
    flex: 1,
  },
  lastMessageUnread: {
    fontWeight: '600',
    color: colors.textDark,
  },
  unreadBadge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
    marginLeft: 8,
  },
  unreadText: {
    color: colors.textWhite,
    fontSize: 12,
    fontWeight: 'bold',
  },
  noChatYet: {
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 32,
  },
  noChatText: {
    fontSize: 14,
    color: colors.textPlaceholder,
    textAlign: 'center',
  },
});
