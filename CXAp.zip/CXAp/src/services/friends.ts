import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  updateDoc,
  query,
  where,
  arrayUnion,
  deleteDoc,
  increment,
} from 'firebase/firestore';
import { db } from '../../firebase.config';
import { User, FriendRequest } from '../types';

// Helper to map Firestore doc to User
const mapDocToUser = (docSnap: any): User => {
  const data = docSnap.data();
  return {
    id: docSnap.id,
    username: data.username || '',
    email: data.email || '',
    country: data.country || '',
    countryCode: data.countryCode || '',
    phoneNumber: data.phoneNumber || '',
    dateOfBirth: data.dateOfBirth || '',
    profileImage: data.profileImage,
    bio: data.bio,
    followers: data.followers || 0,
    following: data.following || 0,
    friends: data.friends || [],
    createdAt: data.createdAt || '',
  };
};

// Get all registered users except current user
export const getAllUsers = async (currentUserId: string): Promise<User[]> => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    console.log('Firestore users total docs:', snapshot.size, 'currentUserId:', currentUserId);
    const users: User[] = [];
    snapshot.forEach((docSnap) => {
      console.log('Found user:', docSnap.id, docSnap.data().username);
      if (docSnap.id !== currentUserId) {
        users.push(mapDocToUser(docSnap));
      }
    });
    return users;
  } catch (error) {
    console.error('Error getting all users:', error);
    return [];
  }
};

// Search users by username or email
export const searchUsers = async (searchText: string, currentUserId: string): Promise<User[]> => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    const users: User[] = [];
    const search = searchText.toLowerCase();

    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (
        docSnap.id !== currentUserId &&
        (data.username?.toLowerCase().includes(search) ||
          data.email?.toLowerCase().includes(search))
      ) {
        users.push(mapDocToUser(docSnap));
      }
    });

    return users;
  } catch (error) {
    console.error('Error searching users:', error);
    return [];
  }
};

// Send friend request
export const sendFriendRequest = async (
  fromUser: User,
  toUser: User
): Promise<void> => {
  // Check if request already exists (single where, filter in code)
  const existingSnap = await getDocs(
    query(collection(db, 'friendRequests'), where('fromUserId', '==', fromUser.id))
  );
  let alreadySent = false;
  existingSnap.forEach((d) => {
    if (d.data().toUserId === toUser.id && d.data().status === 'pending') alreadySent = true;
  });
  if (alreadySent) throw new Error('Request already sent');

  // Check reverse direction
  const reverseSnap = await getDocs(
    query(collection(db, 'friendRequests'), where('fromUserId', '==', toUser.id))
  );
  let reverseExists = false;
  reverseSnap.forEach((d) => {
    if (d.data().toUserId === fromUser.id && d.data().status === 'pending') reverseExists = true;
  });
  if (reverseExists) throw new Error('This user already sent you a request');

  // Check if already friends
  const userDoc = await getDoc(doc(db, 'users', fromUser.id));
  const userData = userDoc.data();
  if (userData?.friends?.includes(toUser.id)) throw new Error('Already friends');

  await addDoc(collection(db, 'friendRequests'), {
    fromUserId: fromUser.id,
    fromUsername: fromUser.username,
    toUserId: toUser.id,
    toUsername: toUser.username,
    status: 'pending',
    createdAt: new Date().toISOString(),
  });
};

// Get pending requests received by user (single where, filter in code to avoid index)
export const getReceivedRequests = async (userId: string): Promise<FriendRequest[]> => {
  try {
    const q = query(
      collection(db, 'friendRequests'),
      where('toUserId', '==', userId)
    );
    const snapshot = await getDocs(q);
    const requests: FriendRequest[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.status === 'pending') {
        requests.push({ id: docSnap.id, ...data } as FriendRequest);
      }
    });
    return requests;
  } catch (error) {
    console.error('Error getting requests:', error);
    return [];
  }
};

// Get sent pending requests (single where, filter in code to avoid index)
export const getSentRequests = async (userId: string): Promise<FriendRequest[]> => {
  try {
    const q = query(
      collection(db, 'friendRequests'),
      where('fromUserId', '==', userId)
    );
    const snapshot = await getDocs(q);
    const requests: FriendRequest[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.status === 'pending') {
        requests.push({ id: docSnap.id, ...data } as FriendRequest);
      }
    });
    return requests;
  } catch (error) {
    console.error('Error getting sent requests:', error);
    return [];
  }
};

// Accept friend request — updates friends list + followers/following
export const acceptFriendRequest = async (request: FriendRequest): Promise<void> => {
  // Update request status
  await updateDoc(doc(db, 'friendRequests', request.id), { status: 'accepted' });

  // Both become friends — both get +1 follower and +1 following
  await updateDoc(doc(db, 'users', request.fromUserId), {
    friends: arrayUnion(request.toUserId),
    followers: increment(1),
    following: increment(1),
  });
  await updateDoc(doc(db, 'users', request.toUserId), {
    friends: arrayUnion(request.fromUserId),
    followers: increment(1),
    following: increment(1),
  });
};

// Reject friend request
export const rejectFriendRequest = async (requestId: string): Promise<void> => {
  await deleteDoc(doc(db, 'friendRequests', requestId));
};

// Get user's friends list (full user objects)
export const getFriends = async (userId: string): Promise<User[]> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    const userData = userDoc.data();
    const friendIds: string[] = userData?.friends || [];

    if (friendIds.length === 0) return [];

    const friends: User[] = [];
    for (const fid of friendIds) {
      const friendDoc = await getDoc(doc(db, 'users', fid));
      if (friendDoc.exists()) {
        friends.push(mapDocToUser(friendDoc));
      }
    }
    return friends;
  } catch (error) {
    console.error('Error getting friends:', error);
    return [];
  }
};

// Check friendship status between two users
export const getFriendshipStatus = async (
  currentUserId: string,
  otherUserId: string
): Promise<'friends' | 'pending_sent' | 'pending_received' | 'none'> => {
  // Check if already friends
  const userDoc = await getDoc(doc(db, 'users', currentUserId));
  const userData = userDoc.data();
  if (userData?.friends?.includes(otherUserId)) return 'friends';

  // Check sent request (single where, filter in code)
  const sentSnap = await getDocs(
    query(collection(db, 'friendRequests'), where('fromUserId', '==', currentUserId))
  );
  let isSent = false;
  sentSnap.forEach((d) => {
    if (d.data().toUserId === otherUserId && d.data().status === 'pending') isSent = true;
  });
  if (isSent) return 'pending_sent';

  // Check received request
  const recvSnap = await getDocs(
    query(collection(db, 'friendRequests'), where('fromUserId', '==', otherUserId))
  );
  let isRecv = false;
  recvSnap.forEach((d) => {
    if (d.data().toUserId === currentUserId && d.data().status === 'pending') isRecv = true;
  });
  if (isRecv) return 'pending_received';

  return 'none';
};
