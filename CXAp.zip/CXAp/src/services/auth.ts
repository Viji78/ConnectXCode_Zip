import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../../firebase.config';
import { User } from '../types';

export const signUp = async (
  email: string,
  password: string,
  username: string,
  country: string,
  countryCode: string,
  phoneNumber: string,
  dateOfBirth: string
): Promise<User> => {
  // Create auth user
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  // Create user document in Firestore
  const user: User = {
    id: firebaseUser.uid,
    username,
    email,
    country,
    countryCode,
    phoneNumber,
    dateOfBirth,
    bio: 'New user on ConnectX',
    followers: 0,
    following: 0,
    friends: [],
    createdAt: new Date().toISOString()
  };

  await setDoc(doc(db, 'users', firebaseUser.uid), user);

  return user;
};

export const signIn = async (
  email: string, 
  password: string
): Promise<User> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  // Get user data from Firestore
  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
  
  if (!userDoc.exists()) {
    throw new Error('User data not found');
  }

  return userDoc.data() as User;
};

export const signOut = async (): Promise<void> => {
  await firebaseSignOut(auth);
};

export const getCurrentUser = async (
  firebaseUser: FirebaseUser
): Promise<User | null> => {
  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));

  if (!userDoc.exists()) {
    return null;
  }

  const data = userDoc.data();
  return { ...data, friends: data.friends || [] } as User;
};