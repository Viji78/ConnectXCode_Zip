import React, { useState, useEffect, useRef } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Alert } from 'react-native';
import { NavigationContainer, NavigationContainerRef } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import * as Notifications from 'expo-notifications';
import { onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { auth } from './firebase.config';
import { User } from './src/types';
import { getCurrentUser, signOut, isLoggingIn } from './src/services/auth';
import { registerForPushNotifications, savePushToken } from './src/services/notifications';

// Screens
import AuthScreen from './src/screens/AuthScreen';
import LearnScreen from './src/screens/LearnScreen';
import CourseScreen from './src/screens/CourseScreen';
import LessonScreen from './src/screens/LessonScreen';
import FeedScreen from './src/screens/FeedScreen';
import AdminCoursePdfScreen from './src/screens/AdminCoursePdfScreen';
import AddCourseScreen from './src/screens/AddCourseScreen';
import UserManagementScreen from './src/screens/UserManagementScreen';
import UserDetailScreen from './src/screens/UserDetailScreen';
import CreatePostScreen from './src/screens/CreatePostScreen';
import SearchScreen from './src/screens/SearchScreen';
import MessagesScreen from './src/screens/MessagesScreen';
import ChatScreen from './src/screens/ChatScreen';
import ProfileScreen from './src/screens/ProfileScreen';

// Admin Drawer
import AdminDrawerContent from './src/components/AdminDrawerContent';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function AdminStackScreens({ user, setUser }: { user: User; setUser: (u: User | null) => void }) {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home">
        {(props) => <LearnScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Course">
        {(props) => <CourseScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Lesson">
        {(props) => <LessonScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Feed">
        {(props) => <FeedScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="AdminPanel">
        {(props) => <AdminCoursePdfScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="AddCourse">
        {(props) => <AddCourseScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="UserManagement">
        {(props) => <UserManagementScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="UserDetail">
        {(props) => <UserDetailScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="CreatePost">
        {(props) => <CreatePostScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Search">
        {(props) => <SearchScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Messages">
        {(props) => <MessagesScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Chat">
        {(props) => <ChatScreen {...props} user={user} />}
      </Stack.Screen>
      <Stack.Screen name="Profile">
        {(props) => <ProfileScreen {...props} user={user} onLogout={() => setUser(null)} onUserUpdate={setUser} />}
      </Stack.Screen>
    </Stack.Navigator>
  );
}

function AdminDrawerNav({ user, setUser }: { user: User; setUser: (u: User | null) => void }) {
  const handleLogout = async () => {
    try {
      await signOut();
      setUser(null);
    } catch {}
  };

  return (
    <Drawer.Navigator
      screenOptions={{ headerShown: false }}
      drawerContent={(props) => (
        <AdminDrawerContent {...props} user={user} onLogout={handleLogout} />
      )}
    >
      <Drawer.Screen name="AdminMain">
        {() => <AdminStackScreens user={user} setUser={setUser} />}
      </Drawer.Screen>
    </Drawer.Navigator>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigationRef = useRef<NavigationContainerRef<any>>(null);
  const justLoggedIn = useRef(false);

  // Called from AuthScreen — sets user directly, skips onAuthStateChanged validation
  const handleAuthSuccess = (userData: User) => {
    justLoggedIn.current = true;
    setUser(userData);
    // Register push token
    registerForPushNotifications().then((token) => {
      if (token) savePushToken(userData.id, token);
    });
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Skip validation if user just logged in from AuthScreen
        if (justLoggedIn.current || isLoggingIn) {
          justLoggedIn.current = false;
          setLoading(false);
          return;
        }
        try {
          const userData = await getCurrentUser(firebaseUser);
          if (userData) {
            setUser(userData);
            const token = await registerForPushNotifications();
            if (token) {
              await savePushToken(userData.id, token);
            }
          } else {
            // Session invalid — logged in on another device
            setUser(null);
            try { await firebaseSignOut(auth); } catch {}
            Alert.alert(
              'Session Expired',
              'You have been logged out because your account was logged in on another device.',
              [{ text: 'OK' }]
            );
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Handle notification tap — navigate to correct screen
  useEffect(() => {
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const data = response.notification.request.content.data;
      if (data?.screen && navigationRef.current) {
        const params = data.params || {};
        navigationRef.current.navigate(data.screen as string, params);
      }
    });

    return () => subscription.remove();
  }, []);

  if (loading) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StatusBar style="auto" />
      <NavigationContainer ref={navigationRef}>
        {!user ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Auth">
              {(props) => <AuthScreen {...props} onAuthSuccess={handleAuthSuccess} />}
            </Stack.Screen>
          </Stack.Navigator>
        ) : user.user_role === 'Admin' ? (
          <AdminDrawerNav user={user} setUser={setUser} />
        ) : (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home">
              {(props) => <LearnScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Course">
              {(props) => <CourseScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Lesson">
              {(props) => <LessonScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Feed">
              {(props) => <FeedScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="CreatePost">
              {(props) => <CreatePostScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Search">
              {(props) => <SearchScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Messages">
              {(props) => <MessagesScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Chat">
              {(props) => <ChatScreen {...props} user={user} />}
            </Stack.Screen>
            <Stack.Screen name="Profile">
              {(props) => <ProfileScreen {...props} user={user} onLogout={() => setUser(null)} onUserUpdate={setUser} />}
            </Stack.Screen>
          </Stack.Navigator>
        )}
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}
