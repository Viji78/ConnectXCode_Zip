const { withAndroidStyles } = require('@expo/config-plugins');

module.exports = function withLightCropTheme(config) {
  return withAndroidStyles(config, (config) => {
    const styles = config.modResults;

    // Add UCrop light theme style
    const uCropTheme = {
      $: { name: 'Theme.UCrop', parent: 'Theme.AppCompat.Light.NoActionBar' },
      item: [
        { $: { name: 'colorPrimary' }, _: '#FFFFFF' },
        { $: { name: 'colorPrimaryDark' }, _: '#FFFFFF' },
        { $: { name: 'colorAccent' }, _: '#4F46E5' },
        { $: { name: 'android:statusBarColor' }, _: '#FFFFFF' },
        { $: { name: 'android:windowLightStatusBar' }, _: 'true' },
        { $: { name: 'ucrop_color_toolbar_background' }, _: '#FFFFFF' },
        { $: { name: 'ucrop_color_statusbar' }, _: '#FFFFFF' },
        { $: { name: 'ucrop_color_widget_active' }, _: '#4F46E5' },
        { $: { name: 'ucrop_color_widget' }, _: '#333333' },
        { $: { name: 'ucrop_color_widget_text' }, _: '#333333' },
      ],
    };

    // Find or create resources.style array
    if (!styles.resources) styles.resources = {};
    if (!styles.resources.style) styles.resources.style = [];

    // Remove existing UCrop theme if present
    styles.resources.style = styles.resources.style.filter(
      (s) => s?.$?.name !== 'Theme.UCrop'
    );

    styles.resources.style.push(uCropTheme);

    return config;
  });
};
