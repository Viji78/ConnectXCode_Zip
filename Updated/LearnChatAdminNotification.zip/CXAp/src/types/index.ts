// export interface User {
//   id: string;
//   username: string;
//   email: string;
//   profileImage?: string;
//   bio?: string;
//   followers: number;
//   following: number;
//   createdAt: string;
// }

// export interface Post {
//   id: string;
//   userId: string;
//   username: string;
//   profileImage?: string;
//   type: 'text' | 'image' | 'video';
//   content: string;
//   mediaUrl?: string;
//   visibility: 'public' | 'friends' | 'private';
//   likes: number;
//   likedBy: string[];
//   comments: Comment[];
//   createdAt: string;
// }

// export interface Story {
//   id: string;
//   userId: string;
//   username: string;
//   profileImage?: string;
//   mediaUrl: string;
//   expiresAt: string;
//   views: number;
//   createdAt: string;
// }

// export interface Message {
//   id: string;
//   chatId: string;
//   senderId: string;
//   content: string;
//   mediaUrl?: string;
//   createdAt: string;
//   read: boolean;
// }

// export interface Comment {
//   id: string;
//   userId: string;
//   username: string;
//   content: string;
//   createdAt: string;
// }



// User type
export interface User {
  id: string;
  username: string;
  email: string;
  country: string;
  countryCode: string;
  phoneNumber: string;
  dateOfBirth: string;
  profileImage?: string;
  bio?: string;
  followers: number;
  following: number;
  friends: string[];
  user_role: 'Admin' | 'Student';
  pushToken?: string;
  createdAt: string;
}

// Post type
export interface Post {
  id: string;
  userId: string;
  username: string;
  profileImage?: string;
  type: 'text' | 'image';
  content: string;
  mediaUrl?: string;
  visibility: 'public' | 'friends' | 'private';
  likes: number;
  expiresAt: string;
  likedBy: string[];
  comments: Comment[];
  createdAt: string;
}

// Story type
export interface Story {
  id: string;
  userId: string;
  username: string;
  profileImage?: string;
  mediaUrl: string;
  expiresAt: string;
  views: number;
  createdAt: string;
}

// Message type
export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  content: string;
  mediaUrl?: string;
  createdAt: string;
  read: boolean;
  readAt?: string;
}

// Friend request type
export interface FriendRequest {
  id: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  toUsername: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

// Chat type
export interface Chat {
  id: string;
  participants: string[];
  participantNames: { [userId: string]: string };
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: { [userId: string]: number };
  createdAt: string;
}

// Comment type
export interface Comment {
  id: string;
  userId: string;
  username: string;
  profileImage?: string;
  content: string;
  createdAt: string;
}

// Notification type
export interface Notification {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  type: 'like' | 'comment' | 'follow' | 'message';
  postId?: string;
  message: string;
  read: boolean;
  createdAt: string;
}

// Course PDF type
export interface CoursePdf {
  id: string;
  courseId: string;
  fileName: string;
  fileSize: number;
  base64Data: string;
  uploadedBy: string;
  uploadedAt: string;
}