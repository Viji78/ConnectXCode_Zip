import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Image,
  ActivityIndicator,
  Modal,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase.config';
import { User, Post } from '../types';
import { signOut } from '../services/auth';
import { getPosts, deletePost } from '../services/posts';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';

interface Props {
  navigation: any;
  user: User;
  onLogout: () => void;
  onUserUpdate: (user: User) => void;
}

export default function ProfileScreen({ navigation, user, onLogout, onUserUpdate }: Props) {
  const [myPosts, setMyPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);

  useEffect(() => {
    loadMyPosts();
  }, []);

  const handlePickProfileImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });

    if (result.canceled) return;

    try {
      setUploading(true);
      const uri = result.assets[0].uri;
      const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
      const dataUri = `data:image/jpeg;base64,${base64}`;

      await updateDoc(doc(db, 'users', user.id), { profileImage: dataUri });
      onUserUpdate({ ...user, profileImage: dataUri });
      Alert.alert('Success', 'Profile photo updated!');
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  const loadMyPosts = async () => {
    try {
      const allPosts = await getPosts('all');
      const filtered = allPosts.filter(p => p.userId === user.id);
      setMyPosts(filtered);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            await signOut();
            onLogout();
          }
        }
      ]
    );
  };

  const handleDeletePost = async (postId: string) => {
    Alert.alert(
      'Delete Post',
      'Are you sure you want to delete this post?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deletePost(postId);
              setMyPosts(myPosts.filter(p => p.id !== postId));
              Alert.alert('Success', 'Post deleted');
            } catch (error: any) {
              Alert.alert('Error', error.message);
            }
          }
        }
      ]
    );
  };

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={common.header}>
        {/* <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={common.headerBackButton}>← </Text>
        </TouchableOpacity> */}
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ padding: 4 }}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={common.headerTitle}>Profile </Text>
        <TouchableOpacity onPress={handleLogout}>
          <Text style={styles.logoutButton}>Logout </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.coverPhoto} />
          <View style={styles.profileInfo}>
            <View>
              <TouchableOpacity onPress={() => user.profileImage && user.profileImage.length > 2 && setShowImageModal(true)}>
                {uploading ? (
                  <View style={styles.avatarContainer}>
                    <ActivityIndicator size="large" color={colors.primary} />
                  </View>
                ) : user.profileImage && user.profileImage.length > 2 ? (
                  <Image source={{ uri: user.profileImage }} style={styles.avatarImage} />
                ) : (
                  <Text style={styles.avatar}>{'👤'} </Text>
                )}
              </TouchableOpacity>
              <TouchableOpacity style={styles.editIcon} onPress={handlePickProfileImage} disabled={uploading}>
                <Ionicons name="pencil" size={14} color={colors.textWhite} />
              </TouchableOpacity>
            </View>
            <Text style={styles.username}>{user.username} </Text>
            <Text style={styles.email}>{user.email} </Text>
            <Text style={styles.bio}>{user.bio} </Text>

            <View style={styles.stats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{myPosts.length} </Text>
                <Text style={styles.statLabel}>Posts </Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{user.followers} </Text>
                <Text style={styles.statLabel}>Followers </Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{user.following} </Text>
                <Text style={styles.statLabel}>Following </Text>
              </View>
            </View>

            <TouchableOpacity style={styles.editButton}>
              <Text style={styles.editButtonText}>Edit Profile </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* My Posts */}
        <View style={styles.postsSection}>
          <Text style={styles.sectionTitle}>My Posts </Text>
          {myPosts.length === 0 ? (
            <View style={styles.emptyPosts}>
              <Text style={common.emptyIcon}>📝 </Text>
              <Text style={common.emptyText}>No posts yet </Text>
              <TouchableOpacity
                style={common.buttonPrimary}
                onPress={() => navigation.navigate('CreatePost')}
              >
                <Text style={common.buttonPrimaryText}>Create First Post </Text>
              </TouchableOpacity>
            </View>
          ) : (
            myPosts.map(post => (
              <View key={post.id} style={styles.postCard}>
                <View style={styles.postHeader}>
                  <Text style={styles.postContent}>{post.content} </Text>
                  <TouchableOpacity onPress={() => handleDeletePost(post.id)}>
                    <Text style={styles.deleteIcon}>🗑️ </Text>
                  </TouchableOpacity>
                </View>
                <View style={styles.postFooter}>
                  <Text style={styles.postStat}>❤️ {post.likes} </Text>
                  <Text style={styles.postStat}>💬 {post.comments.length} </Text>
                  <Text style={styles.postVisibility}>{post.visibility} </Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>

      <BottomNav navigation={navigation} active="Profile" />

      {/* Full Profile Image Modal */}
      <Modal visible={showImageModal} transparent animationType="fade" onRequestClose={() => setShowImageModal(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowImageModal(false)}>
          <View style={styles.modalContent}>
            {user.profileImage && user.profileImage.length > 2 && (
              <Image source={{ uri: user.profileImage }} style={styles.modalImage} />
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  logoutButton: { fontSize: 14, color: colors.error, fontWeight: '600' },
  content: { flex: 1 },
  profileHeader: { backgroundColor: colors.bgWhite },
  coverPhoto: {
    height: 120,
    backgroundColor: colors.primary,
  },
  profileInfo: { alignItems: 'center', padding: 16, marginTop: -40 },
  avatar: {
    fontSize: 64,
    backgroundColor: colors.bgWhite,
    borderRadius: 50,
    padding: 10,
  },
  avatarImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.bgWhite,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.bgWhite,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  editIcon: {
    position: 'absolute' as const,
    bottom: 0,
    right: 0,
    backgroundColor: colors.primary,
    borderRadius: 14,
    width: 28,
    height: 28,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    elevation: 2,
  },
  username: { fontSize: 24, fontWeight: 'bold', marginTop: 8, color: colors.textDark },
  email: { fontSize: 14, color: colors.textMuted },
  bio: { fontSize: 14, color: colors.textBody, marginTop: 8, textAlign: 'center' },
  stats: {
    flexDirection: 'row',
    marginTop: 16,
    gap: 32,
  },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: 'bold', color: colors.textDark },
  statLabel: { fontSize: 12, color: colors.textMuted },
  editButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 8,
    borderRadius: 8,
    marginTop: 16,
  },
  editButtonText: { color: colors.textWhite, fontWeight: '600' },
  postsSection: { padding: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: colors.textDark },
  emptyPosts: { alignItems: 'center', paddingVertical: 32 },
  postCard: {
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  postHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  postContent: { flex: 1, fontSize: 14, color: colors.textBody },
  deleteIcon: { fontSize: 20 },
  postFooter: { flexDirection: 'row', gap: 16, marginTop: 12 },
  postStat: { fontSize: 12, color: colors.textMuted },
  postVisibility: { fontSize: 12, color: colors.primary, marginLeft: 'auto' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
  },
  modalContent: {
    alignItems: 'center' as const,
  },
  modalImage: {
    width: Dimensions.get('window').width - 40,
    height: Dimensions.get('window').width - 40,
    borderRadius: 8,
  },
});
