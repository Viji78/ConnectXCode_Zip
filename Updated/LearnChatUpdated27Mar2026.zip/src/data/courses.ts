export interface LessonStep {
  title: string;
  explanation: string;
  code?: string;
  output?: string;
  tip?: string;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  steps: LessonStep[];
}

export interface Course {
  id: string;
  title: string;
  icon: string;
  color: string;
  description: string;
  lessons: Lesson[];
}

export const defaultCourses: Course[] = [
  {
    id: 'html',
    title: 'HTML',
    icon: 'logo-html5',
    color: '#E44D26',
    description: 'Learn the foundation of web pages',
    lessons: [
      {
        id: 'html-intro',
        title: 'Introduction to HTML',
        duration: '5 min',
        steps: [
          {
            title: 'What is HTML?',
            explanation: 'HTML stands for HyperText Markup Language. It is the standard language for creating web pages. HTML describes the structure of a web page using elements.',
          },
          {
            title: 'Your First HTML Page',
            explanation: 'Every HTML page starts with a document structure. The <!DOCTYPE html> declaration tells the browser this is an HTML5 document.',
            code: '<!DOCTYPE html>\n<html>\n<head>\n  <title>My Page</title>\n</head>\n<body>\n  <h1>Hello World!</h1>\n  <p>My first web page.</p>\n</body>\n</html>',
            output: 'Hello World!\nMy first web page.',
          },
          {
            title: 'HTML Elements',
            explanation: 'An HTML element is defined by a start tag, some content, and an end tag. Elements can be nested inside other elements.',
            code: '<tagname>Content goes here</tagname>',
            tip: 'Most HTML elements have an opening and closing tag. Some elements like <br> and <img> are self-closing.',
          },
        ],
      },
      {
        id: 'html-elements',
        title: 'HTML Elements',
        duration: '8 min',
        steps: [
          {
            title: 'Headings',
            explanation: 'HTML headings are defined with <h1> to <h6> tags. <h1> is the most important heading and <h6> is the least important.',
            code: '<h1>Heading 1</h1>\n<h2>Heading 2</h2>\n<h3>Heading 3</h3>\n<h4>Heading 4</h4>',
          },
          {
            title: 'Paragraphs',
            explanation: 'The <p> element defines a paragraph. Browsers automatically add some space before and after each paragraph.',
            code: '<p>This is a paragraph.</p>\n<p>This is another paragraph.</p>',
          },
          {
            title: 'Links',
            explanation: 'HTML links are defined with the <a> tag. The href attribute specifies the URL of the page the link goes to.',
            code: '<a href="https://www.example.com">\n  Visit Example\n</a>',
            tip: 'Use target="_blank" to open the link in a new tab.',
          },
          {
            title: 'Images',
            explanation: 'The <img> tag is used to embed images. It requires src (image path) and alt (alternative text) attributes.',
            code: '<img src="photo.jpg" alt="A photo"\n  width="300" height="200">',
            tip: 'Always include the alt attribute for accessibility.',
          },
        ],
      },
      {
        id: 'html-lists',
        title: 'Lists & Tables',
        duration: '7 min',
        steps: [
          {
            title: 'Unordered Lists',
            explanation: 'An unordered list starts with the <ul> tag. Each list item starts with the <li> tag. Items are marked with bullets.',
            code: '<ul>\n  <li>Coffee</li>\n  <li>Tea</li>\n  <li>Milk</li>\n</ul>',
          },
          {
            title: 'Ordered Lists',
            explanation: 'An ordered list starts with the <ol> tag. Each list item starts with the <li> tag. Items are marked with numbers.',
            code: '<ol>\n  <li>First item</li>\n  <li>Second item</li>\n  <li>Third item</li>\n</ol>',
          },
          {
            title: 'Tables',
            explanation: 'HTML tables are defined with the <table> tag. Each row is <tr>, each header cell is <th>, and each data cell is <td>.',
            code: '<table>\n  <tr>\n    <th>Name</th>\n    <th>Age</th>\n  </tr>\n  <tr>\n    <td>Alice</td>\n    <td>25</td>\n  </tr>\n  <tr>\n    <td>Bob</td>\n    <td>30</td>\n  </tr>\n</table>',
          },
        ],
      },
      {
        id: 'html-forms',
        title: 'HTML Forms',
        duration: '10 min',
        steps: [
          {
            title: 'The Form Element',
            explanation: 'The <form> element is used to collect user input. The action attribute defines where to send the form data.',
            code: '<form action="/submit">\n  <!-- form elements -->\n</form>',
          },
          {
            title: 'Input Types',
            explanation: 'The <input> element is the most common form element. It can be displayed in many ways depending on the type attribute.',
            code: '<input type="text" placeholder="Name">\n<input type="email" placeholder="Email">\n<input type="password" placeholder="Password">\n<input type="number" placeholder="Age">\n<input type="checkbox"> Remember me\n<input type="submit" value="Submit">',
          },
          {
            title: 'Labels & Textarea',
            explanation: 'The <label> element defines a label for form elements. The <textarea> element defines a multi-line text input.',
            code: '<label for="msg">Message:</label>\n<textarea id="msg" rows="4" cols="30">\n  Type your message here...\n</textarea>',
            tip: 'Always use labels with form inputs for better accessibility.',
          },
          {
            title: 'Select Dropdown',
            explanation: 'The <select> element creates a drop-down list. The <option> elements define the available options.',
            code: '<select name="country">\n  <option value="">Choose...</option>\n  <option value="us">USA</option>\n  <option value="uk">UK</option>\n  <option value="in">India</option>\n</select>',
          },
        ],
      },
    ],
  },
  {
    id: 'css',
    title: 'CSS',
    icon: 'logo-css3',
    color: '#264DE4',
    description: 'Style and design your web pages',
    lessons: [
      {
        id: 'css-intro',
        title: 'Introduction to CSS',
        duration: '5 min',
        steps: [
          {
            title: 'What is CSS?',
            explanation: 'CSS stands for Cascading Style Sheets. It describes how HTML elements should be displayed on screen. CSS saves a lot of work by controlling the layout of multiple web pages at once.',
          },
          {
            title: 'CSS Syntax',
            explanation: 'A CSS rule consists of a selector and a declaration block. The selector points to the HTML element you want to style.',
            code: 'selector {\n  property: value;\n  property: value;\n}\n\nh1 {\n  color: blue;\n  font-size: 24px;\n}',
          },
          {
            title: 'Ways to Add CSS',
            explanation: 'There are 3 ways to add CSS: Inline (style attribute), Internal (<style> tag), and External (separate .css file). External is the most recommended.',
            code: '<!-- Inline -->\n<p style="color: red;">Text</p>\n\n<!-- Internal -->\n<style>\n  p { color: red; }\n</style>\n\n<!-- External -->\n<link rel="stylesheet"\n  href="styles.css">',
            tip: 'External CSS is the best practice — it separates content from design.',
          },
        ],
      },
      {
        id: 'css-selectors',
        title: 'Selectors & Colors',
        duration: '8 min',
        steps: [
          {
            title: 'CSS Selectors',
            explanation: 'Selectors are used to select HTML elements. You can select by element name, class, ID, or attributes.',
            code: '/* Element selector */\np { color: red; }\n\n/* Class selector */\n.highlight { background: yellow; }\n\n/* ID selector */\n#header { font-size: 24px; }\n\n/* Group selector */\nh1, h2, p { margin: 10px; }',
          },
          {
            title: 'Colors',
            explanation: 'CSS supports color names, HEX values, RGB, and HSL values.',
            code: '/* Named color */\ncolor: tomato;\n\n/* HEX */\ncolor: #ff6347;\n\n/* RGB */\ncolor: rgb(255, 99, 71);\n\n/* With transparency */\ncolor: rgba(255, 99, 71, 0.5);',
          },
          {
            title: 'Backgrounds',
            explanation: 'CSS background properties are used to add background effects to elements.',
            code: 'div {\n  background-color: #f0f0f0;\n  background-image: url("bg.jpg");\n  background-size: cover;\n  background-position: center;\n  background-repeat: no-repeat;\n}',
          },
        ],
      },
      {
        id: 'css-box',
        title: 'Box Model & Layout',
        duration: '10 min',
        steps: [
          {
            title: 'The Box Model',
            explanation: 'Every HTML element is a box. The box model consists of: Content, Padding, Border, and Margin. Understanding this is crucial for layout.',
            code: 'div {\n  width: 300px;\n  padding: 20px;\n  border: 2px solid black;\n  margin: 10px;\n}',
            tip: 'Use box-sizing: border-box to include padding and border in the element\'s total width.',
          },
          {
            title: 'Display Property',
            explanation: 'The display property controls how an element is displayed. Common values are block, inline, inline-block, flex, and grid.',
            code: '.block { display: block; }\n.inline { display: inline; }\n.hidden { display: none; }\n.flex { display: flex; }',
          },
          {
            title: 'Flexbox',
            explanation: 'Flexbox is a layout model that makes it easy to design flexible responsive layouts without float or positioning.',
            code: '.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 10px;\n}\n\n.item {\n  flex: 1;\n}',
            tip: 'Flexbox is perfect for one-dimensional layouts (row or column).',
          },
        ],
      },
    ],
  },
  {
    id: 'javascript',
    title: 'JavaScript',
    icon: 'logo-javascript',
    color: '#F7DF1E',
    description: 'Add interactivity to your websites',
    lessons: [
      {
        id: 'js-intro',
        title: 'Introduction to JavaScript',
        duration: '5 min',
        steps: [
          {
            title: 'What is JavaScript?',
            explanation: 'JavaScript is the programming language of the web. It can update HTML content, change styles, validate data, and make web pages interactive.',
          },
          {
            title: 'Your First Script',
            explanation: 'You can add JavaScript inside <script> tags or in external .js files. Use console.log() to print output.',
            code: '<script>\n  console.log("Hello World!");\n  document.getElementById("demo")\n    .innerHTML = "Hello JavaScript!";\n</script>',
            output: 'Hello World!',
          },
          {
            title: 'Variables',
            explanation: 'Variables are containers for storing data. Use let for changeable values, const for constants, and avoid var.',
            code: 'let name = "Alice";\nconst age = 25;\nlet isStudent = true;\n\nconsole.log(name);  // Alice\nconsole.log(age);   // 25',
            tip: 'Use const by default. Only use let when you need to reassign the value.',
          },
        ],
      },
      {
        id: 'js-datatypes',
        title: 'Data Types & Operators',
        duration: '8 min',
        steps: [
          {
            title: 'Data Types',
            explanation: 'JavaScript has 8 data types: String, Number, BigInt, Boolean, Undefined, Null, Symbol, and Object.',
            code: 'let text = "Hello";     // String\nlet num = 42;           // Number\nlet big = 9007n;        // BigInt\nlet flag = true;        // Boolean\nlet x;                  // Undefined\nlet y = null;           // Null\nlet arr = [1, 2, 3];   // Object\nlet obj = {a: 1};      // Object',
          },
          {
            title: 'Operators',
            explanation: 'JavaScript supports arithmetic, assignment, comparison, and logical operators.',
            code: '// Arithmetic\nlet sum = 10 + 5;   // 15\nlet diff = 10 - 5;  // 5\nlet prod = 10 * 5;  // 50\n\n// Comparison\n10 == "10"   // true (loose)\n10 === "10"  // false (strict)\n\n// Logical\ntrue && false  // false\ntrue || false  // true',
            tip: 'Always use === (strict equality) instead of == to avoid type coercion bugs.',
          },
          {
            title: 'String Methods',
            explanation: 'JavaScript provides many built-in string methods for manipulating text.',
            code: 'let str = "Hello World";\n\nstr.length;         // 11\nstr.toUpperCase();  // HELLO WORLD\nstr.toLowerCase();  // hello world\nstr.includes("World"); // true\nstr.slice(0, 5);    // Hello\nstr.replace("World", "JS"); // Hello JS',
          },
        ],
      },
      {
        id: 'js-functions',
        title: 'Functions',
        duration: '8 min',
        steps: [
          {
            title: 'Function Declaration',
            explanation: 'A function is a block of code designed to perform a task. It is executed when it is called (invoked).',
            code: 'function greet(name) {\n  return "Hello, " + name + "!";\n}\n\nconsole.log(greet("Alice"));\n// Hello, Alice!',
          },
          {
            title: 'Arrow Functions',
            explanation: 'Arrow functions provide a shorter syntax for writing functions. They are especially useful for callbacks.',
            code: '// Regular function\nconst add = function(a, b) {\n  return a + b;\n};\n\n// Arrow function\nconst add = (a, b) => a + b;\n\n// With one parameter\nconst double = n => n * 2;\n\nconsole.log(add(5, 3));    // 8\nconsole.log(double(4));    // 8',
            tip: 'Arrow functions don\'t have their own "this" context — keep this in mind with objects.',
          },
          {
            title: 'Array Methods',
            explanation: 'Modern JavaScript uses array methods with callbacks for powerful data manipulation.',
            code: 'const nums = [1, 2, 3, 4, 5];\n\n// Map - transform each item\nnums.map(n => n * 2);\n// [2, 4, 6, 8, 10]\n\n// Filter - keep matching items\nnums.filter(n => n > 3);\n// [4, 5]\n\n// Find - first match\nnums.find(n => n > 3);\n// 4\n\n// Reduce - accumulate\nnums.reduce((sum, n) => sum + n, 0);\n// 15',
          },
        ],
      },
      {
        id: 'js-dom',
        title: 'DOM Manipulation',
        duration: '10 min',
        steps: [
          {
            title: 'Selecting Elements',
            explanation: 'The DOM (Document Object Model) lets JavaScript access and change HTML elements.',
            code: '// By ID\nconst el = document\n  .getElementById("myId");\n\n// By class\nconst items = document\n  .getElementsByClassName("item");\n\n// Modern way (recommended)\nconst el = document\n  .querySelector("#myId");\nconst all = document\n  .querySelectorAll(".item");',
          },
          {
            title: 'Changing Content & Style',
            explanation: 'You can modify the content, attributes, and styles of HTML elements using JavaScript.',
            code: 'const el = document\n  .querySelector("#demo");\n\n// Change content\nel.innerHTML = "<b>Bold text</b>";\nel.textContent = "Plain text";\n\n// Change style\nel.style.color = "red";\nel.style.fontSize = "20px";\n\n// Change attributes\nel.setAttribute("class", "active");',
          },
          {
            title: 'Event Listeners',
            explanation: 'Events let you run code when something happens — clicks, key presses, form submissions, etc.',
            code: 'const btn = document\n  .querySelector("#myBtn");\n\nbtn.addEventListener("click", () => {\n  alert("Button clicked!");\n});\n\n// Common events:\n// click, dblclick, mouseover,\n// keydown, keyup, submit,\n// change, input, load',
            tip: 'Use addEventListener instead of inline onclick for cleaner, maintainable code.',
          },
        ],
      },
    ],
  },
  {
    id: 'python',
    title: 'Python',
    icon: 'logo-python',
    color: '#3776AB',
    description: 'Popular language for beginners & AI',
    lessons: [
      {
        id: 'py-intro',
        title: 'Introduction to Python',
        duration: '5 min',
        steps: [
          {
            title: 'What is Python?',
            explanation: 'Python is a popular, easy-to-learn programming language. It is used for web development, data science, AI, automation, and more.',
          },
          {
            title: 'Hello World',
            explanation: 'Python uses a simple, readable syntax. Use print() to display output. No semicolons or curly braces needed!',
            code: 'print("Hello, World!")\n\nname = "Alice"\nage = 25\nprint(f"My name is {name}")\nprint(f"I am {age} years old")',
            output: 'Hello, World!\nMy name is Alice\nI am 25 years old',
          },
          {
            title: 'Variables & Types',
            explanation: 'Python is dynamically typed — you don\'t need to declare variable types. Python figures it out automatically.',
            code: 'name = "Alice"     # str\nage = 25           # int\nheight = 5.6       # float\nis_student = True  # bool\nfruits = ["apple", "banana"] # list\n\n# Check type\nprint(type(name))  # <class \'str\'>',
            tip: 'Python uses indentation (spaces) instead of braces {} to define code blocks.',
          },
        ],
      },
      {
        id: 'py-control',
        title: 'Control Flow',
        duration: '8 min',
        steps: [
          {
            title: 'If / Elif / Else',
            explanation: 'Python uses if, elif (else if), and else for conditional execution.',
            code: 'age = 18\n\nif age >= 18:\n    print("Adult")\nelif age >= 13:\n    print("Teenager")\nelse:\n    print("Child")',
            output: 'Adult',
          },
          {
            title: 'For Loops',
            explanation: 'For loops iterate over sequences like lists, strings, or ranges.',
            code: '# Loop through a list\nfruits = ["apple", "banana", "cherry"]\nfor fruit in fruits:\n    print(fruit)\n\n# Loop with range\nfor i in range(5):\n    print(i)  # 0, 1, 2, 3, 4',
          },
          {
            title: 'While Loops',
            explanation: 'While loops run as long as a condition is true.',
            code: 'count = 0\nwhile count < 5:\n    print(count)\n    count += 1\n# Output: 0, 1, 2, 3, 4',
            tip: 'Be careful with while loops — make sure the condition eventually becomes False to avoid infinite loops!',
          },
        ],
      },
      {
        id: 'py-functions',
        title: 'Functions & Lists',
        duration: '8 min',
        steps: [
          {
            title: 'Defining Functions',
            explanation: 'Functions are defined using the def keyword. They can accept parameters and return values.',
            code: 'def greet(name):\n    return f"Hello, {name}!"\n\ndef add(a, b):\n    return a + b\n\nprint(greet("Alice"))  # Hello, Alice!\nprint(add(5, 3))       # 8',
          },
          {
            title: 'Lists',
            explanation: 'Lists are ordered, mutable collections. They can hold different data types.',
            code: 'fruits = ["apple", "banana", "cherry"]\n\nfruits.append("date")    # Add item\nfruits.remove("banana")  # Remove item\nprint(len(fruits))       # Length: 3\nprint(fruits[0])         # First: apple\nprint(fruits[-1])        # Last: date',
          },
          {
            title: 'List Comprehension',
            explanation: 'List comprehension offers a concise way to create lists based on existing lists.',
            code: 'numbers = [1, 2, 3, 4, 5]\n\n# Double each number\ndoubled = [n * 2 for n in numbers]\n# [2, 4, 6, 8, 10]\n\n# Filter even numbers\nevens = [n for n in numbers if n % 2 == 0]\n# [2, 4]',
            tip: 'List comprehensions are Pythonic and faster than regular for loops for creating lists.',
          },
        ],
      },
    ],
  },
  {
    id: 'sql',
    title: 'SQL',
    icon: 'server-outline',
    color: '#336791',
    description: 'Query and manage databases',
    lessons: [
      {
        id: 'sql-intro',
        title: 'Introduction to SQL',
        duration: '5 min',
        steps: [
          {
            title: 'What is SQL?',
            explanation: 'SQL (Structured Query Language) is the standard language for managing relational databases. It lets you create, read, update, and delete data.',
          },
          {
            title: 'SELECT Statement',
            explanation: 'The SELECT statement is used to retrieve data from a database table.',
            code: 'SELECT * FROM users;\n\nSELECT name, email\nFROM users;',
            tip: 'Avoid SELECT * in production — only select the columns you need for better performance.',
          },
          {
            title: 'WHERE Clause',
            explanation: 'The WHERE clause filters records based on specified conditions.',
            code: 'SELECT name, age\nFROM users\nWHERE age >= 18;\n\nSELECT *\nFROM products\nWHERE price > 100\n  AND category = \'electronics\';',
          },
        ],
      },
      {
        id: 'sql-crud',
        title: 'INSERT, UPDATE, DELETE',
        duration: '7 min',
        steps: [
          {
            title: 'INSERT',
            explanation: 'The INSERT INTO statement adds new records to a table.',
            code: 'INSERT INTO users (name, email, age)\nVALUES (\'Alice\', \'alice@mail.com\', 25);\n\n-- Insert multiple rows\nINSERT INTO users (name, email, age)\nVALUES\n  (\'Bob\', \'bob@mail.com\', 30),\n  (\'Carol\', \'carol@mail.com\', 28);',
          },
          {
            title: 'UPDATE',
            explanation: 'The UPDATE statement modifies existing records in a table.',
            code: 'UPDATE users\nSET email = \'newemail@mail.com\'\nWHERE name = \'Alice\';\n\nUPDATE products\nSET price = price * 0.9\nWHERE category = \'sale\';',
            tip: 'Always include a WHERE clause with UPDATE — without it, ALL rows will be updated!',
          },
          {
            title: 'DELETE',
            explanation: 'The DELETE statement removes records from a table.',
            code: 'DELETE FROM users\nWHERE id = 5;\n\nDELETE FROM orders\nWHERE created_at < \'2024-01-01\';',
            tip: 'Like UPDATE, always use WHERE with DELETE to avoid deleting all records.',
          },
        ],
      },
    ],
  },
  {
    id: 'react',
    title: 'React',
    icon: 'logo-react',
    color: '#61DAFB',
    description: 'Build modern user interfaces',
    lessons: [
      {
        id: 'react-intro',
        title: 'Introduction to React',
        duration: '5 min',
        steps: [
          {
            title: 'What is React?',
            explanation: 'React is a JavaScript library for building user interfaces. It lets you build reusable components and efficiently update the DOM.',
          },
          {
            title: 'Components',
            explanation: 'Components are the building blocks of React. They are JavaScript functions that return JSX (HTML-like syntax).',
            code: 'function Welcome() {\n  return (\n    <div>\n      <h1>Hello, React!</h1>\n      <p>Welcome to my app.</p>\n    </div>\n  );\n}\n\nexport default Welcome;',
          },
          {
            title: 'Props',
            explanation: 'Props (properties) are how you pass data from a parent component to a child component.',
            code: 'function Greeting({ name, age }) {\n  return (\n    <div>\n      <h1>Hello, {name}!</h1>\n      <p>You are {age} years old.</p>\n    </div>\n  );\n}\n\n// Usage:\n<Greeting name="Alice" age={25} />',
            tip: 'Props are read-only — a component should never modify its own props.',
          },
        ],
      },
      {
        id: 'react-state',
        title: 'State & Events',
        duration: '8 min',
        steps: [
          {
            title: 'useState Hook',
            explanation: 'State lets components remember information between renders. The useState hook returns a value and a setter function.',
            code: 'import { useState } from "react";\n\nfunction Counter() {\n  const [count, setCount] = useState(0);\n\n  return (\n    <div>\n      <p>Count: {count}</p>\n      <button onClick={() =>\n        setCount(count + 1)\n      }>\n        Add\n      </button>\n    </div>\n  );\n}',
          },
          {
            title: 'Handling Events',
            explanation: 'React events are named using camelCase. You pass functions as event handlers, not strings.',
            code: 'function Form() {\n  const [text, setText] = useState("");\n\n  const handleSubmit = (e) => {\n    e.preventDefault();\n    alert("Submitted: " + text);\n  };\n\n  return (\n    <form onSubmit={handleSubmit}>\n      <input\n        value={text}\n        onChange={e =>\n          setText(e.target.value)\n        }\n      />\n      <button type="submit">\n        Submit\n      </button>\n    </form>\n  );\n}',
          },
          {
            title: 'useEffect Hook',
            explanation: 'useEffect lets you perform side effects — fetching data, setting up subscriptions, or updating the DOM after render.',
            code: 'import { useState, useEffect } from "react";\n\nfunction Timer() {\n  const [seconds, setSeconds] = useState(0);\n\n  useEffect(() => {\n    const id = setInterval(() => {\n      setSeconds(s => s + 1);\n    }, 1000);\n\n    return () => clearInterval(id);\n  }, []);\n\n  return <p>Time: {seconds}s</p>;\n}',
            tip: 'The empty [] dependency array means the effect runs only once on mount.',
          },
        ],
      },
    ],
  },
];

// Backward compat alias
export const courses = defaultCourses;
