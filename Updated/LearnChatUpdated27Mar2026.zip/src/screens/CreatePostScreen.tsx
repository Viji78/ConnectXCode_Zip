import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  ActivityIndicator,
  Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { User } from '../types';
import { createPost } from '../services/posts';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';
import ImageCropModal from '../components/ImageCropModal';

interface Props {
  navigation: any;
  user: User;
}

export default function CreatePostScreen({ navigation, user }: Props) {
  const [content, setContent] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'friends' | 'private'>('public');
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [cropImageUri, setCropImageUri] = useState('');
  const [showCropModal, setShowCropModal] = useState(false);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow access to your photo library.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: false,
      quality: 1,
      allowsMultipleSelection: false,
    });
    if (!result.canceled && result.assets[0]) {
      setCropImageUri(result.assets[0].uri);
      setShowCropModal(true);
    }
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow access to your camera.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: false,
      quality: 1,
    });
    if (!result.canceled && result.assets[0]) {
      setCropImageUri(result.assets[0].uri);
      setShowCropModal(true);
    }
  };

  const handleCropDone = (uri: string) => {
    setShowCropModal(false);
    setSelectedImage(uri);
  };

  const handleCreatePost = async () => {
    if (!content.trim() && !selectedImage) {
      Alert.alert('Error', 'Please add text or an image');
      return;
    }

    setLoading(true);
    try {
      await createPost(
        user.id,
        user.username,
        content,
        visibility,
        user.profileImage,
        selectedImage || undefined
      );
      Alert.alert('Success', 'Post created! Visible for 24 hours.');
      navigation.goBack();
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to create post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={common.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={common.headerTitle}>New Post </Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content} keyboardShouldPersistTaps="handled">
       
        {/* -------------------- Your Story ------------------- */}
        {/* <TouchableOpacity style={styles.storyRow}>
          <View style={styles.storyAvatarWrap}>
            {user.profileImage && user.profileImage.length > 2 ? (
              <Image source={{ uri: user.profileImage }} style={styles.storyAvatar} />
            ) : (
              <View style={styles.storyAvatarPlaceholder}>
                <Text style={styles.storyAvatarLetter}>
                  {user.username.charAt(0).toUpperCase()}
                 </Text>
              </View>
            )}
            <View style={styles.storyAddBadge}>
              <Ionicons name="add" size={14} color={colors.textWhite} />
            </View>
          </View>
          <View style={styles.storyTextWrap}>
            <Text style={styles.storyLabel}>Your Story </Text>
            <Text style={styles.storySubLabel}>Add to your story </Text>
          </View>
        </TouchableOpacity> */}

        {/* ------------------- Image Section ------------------- */}
        <View style={styles.section}>
          {selectedImage ? (
            <View style={styles.imagePreviewContainer}>
              <Image source={{ uri: selectedImage }} style={styles.imagePreview} />
              <TouchableOpacity
                style={styles.removeImageBtn}
                onPress={() => setSelectedImage(null)}
              >
                <Ionicons name="close-circle" size={30} color={colors.error} />
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.imagePickerButtons}>
              <TouchableOpacity style={styles.imagePickerBtn} onPress={pickImage}>
                <Ionicons name="images-outline" size={30} color={colors.primary} />
                <Text style={styles.imagePickerBtnText}>Gallery </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.imagePickerBtn} onPress={takePhoto}>
                <Ionicons name="camera-outline" size={30} color={colors.primary} />
                <Text style={styles.imagePickerBtnText}>Camera </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Caption / Text */}
        <View style={styles.section}>
          <TextInput
            style={styles.textInput}
            placeholder="Write a caption..."
            placeholderTextColor={colors.textPlaceholder}
            multiline
            value={content}
            onChangeText={setContent}
            maxLength={2000}
          />
        </View>

        {/* Visibility */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Who can see this? </Text>
          <View style={styles.visibilityRow}>
            {[
              { key: 'public' as const, icon: 'globe-outline', label: 'Public' },
              { key: 'friends' as const, icon: 'people-outline', label: 'Friends' },
              { key: 'private' as const, icon: 'lock-closed-outline', label: 'Only Me' },
            ].map((opt) => (
              <TouchableOpacity
                key={opt.key}
                style={[styles.visibilityChip, visibility === opt.key && styles.visibilityChipActive]}
                onPress={() => setVisibility(opt.key)}
              >
                <Ionicons
                  name={opt.icon as any}
                  size={18}
                  color={visibility === opt.key ? colors.textWhite : colors.textBody}
                />
                <Text style={[styles.visibilityChipText, visibility === opt.key && styles.visibilityChipTextActive]}>
                  {opt.label}
                 </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Info */}
        <View style={styles.infoRow}>
          <Ionicons name="time-outline" size={16} color={colors.textPlaceholder} />
          <Text style={styles.infoText}>Posts auto-delete after 24 hours </Text>
        </View>
      </ScrollView>

      {loading && (
        <View style={common.loadingOverlay}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.uploadingText}>Uploading... </Text>
        </View>
      )}

      {/* Share Button */}
      <View style={styles.shareButtonContainer}>
        <TouchableOpacity
          style={[styles.shareButton, loading && styles.shareButtonDisabled]}
          onPress={handleCreatePost}
          disabled={loading}
        >
          <Text style={styles.shareButtonText}>
            {loading ? 'Posting...' : 'Share'}
           </Text>
        </TouchableOpacity>
      </View>

      <BottomNav navigation={navigation} active="Create" />

      <ImageCropModal
        visible={showCropModal}
        imageUri={cropImageUri}
        squareOnly={false}
        onDone={handleCropDone}
        onCancel={() => setShowCropModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  postButton: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.primary,
  },
  postButtonDisabled: {
    color: colors.textPlaceholder,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  section: {
    marginBottom: 20,
  },
  sectionLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textBody,
    marginBottom: 10,
  },
  // Image picker
  imagePickerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  imagePickerBtn: {
    flex: 1,
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.borderLight,
    borderStyle: 'dashed',
    paddingVertical: 36,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  imagePickerBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  imagePreviewContainer: {
    position: 'relative',
  },
  imagePreview: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 12,
    backgroundColor: colors.bgInputLight,
    resizeMode: 'contain',
  },
  removeImageBtn: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: colors.bgWhite,
    borderRadius: 15,
  },
  // Text input
  textInput: {
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.borderLight,
    color: colors.textDark,
  },
  // Visibility chips
  visibilityRow: {
    flexDirection: 'row',
    gap: 8,
  },
  visibilityChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: colors.bgWhite,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
  },
  visibilityChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  visibilityChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textBody,
  },
  visibilityChipTextActive: {
    color: colors.textWhite,
  },
  // Info
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    justifyContent: 'center',
    marginTop: 8,
  },
  infoText: {
    fontSize: 12,
    color: colors.textPlaceholder,
  },
  uploadingText: {
    color: colors.textWhite,
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
  },
  // Share Button
  shareButtonContainer: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: colors.bgWhite,
    borderTopWidth: 0.5,
    borderTopColor: colors.borderLight,
  },
  shareButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  shareButtonDisabled: {
    backgroundColor: colors.primaryFaded,
  },
  shareButtonText: {
    color: colors.textWhite,
    fontSize: 16,
    fontWeight: 'bold',
  },
  // Your Story
  storyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 14,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  storyAvatarWrap: {
    position: 'relative',
    marginRight: 12,
  },
  storyAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  storyAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  storyAvatarLetter: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  storyAddBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.info,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.bgWhite,
  },
  storyTextWrap: {
    flex: 1,
  },
  storyLabel: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textDark,
  },
  storySubLabel: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
  },
});
