import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  TextInput,
  Alert,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DrawerActions } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';
import { courses as staticCourses, Course } from '../data/courses';
import { getCustomCourses, deleteCourse, seedDefaultCourses } from '../services/courseCreator';
import { getReceivedRequests } from '../services/friends';
import { getChats } from '../services/messages';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';

interface Props {
  navigation: any;
  user: User;
}

export default function LearnScreen({ navigation, user }: Props) {
  const [search, setSearch] = useState('');
  const [progress, setProgress] = useState<{ [courseId: string]: number }>({});
  const [requestCount, setRequestCount] = useState(0);
  const [messageCount, setMessageCount] = useState(0);
  const [customCourses, setCustomCourses] = useState<Course[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  // Use Firestore courses if loaded, fallback to static
  const courses = customCourses.length > 0 ? customCourses : staticCourses;

  useEffect(() => {
    loadProgress();
    loadCounts();
    loadCustomCourses();
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadProgress();
      loadCounts();
      loadCustomCourses();
    });
    return unsubscribe;
  }, [navigation]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadProgress();
    await loadCounts();
    await loadCustomCourses();
    setRefreshing(false);
  };

  const loadCustomCourses = async () => {
    try {
      if (user.user_role === 'Admin') {
        await seedDefaultCourses();
      }
      const data = await getCustomCourses();
      setCustomCourses(data);
    } catch {}
  };

  const loadCounts = async () => {
    try {
      const requests = await getReceivedRequests(user.id);
      setRequestCount(requests.length);
    } catch {}
    try {
      const chats = await getChats(user.id);
      const total = chats.reduce((sum, chat) => sum + (chat.unreadCount[user.id] || 0), 0);
      setMessageCount(total);
    } catch {}
  };

  const loadProgress = async () => {
    try {
      const stored = await AsyncStorage.getItem(`learn_progress_${user.id}`);
      if (stored) setProgress(JSON.parse(stored));
    } catch {}
  };

  const filtered = courses.filter(
    (c) =>
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase())
  );

  const getCompletedLessons = (course: Course) => {
    const total = (course.lessons || []).length;
    const completed = progress[course.id] || 0;
    return Math.min(completed, total);
  };

  const getProgressPercent = (course: Course) => {
    const lessons = course.lessons || [];
    if (lessons.length === 0) return 0;
    const completed = getCompletedLessons(course);
    return Math.min(Math.round((completed / lessons.length) * 100), 100);
  };

  const isCustomCourse = (courseId: string) => customCourses.some(c => c.id === courseId);
  const isAdmin = user.user_role === 'Admin';

  const handleDeleteCourse = (course: Course) => {
    Alert.alert('Delete Course', `Delete "${course.title}" and all its lessons?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteCourse(course.id);
            setCustomCourses(prev => prev.filter(c => c.id !== course.id));
          } catch {
            Alert.alert('Error', 'Failed to delete course');
          }
        },
      },
    ]);
  };

  const renderCourse = ({ item }: { item: Course }) => {
    const percent = getProgressPercent(item);
    const completed = getCompletedLessons(item);

    const isCustom = isCustomCourse(item.id);

    return (
      <TouchableOpacity
        style={styles.courseCard}
        onPress={() => navigation.navigate('Course', { courseId: item.id })}
        activeOpacity={0.7}
      >
        <View style={[styles.courseIconBox, { backgroundColor: item.color + '18' }]}>
          <Ionicons name={item.icon as any} size={32} color={item.color} />
        </View>
        <View style={styles.courseInfo}>
          <Text style={styles.courseTitle}>{item.title} </Text>
          <Text style={styles.courseDesc} numberOfLines={1}>{item.description} </Text>
          <View style={styles.progressRow}>
            <View style={styles.progressBarBg}>
              <View style={[styles.progressBarFill, { width: `${percent}%`, backgroundColor: item.color }]} />
            </View>
            <Text style={styles.progressText}>
              {completed}/{(item.lessons || []).length}
             </Text>
          </View>
        </View>
        {isAdmin && isCustom ? (
          <View style={styles.adminActions}>
            <TouchableOpacity
              style={styles.adminActionBtn}
              onPress={(e) => { e.stopPropagation(); navigation.navigate('AddCourse'); }}
            >
              <Ionicons name="create-outline" size={18} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.adminActionBtn}
              onPress={(e) => { e.stopPropagation(); handleDeleteCourse(item); }}
            >
              <Ionicons name="trash-outline" size={18} color={colors.error} />
            </TouchableOpacity>
          </View>
        ) : (
          <Ionicons name="chevron-forward" size={20} color={colors.textPlaceholder} />
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        {user.user_role === 'Admin' && (
          <TouchableOpacity
            style={styles.menuBtn}
            onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
          >
            <Ionicons name="menu" size={26} color={colors.textDark} />
          </TouchableOpacity>
        )}
        <View style={styles.headerLeft}>
          <Text style={styles.greeting}>Hello, {user.username}! </Text>
          <Text style={styles.subtitle}>What do you want to learn today? </Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Search', { openTab: 'requests' })}
          >
            <Ionicons name="notifications-outline" size={24} color={colors.textDark} />
            {requestCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{requestCount} </Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Messages')}
          >
            <Ionicons name="chatbubble-outline" size={24} color={colors.textDark} />
            {messageCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{messageCount} </Text>
              </View>
            )}
          </TouchableOpacity>
          {/* {user.user_role === 'Admin' && (
            <TouchableOpacity
              style={styles.headerButton}
              onPress={() => navigation.navigate('AdminPanel')}
            >
              <Ionicons name="shield-checkmark" size={24} color={colors.primary} />
            </TouchableOpacity>
          )} */}
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Ionicons name="search-outline" size={20} color={colors.textPlaceholder} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search courses..."
            placeholderTextColor={colors.textPlaceholder}
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color={colors.textPlaceholder} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{courses.length} </Text>
          <Text style={styles.statLabel}>Courses </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>
            {courses.reduce((sum, c) => sum + (c.lessons || []).length, 0)}
           </Text>
          <Text style={styles.statLabel}>Lessons </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>
            {Object.values(progress).reduce((sum, v) => sum + v, 0)}
           </Text>
          <Text style={styles.statLabel}>Completed </Text>
        </View>
      </View>

      {/* Course List */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderCourse}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
        }
        ListEmptyComponent={
          <View style={common.emptyContainer}>
            <Ionicons name="search-outline" size={48} color={colors.textPlaceholder} />
            <Text style={common.emptyTitle}>No courses found </Text>
            <Text style={common.emptyText}>Try a different search term </Text>
          </View>
        }
      />

      <BottomNav navigation={navigation} active="Home" />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 54,
    paddingBottom: 12,
    backgroundColor: colors.bgWhite,
  },
  menuBtn: {
    padding: 4,
    marginRight: 10,
  },
  headerLeft: {
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 18,
  },
  headerButton: {
    padding: 4,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -6,
    backgroundColor: colors.error,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: colors.textWhite,
    fontSize: 11,
    fontWeight: 'bold',
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textMuted,
    marginTop: 2,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgInputLight,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 42,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: colors.textDark,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 10,
  },
  statBox: {
    flex: 1,
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  courseCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  courseIconBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  courseInfo: {
    flex: 1,
  },
  courseTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.textDark,
  },
  courseDesc: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 8,
  },
  progressBarBg: {
    flex: 1,
    height: 6,
    backgroundColor: colors.bgInputLight,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: 6,
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '600',
    minWidth: 28,
  },
  adminActions: {
    flexDirection: 'row',
    gap: 6,
  },
  adminActionBtn: {
    padding: 6,
    borderRadius: 8,
    backgroundColor: colors.bgInputLight,
  },
});
