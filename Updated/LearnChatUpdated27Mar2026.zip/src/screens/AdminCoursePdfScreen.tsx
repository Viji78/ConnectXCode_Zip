import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
  TextInput,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { User, CoursePdf } from '../types';
import { courses as staticCourses, Course } from '../data/courses';
import { getCustomCourses, seedDefaultCourses } from '../services/courseCreator';
import { uploadPdf, getCoursePdfs, deletePdf, formatFileSize } from '../services/coursePdfCreater';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  user: User;
}

export default function AdminCoursePdfScreen({ navigation, user }: Props) {
  const [courses, setCourses] = useState<Course[]>(staticCourses);
  const [allPdfs, setAllPdfs] = useState<{ [courseId: string]: CoursePdf[] }>({});
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  // Upload form state
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadCourse, setUploadCourse] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [pickedFile, setPickedFile] = useState<{ uri: string; name: string; size: number } | null>(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      await seedDefaultCourses();
      const custom = await getCustomCourses();
      const allCourses = custom.length > 0 ? custom : staticCourses;
      setCourses(allCourses);
      if (allCourses.length > 0 && !uploadCourse) {
        setUploadCourse(allCourses[0].id);
      }
      const result: { [courseId: string]: CoursePdf[] } = {};
      for (const c of allCourses) {
        const pdfs = await getCoursePdfs(c.id);
        if (pdfs.length > 0) result[c.id] = pdfs;
      }
      setAllPdfs(result);
    } catch {}
    setLoading(false);
  };

  const handlePickFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
      });

      if (result.canceled || !result.assets[0]) return;

      const file = result.assets[0];

      if (file.size && file.size > 700000) {
        Alert.alert('File too large', 'PDF must be under 700KB. Please use a smaller file.');
        return;
      }

      setPickedFile({ uri: file.uri, name: file.name || 'document.pdf', size: file.size || 0 });
      setDisplayName(file.name?.replace('.pdf', '') || '');
    } catch {
      Alert.alert('Error', 'Failed to pick file');
    }
  };

  const handleSubmitUpload = async () => {
    if (!pickedFile) {
      Alert.alert('Error', 'Please select a PDF file first');
      return;
    }
    if (!displayName.trim()) {
      Alert.alert('Error', 'Please enter a display name');
      return;
    }

    setUploading(true);
    try {
      const base64 = await FileSystem.readAsStringAsync(pickedFile.uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const dataUri = `data:application/pdf;base64,${base64}`;

      const fileName = displayName.trim().endsWith('.pdf')
        ? displayName.trim()
        : `${displayName.trim()}.pdf`;

      const pdf = await uploadPdf(
        uploadCourse,
        fileName,
        pickedFile.size,
        dataUri,
        user.id
      );

      // Update local state
      setAllPdfs(prev => ({
        ...prev,
        [uploadCourse]: [pdf, ...(prev[uploadCourse] || [])],
      }));

      const courseName = courses.find(c => c.id === uploadCourse)?.title;
      Alert.alert('Success', `"${fileName}" uploaded to ${courseName}`);

      // Reset form
      setShowUploadModal(false);
      setPickedFile(null);
      setDisplayName('');
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to upload PDF');
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePdf = (pdf: CoursePdf) => {
    Alert.alert('Delete PDF', `Delete "${pdf.fileName}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deletePdf(pdf.id);
            setAllPdfs(prev => {
              const updated = { ...prev };
              updated[pdf.courseId] = (updated[pdf.courseId] || []).filter(p => p.id !== pdf.id);
              if (updated[pdf.courseId].length === 0) delete updated[pdf.courseId];
              return updated;
            });
          } catch {
            Alert.alert('Error', 'Failed to delete PDF');
          }
        },
      },
    ]);
  };

  const openUploadModal = () => {
    setPickedFile(null);
    setDisplayName('');
    setUploadCourse(courses[0].id);
    setShowUploadModal(true);
  };

  const totalPdfs = Object.values(allPdfs).reduce((sum, arr) => sum + arr.length, 0);

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Admin Panel </Text>
        <View style={styles.adminBadge}>
          <Ionicons name="shield-checkmark" size={16} color={colors.textWhite} />
        </View>
      </View>

      {/* Upload Button */}
      <View style={styles.uploadSection}>
        <TouchableOpacity style={styles.uploadBtn} onPress={openUploadModal}>
          <Ionicons name="cloud-upload-outline" size={22} color={colors.textWhite} />
          <Text style={styles.uploadBtnText}>Upload New PDF </Text>
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{totalPdfs} </Text>
          <Text style={styles.statLabel}>Total PDFs </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{Object.keys(allPdfs).length} </Text>
          <Text style={styles.statLabel}>Courses </Text>
        </View>
      </View>

      {/* All PDFs grouped by course */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {totalPdfs === 0 && (
            <View style={styles.emptyContainer}>
              <Ionicons name="document-outline" size={48} color={colors.textPlaceholder} />
              <Text style={styles.emptyTitle}>No PDFs uploaded yet </Text>
              <Text style={styles.emptyText}>Tap "Upload New PDF" to get started </Text>
            </View>
          )}

          {courses.map(c => {
            const coursePdfs = allPdfs[c.id];
            if (!coursePdfs || coursePdfs.length === 0) return null;

            return (
              <View key={c.id} style={styles.courseGroup}>
                <View style={styles.courseGroupHeader}>
                  <View style={[styles.courseGroupIcon, { backgroundColor: c.color + '18' }]}>
                    <Ionicons name={c.icon as any} size={20} color={c.color} />
                  </View>
                  <Text style={styles.courseGroupTitle}>{c.title} </Text>
                  <View style={[styles.countBadge, { backgroundColor: c.color }]}>
                    <Text style={styles.countBadgeText}>{coursePdfs.length} </Text>
                  </View>
                </View>

                {coursePdfs.map(pdf => (
                  <View key={pdf.id} style={styles.pdfCard}>
                    <View style={[styles.pdfIcon, { backgroundColor: c.color + '18' }]}>
                      <Ionicons name="document-text" size={22} color={c.color} />
                    </View>
                    <View style={styles.pdfInfo}>
                      <Text style={styles.pdfName} numberOfLines={1}>{pdf.fileName} </Text>
                      <Text style={styles.pdfMeta}>
                        {formatFileSize(pdf.fileSize)} · {new Date(pdf.uploadedAt).toLocaleDateString()}
                       </Text>
                    </View>
                    <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDeletePdf(pdf)}>
                      <Ionicons name="trash-outline" size={20} color={colors.error} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            );
          })}
          <View style={{ height: 32 }} />
        </ScrollView>
      )}

      {/* Upload Modal */}
      <Modal visible={showUploadModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Upload PDF </Text>
              <TouchableOpacity onPress={() => setShowUploadModal(false)}>
                <Ionicons name="close" size={24} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            {/* Step 1: Select Course */}
            <Text style={styles.formLabel}>1. Select Course </Text>
            <View style={styles.courseChips}>
              {courses.map(c => (
                <TouchableOpacity
                  key={c.id}
                  style={[
                    styles.courseChip,
                    uploadCourse === c.id && { backgroundColor: c.color, borderColor: c.color },
                  ]}
                  onPress={() => setUploadCourse(c.id)}
                >
                  <Ionicons
                    name={c.icon as any}
                    size={14}
                    color={uploadCourse === c.id ? colors.textWhite : c.color}
                  />
                  <Text style={[
                    styles.courseChipText,
                    uploadCourse === c.id && { color: colors.textWhite },
                  ]}>
                    {c.title}
                   </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Step 2: Pick PDF */}
            <Text style={styles.formLabel}>2. Select PDF File </Text>
            <TouchableOpacity style={styles.pickFileBtn} onPress={handlePickFile}>
              <Ionicons
                name={pickedFile ? 'document-text' : 'folder-open-outline'}
                size={22}
                color={pickedFile ? colors.success : colors.primary}
              />
              <Text style={styles.pickFileBtnText} numberOfLines={1}>
                {pickedFile ? `${pickedFile.name} (${formatFileSize(pickedFile.size)})` : 'Tap to select PDF...'}
               </Text>
              {pickedFile && (
                <TouchableOpacity onPress={() => setPickedFile(null)}>
                  <Ionicons name="close-circle" size={20} color={colors.textPlaceholder} />
                </TouchableOpacity>
              )}
            </TouchableOpacity>

            {/* Step 3: Display Name */}
            <Text style={styles.formLabel}>3. Display Name </Text>
            <TextInput
              style={styles.nameInput}
              placeholder="Enter display name for this PDF..."
              placeholderTextColor={colors.textPlaceholder}
              value={displayName}
              onChangeText={setDisplayName}
              maxLength={100}
            />

            {/* Submit */}
            <TouchableOpacity
              style={[
                styles.submitBtn,
                (!pickedFile || !displayName.trim() || uploading) && styles.submitBtnDisabled,
              ]}
              onPress={handleSubmitUpload}
              disabled={!pickedFile || !displayName.trim() || uploading}
            >
              {uploading ? (
                <ActivityIndicator size="small" color={colors.textWhite} />
              ) : (
                <Ionicons name="cloud-upload-outline" size={20} color={colors.textWhite} />
              )}
              <Text style={styles.submitBtnText}>
                {uploading ? 'Uploading...' : 'Upload PDF'}
               </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 52,
    paddingBottom: 12,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  backBtn: {
    padding: 4,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textDark,
    flex: 1,
  },
  adminBadge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 6,
  },
  uploadSection: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 6,
  },
  uploadBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
  },
  uploadBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 10,
  },
  statBox: {
    flex: 1,
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  scrollContent: {
    flex: 1,
    paddingHorizontal: 16,
  },
  courseGroup: {
    marginBottom: 16,
  },
  courseGroupHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  courseGroupIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  courseGroupTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textDark,
    flex: 1,
  },
  countBadge: {
    borderRadius: 10,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
  },
  countBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  pdfCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  pdfIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  pdfInfo: {
    flex: 1,
  },
  pdfName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textDark,
  },
  pdfMeta: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  deleteBtn: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textMuted,
    marginTop: 12,
  },
  emptyText: {
    fontSize: 13,
    color: colors.textPlaceholder,
    marginTop: 4,
  },

  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.bgWhite,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    paddingBottom: 36,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  formLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textBody,
    marginBottom: 8,
    marginTop: 14,
  },
  courseChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  courseChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
    backgroundColor: colors.bgWhite,
  },
  courseChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textBody,
  },
  pickFileBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.bgInputLight,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderStyle: 'dashed',
  },
  pickFileBtnText: {
    flex: 1,
    fontSize: 14,
    color: colors.textBody,
  },
  nameInput: {
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 14,
    fontSize: 15,
    color: colors.textDark,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: colors.success,
    borderRadius: 12,
    paddingVertical: 14,
    marginTop: 20,
  },
  submitBtnDisabled: {
    opacity: 0.4,
  },
  submitBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
});
