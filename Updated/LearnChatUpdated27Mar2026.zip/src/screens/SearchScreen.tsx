import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { User, FriendRequest } from '../types';
import {
  getAllUsers,
  sendFriendRequest,
  getReceivedRequests,
  getSentRequests,
  acceptFriendRequest,
  rejectFriendRequest,
} from '../services/friends';
import { findChat, createChat } from '../services/messages';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';

interface Props {
  navigation: any;
  route?: any;
  user: User;
}

export default function SearchScreen({ navigation, route, user }: Props) {
  const initialTab = route?.params?.openTab === 'requests' ? 'requests' : 'search';
  const [searchText, setSearchText] = useState('');
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'search' | 'requests'>(initialTab);
  const [receivedRequests, setReceivedRequests] = useState<FriendRequest[]>([]);
  const [sentRequestUserIds, setSentRequestUserIds] = useState<string[]>([]);
  const [friendIds, setFriendIds] = useState<string[]>(user.friends || []);
  const [loadingRequests, setLoadingRequests] = useState(false);

  // Load users every time screen is focused + handle openTab param
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadAll();
      if (route?.params?.openTab === 'requests') {
        setTab('requests');
      }
    });
    return unsubscribe;
  }, [navigation, route?.params?.openTab]);

  const loadAll = async () => {
    setLoading(true);
    try {
      const users = await getAllUsers(user.id);
      setAllUsers(users);
      // Refresh friend IDs from loaded users' data against current user's friends in Firestore
      // Reload fresh friend IDs from Firestore
      const { getDoc, doc } = await import('firebase/firestore');
      const { db } = await import('../../firebase.config');
      const myDoc = await getDoc(doc(db, 'users', user.id));
      if (myDoc.exists()) {
        setFriendIds(myDoc.data().friends || []);
      }
    } catch (e) {
      console.error('Failed to load users:', e);
    }
    try {
      const received = await getReceivedRequests(user.id);
      setReceivedRequests(received);
    } catch (e) {
      console.error('Failed to load received requests:', e);
    }
    try {
      const sent = await getSentRequests(user.id);
      setSentRequestUserIds(sent.map((r) => r.toUserId));
    } catch (e) {
      console.error('Failed to load sent requests:', e);
    }
    setLoading(false);
  };

  const loadRequests = async () => {
    setLoadingRequests(true);
    const [received, sent] = await Promise.all([
      getReceivedRequests(user.id),
      getSentRequests(user.id),
    ]);
    setReceivedRequests(received);
    setSentRequestUserIds(sent.map((r) => r.toUserId));
    setLoadingRequests(false);
  };

  // Filter out current user + filter by search text
  const filteredUsers = allUsers
    .filter((u) => u.id !== user.id)
    .filter((u) =>
      searchText.trim()
        ? u.username.toLowerCase().includes(searchText.toLowerCase()) ||
          u.email.toLowerCase().includes(searchText.toLowerCase())
        : true
    );

  const handleSendRequest = async (toUser: User) => {
    try {
      await sendFriendRequest(user, toUser);
      setSentRequestUserIds([...sentRequestUserIds, toUser.id]);
      Alert.alert('Sent', `Friend request sent to ${toUser.username}`);
    } catch (error: any) {
      Alert.alert('Info', error.message);
    }
  };

  const handleAccept = async (request: FriendRequest) => {
    try {
      await acceptFriendRequest(request);
      const updatedFriends = [...friendIds, request.fromUserId];
      setFriendIds(updatedFriends);
      setReceivedRequests(receivedRequests.filter((r) => r.id !== request.id));
      setSentRequestUserIds(sentRequestUserIds.filter((id) => id !== request.fromUserId));
      Alert.alert('Accepted', `You and ${request.fromUsername} are now friends!`);
    } catch (error: any) {
      console.error('Accept failed:', error);
      Alert.alert('Error', error.message || 'Failed to accept request. Check Firestore rules.');
    }
  };

  const handleReject = async (request: FriendRequest) => {
    await rejectFriendRequest(request.id);
    setReceivedRequests(receivedRequests.filter((r) => r.id !== request.id));
  };

  const handleStartChat = async (friend: User) => {
    const existing = await findChat(user.id, friend.id);
    if (existing) {
      navigation.navigate('Chat', { chatId: existing.id, friendName: friend.username });
    } else {
      const newChat = await createChat(
        [user.id, friend.id],
        { [user.id]: user.username, [friend.id]: friend.username }
      );
      navigation.navigate('Chat', { chatId: newChat.id, friendName: friend.username });
    }
  };

  const getButtonForUser = (u: User) => {
    if (friendIds.includes(u.id)) {
      return (
        <TouchableOpacity style={styles.messageBtn} onPress={() => handleStartChat(u)}>
          <Ionicons name="chatbubble-outline" size={18} color={colors.textWhite} />
          <Text style={styles.messageBtnText}>Message </Text>
        </TouchableOpacity>
      );
    }
    if (sentRequestUserIds.includes(u.id)) {
      return (
        <View style={styles.pendingBadge}>
          <Text style={styles.pendingBadgeText}>Pending </Text>
        </View>
      );
    }
    return (
      <TouchableOpacity style={styles.addBtn} onPress={() => handleSendRequest(u)}>
        <Ionicons name="person-add" size={18} color={colors.textWhite} />
        <Text style={styles.addBtnText}>Add </Text>
      </TouchableOpacity>
    );
  };

  const renderUserItem = ({ item }: { item: User }) => (
    <View style={styles.userCard}>
      <View style={styles.avatarCircle}>
        <Text style={styles.avatarLetter}>{item.username.charAt(0).toUpperCase()} </Text>
      </View>
      <View style={styles.userInfo}>
        <Text style={styles.username}>{item.username} </Text>
        <Text style={styles.userSub}>{item.country || item.email} </Text>
      </View>
      {getButtonForUser(item)}
    </View>
  );

  const renderRequestItem = ({ item }: { item: FriendRequest }) => (
    <View style={styles.userCard}>
      <View style={styles.avatarCircle}>
        <Text style={styles.avatarLetter}>{item.fromUsername.charAt(0).toUpperCase()} </Text>
      </View>
      <View style={styles.userInfo}>
        <Text style={styles.username}>{item.fromUsername} </Text>
        <Text style={styles.userSub}>Wants to be your friend </Text>
      </View>
      <View style={styles.requestActions}>
        <TouchableOpacity style={styles.acceptBtn} onPress={() => handleAccept(item)}>
          <Ionicons name="checkmark" size={20} color={colors.textWhite} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.rejectBtn} onPress={() => handleReject(item)}>
          <Ionicons name="close" size={20} color={colors.textWhite} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Search </Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tab, tab === 'search' && styles.tabActive]}
          onPress={() => setTab('search')}
        >
          <Text style={[styles.tabText, tab === 'search' && styles.tabTextActive]}>Find People </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, tab === 'requests' && styles.tabActive]}
          onPress={() => { setTab('requests'); loadRequests(); }}
        >
          <Text style={[styles.tabText, tab === 'requests' && styles.tabTextActive]}>
            Requests {receivedRequests.length > 0 ? `(${receivedRequests.length})` : ''}
           </Text>
        </TouchableOpacity>
      </View>

      {tab === 'search' && (
        <>
          {/* Search bar */}
          <View style={styles.searchBar}>
            <Ionicons name="search" size={20} color={colors.textPlaceholder} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search by username or email..."
              placeholderTextColor={colors.textPlaceholder}
              value={searchText}
              onChangeText={setSearchText}
              autoCapitalize="none"
            />
            {searchText.length > 0 && (
              <TouchableOpacity onPress={() => setSearchText('')}>
                <Ionicons name="close-circle" size={20} color={colors.textPlaceholder} />
              </TouchableOpacity>
            )}
          </View>

          {loading ? (
            <View style={common.loadingContainer}>
              <ActivityIndicator size="large" color={colors.primary} />
            </View>
          ) : (
            <FlatList
              data={filteredUsers}
              keyExtractor={(item) => item.id}
              renderItem={renderUserItem}
              contentContainerStyle={styles.list}
              ListEmptyComponent={
                <View style={styles.emptyState}>
                  <Ionicons name="people-outline" size={48} color={colors.textPlaceholder} />
                  <Text style={styles.emptyText}>
                    {searchText ? 'No users found' : 'No other users yet'}
                   </Text>
                </View>
              }
            />
          )}
        </>
      )}

      {tab === 'requests' && (
        loadingRequests ? (
          <View style={common.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : (
          <FlatList
            data={receivedRequests}
            keyExtractor={(item) => item.id}
            renderItem={renderRequestItem}
            contentContainerStyle={styles.list}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <Ionicons name="mail-open-outline" size={48} color={colors.textPlaceholder} />
                <Text style={styles.emptyText}>No pending requests </Text>
              </View>
            }
          />
        )
      )}

      <BottomNav navigation={navigation} active="Search" />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 54,
    paddingBottom: 12,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  backBtn: {
    padding: 4,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabActive: {
    borderBottomColor: colors.textDark,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textMuted,
  },
  tabTextActive: {
    color: colors.textDark,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgInputLight,
    margin: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: colors.textDark,
  },
  list: {
    paddingHorizontal: 12,
    paddingBottom: 20,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  avatarCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarLetter: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  userInfo: {
    flex: 1,
  },
  username: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textDark,
  },
  userSub: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addBtnText: {
    color: colors.textWhite,
    fontSize: 13,
    fontWeight: '600',
  },
  messageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.success,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  messageBtnText: {
    color: colors.textWhite,
    fontSize: 13,
    fontWeight: '600',
  },
  pendingBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: colors.bgInputLight,
    borderRadius: 8,
  },
  pendingBadgeText: {
    color: colors.textMuted,
    fontSize: 13,
    fontWeight: '600',
  },
  requestActions: {
    flexDirection: 'row',
    gap: 8,
  },
  acceptBtn: {
    backgroundColor: colors.success,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rejectBtn: {
    backgroundColor: colors.error,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 12,
  },
  emptyText: {
    fontSize: 15,
    color: colors.textPlaceholder,
  },
});
