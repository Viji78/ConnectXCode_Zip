import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  Alert,
  Image,
  Share,
  TextInput,
  Modal,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import { User, Post, Story } from '../types';
import { getPosts, likePost, unlikePost, addComment, deletePost } from '../services/posts';
import { getStories } from '../services/stories';
import { getReceivedRequests } from '../services/friends';
import { getChats } from '../services/messages';
import common, { colors } from '../styles/common';
import BottomNav from '../components/BottomNav';


interface Props {
  navigation: any;
  user: User;
}

const getTimeRemaining = (expiresAt: string): string => {
  const now = new Date().getTime();
  const expiry = new Date(expiresAt).getTime();
  const diff = expiry - now;
  if (diff <= 0) return 'Expiring soon';
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  if (hours > 0) return `${hours}h ${minutes}m remaining`;
  return `${minutes}m remaining`;
};

const getTimeAgo = (createdAt: string): string => {
  const now = new Date().getTime();
  const created = new Date(createdAt).getTime();
  const diff = now - created;
  const minutes = Math.floor(diff / (1000 * 60));
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

export default function FeedScreen({ navigation, user }: Props) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [requestCount, setRequestCount] = useState(0);
  const [messageCount, setMessageCount] = useState(0);
  const [commentModalPost, setCommentModalPost] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState('');
  const [sendingComment, setSendingComment] = useState(false);

  const loadRequestCount = async () => {
    try {
      const requests = await getReceivedRequests(user.id);
      setRequestCount(requests.length);
    } catch {}
  };

  const loadMessageCount = async () => {
    try {
      const chats = await getChats(user.id);
      const total = chats.reduce((sum, chat) => sum + (chat.unreadCount[user.id] || 0), 0);
      setMessageCount(total);
    } catch {}
  };

  useEffect(() => {
    loadFeed();
    loadRequestCount();
    loadMessageCount();
  }, []);

  // Reload request count and message count on screen focus
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadRequestCount();
      loadMessageCount();
      loadFeed();
    });
    return unsubscribe;
  }, [navigation]);

  const loadFeed = async () => {
    try {
      const fetchedPosts = await getPosts('public', user.id, user.friends);
      setPosts(fetchedPosts);
      try {
        const fetchedStories = await getStories();
        setStories(fetchedStories);
      } catch {
        setStories([]);
      }
    } catch (error) {
      console.error('Error loading feed:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadFeed();
    setRefreshing(false);
  };

  const handleLike = async (post: Post) => {
    const isLiked = post.likedBy?.includes(user.id);
    setPosts(prev => prev.map(p => {
      if (p.id === post.id) {
        const newLikedBy = isLiked
          ? p.likedBy.filter(id => id !== user.id)
          : [...p.likedBy, user.id];
        return {
          ...p,
          likes: newLikedBy.length,
          likedBy: newLikedBy
        };
      }
      return p;
    }));
    try {
      if (isLiked) {
        await unlikePost(post.id, user.id);
      } else {
        await likePost(post.id, user.id, user.username);
      }
    } catch {
      loadFeed();
    }
  };

  const handleComment = async () => {
    if (!commentText.trim() || !commentModalPost) return;
    setSendingComment(true);
    try {
      await addComment(commentModalPost.id, user.id, user.username, commentText.trim(), user.profileImage);
      // Update local state
      setPosts(prev => prev.map(p => {
        if (p.id === commentModalPost.id) {
          return {
            ...p,
            comments: [...p.comments, {
              id: Date.now().toString(),
              userId: user.id,
              username: user.username,
              profileImage: user.profileImage,
              content: commentText.trim(),
              createdAt: new Date().toISOString(),
            }],
          };
        }
        return p;
      }));
      setCommentText('');
    } catch {
      Alert.alert('Error', 'Failed to add comment');
    } finally {
      setSendingComment(false);
    }
  };

  const handleShare = async (post: Post) => {
    try {
      await Share.share({
        message: post.content
          ? `${post.username}: ${post.content}`
          : `Check out ${post.username}'s post on Learn & Chat!`,
      });
    } catch {}
  };

  const handleDownload = async (post: Post) => {
    if (!post.mediaUrl) {
      Alert.alert('Info', 'No image to download');
      return;
    }
    try {
      const fileUri = FileSystem.documentDirectory + `connectx_${Date.now()}.jpg`;

      if (post.mediaUrl.startsWith('data:')) {
        const base64Data = post.mediaUrl.split(',')[1];
        await FileSystem.writeAsStringAsync(fileUri, base64Data, {
          encoding: FileSystem.EncodingType.Base64,
        });
      } else {
        const download = await FileSystem.downloadAsync(post.mediaUrl, fileUri);
        // Move downloaded file to our target path if different
        if (download.uri !== fileUri) {
          await FileSystem.copyAsync({ from: download.uri, to: fileUri });
        }
      }

      await Sharing.shareAsync(fileUri, { mimeType: 'image/jpeg', dialogTitle: 'Save Image' });
    } catch {
      Alert.alert('Error', 'Failed to download image');
    }
  };

  const handleCreateStory = () => {
    Alert.alert('Create Story', 'Story feature coming soon.', [{ text: 'OK' }]);
  };

  const groupStoriesByUser = () => {
    const grouped: { [userId: string]: Story[] } = {};
    stories.forEach(story => {
      if (!grouped[story.userId]) grouped[story.userId] = [];
      grouped[story.userId].push(story);
    });
    return Object.values(grouped).map(s => s[0]);
  };

  const handleDeletePost = (post: Post) => {
    Alert.alert('Delete Post', 'Delete this post permanently?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deletePost(post.id);
            setPosts(prev => prev.filter(p => p.id !== post.id));
          } catch {
            Alert.alert('Error', 'Failed to delete post');
          }
        },
      },
    ]);
  };

  const renderPost = ({ item }: { item: Post }) => {
    const isLiked = item.likedBy?.includes(user.id);

    return (
      <View style={styles.postCard}>
        {/* Header - avatar, name, time, menu */}
        <View style={styles.postHeader}>
          <View style={styles.postUserInfo}>
            {item.profileImage && item.profileImage.length > 2 ? (
              <Image source={{ uri: item.profileImage }} style={styles.avatarImage} />
            ) : (
              <View style={styles.avatarCircle}>
                <Text style={styles.avatarLetter}>
                  {item.username.charAt(0).toUpperCase()}
                 </Text>
              </View>
            )}
            <View>
              <Text style={styles.postUsername}>{item.username} </Text>
              <View style={styles.postMetaRow}>
                <Text style={styles.postTime}>{getTimeAgo(item.createdAt)} </Text>
                {item.expiresAt ? (
                  <Text style={styles.expiryText}> · ⏳ {getTimeRemaining(item.expiresAt)} </Text>
                ) : null}
              </View>
            </View>
          </View>
          {user.user_role === 'Admin' && (
            <TouchableOpacity onPress={() => handleDeletePost(item)}>
              <Ionicons name="trash-outline" size={20} color={colors.error} />
            </TouchableOpacity>
          )}
        </View>

        {/* Image */}
        {item.type === 'image' && item.mediaUrl && (
          <Image
            source={{ uri: item.mediaUrl }}
            style={styles.postImage}
            resizeMode="contain"
          />
        )}

        {/* Text-only post (no image) */}
        {item.type === 'text' && item.content ? (
          <View style={styles.textPostContent}>
            <Text style={styles.textPostText}>{item.content} </Text>
          </View>
        ) : null}

        {/* Action buttons row */}
        <View style={styles.actionsRow}>
          <View style={styles.actionsLeft}>
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleLike(item)}>
              <Ionicons
                name={isLiked ? 'heart' : 'heart-outline'}
                size={26}
                color={isLiked ? '#EF4444' : colors.textDark}
              />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionBtn} onPress={() => setCommentModalPost(item)}>
              <Ionicons name="chatbubble-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleShare(item)}>
              <Ionicons name="paper-plane-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
          </View>
          {item.type === 'image' && item.mediaUrl && (
            <TouchableOpacity style={styles.actionBtn} onPress={() => handleDownload(item)}>
              <Ionicons name="download-outline" size={24} color={colors.textDark} />
            </TouchableOpacity>
          )}
        </View>

        {/* Likes count */}
        {item.likes > 0 && (
          <Text style={styles.likesText}>
            {item.likes} {item.likes === 1 ? 'like' : 'likes'}
           </Text>
        )}

        {/* Caption */}
        {item.content ? (
          <View style={styles.captionRow}>
            <Text style={styles.captionUsername}>{item.username} </Text>
            <Text style={styles.captionText}> {item.content} </Text>
          </View>
        ) : null}

        {/* Comments count */}
        {item.comments.length > 0 && (
          <TouchableOpacity onPress={() => setCommentModalPost(item)}>
            <Text style={styles.viewComments}>
              View all {item.comments.length} comments
             </Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  const ListHeaderComponent = () => (
    <View style={styles.storiesContainer}>
      <View style={styles.storiesScrollContainer}>
        <TouchableOpacity style={styles.addStoryCircle} onPress={handleCreateStory}>
          <View style={styles.addStoryButton}>
            <Ionicons name="add" size={28} color={colors.textWhite} />
          </View>
          <Text style={styles.storyUsername}>Your Story </Text>
        </TouchableOpacity>
        {groupStoriesByUser().map((story) => (
          <TouchableOpacity key={story.id} style={styles.storyCircle}>
            <View style={styles.storyRing}>
              <View style={styles.storyAvatar}>
                <Text style={styles.storyAvatarText}>
                  {story.username.charAt(0).toUpperCase()}
                 </Text>
              </View>
            </View>
            <Text style={styles.storyUsername} numberOfLines={1}>{story.username} </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={common.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={common.loadingText}>Loading feed... </Text>
      </View>
    );
  }

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.logo}>Learn & Chat </Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Search', { openTab: 'requests' })}
          >
            <Ionicons name="notifications-outline" size={24} color={colors.textDark} />
            {requestCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{requestCount} </Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Messages')}
          >
            <Ionicons name="chatbubble-outline" size={24} color={colors.textDark} />
            {messageCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{messageCount} </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Feed */}
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={renderPost}
        ListHeaderComponent={ListHeaderComponent}
        contentContainerStyle={styles.feedList}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
        }
        ListEmptyComponent={
          <View style={common.emptyContainer}>
            <Text style={common.emptyIcon}>📱 </Text>
            <Text style={common.emptyTitle}>No posts yet </Text>
            <Text style={common.emptyText}>Be the first to share something! </Text>
            <TouchableOpacity style={common.buttonPrimary} onPress={() => navigation.navigate('CreatePost')}>
              <Text style={common.buttonPrimaryText}>Create Post </Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* Comment Modal */}
      <Modal
        visible={commentModalPost !== null}
        animationType="slide"
        transparent
        onRequestClose={() => { setCommentModalPost(null); setCommentText(''); }}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.commentModalOverlay}
        >
          <TouchableOpacity
            style={styles.commentModalDismiss}
            activeOpacity={1}
            onPress={() => { setCommentModalPost(null); setCommentText(''); }}
          />
          <View style={styles.commentModalContent}>
            {/* Modal Header */}
            <View style={styles.commentModalHeader}>
              <Text style={styles.commentModalTitle}>Comments </Text>
              <TouchableOpacity onPress={() => { setCommentModalPost(null); setCommentText(''); }}>
                <Ionicons name="close" size={24} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            {/* Comments List */}
            <ScrollView style={styles.commentsList} showsVerticalScrollIndicator={false}>
              {commentModalPost?.comments.length === 0 && (
                <View style={styles.noComments}>
                  <Ionicons name="chatbubble-outline" size={40} color={colors.textPlaceholder} />
                  <Text style={styles.noCommentsText}>No comments yet </Text>
                  <Text style={styles.noCommentsSubtext}>Be the first to comment! </Text>
                </View>
              )}
              {commentModalPost?.comments.map((c) => (
                <View key={c.id} style={styles.commentItem}>
                  {c.profileImage && c.profileImage.length > 2 ? (
                    <Image source={{ uri: c.profileImage }} style={styles.commentAvatar} />
                  ) : (
                    <View style={styles.commentAvatarPlaceholder}>
                      <Text style={styles.commentAvatarLetter}>
                        {c.username.charAt(0).toUpperCase()}
                       </Text>
                    </View>
                  )}
                  <View style={styles.commentBody}>
                    <Text style={styles.commentUsername}>{c.username} </Text>
                    <Text style={styles.commentContent}>{c.content} </Text>
                  </View>
                </View>
              ))}
            </ScrollView>

            {/* Comment Input */}
            <View style={styles.commentInputRow}>
              <TextInput
                style={styles.commentInput}
                placeholder="Add a comment..."
                placeholderTextColor={colors.textPlaceholder}
                value={commentText}
                onChangeText={setCommentText}
                multiline
                maxLength={500}
              />
              <TouchableOpacity
                style={[styles.commentSendBtn, !commentText.trim() && styles.commentSendBtnDisabled]}
                onPress={handleComment}
                disabled={!commentText.trim() || sendingComment}
              >
                <Ionicons
                  name="send"
                  size={20}
                  color={commentText.trim() ? colors.primary : colors.textPlaceholder}
                />
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <BottomNav navigation={navigation} active="Feed" />
    </View>
  );
}

const styles = StyleSheet.create({
  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
    paddingTop: 50,
  },
  backBtn: {
    padding: 4,
    marginRight: 10,
  },
  logo: {
    fontSize: 26,
    fontWeight: 'bold',
    color: colors.textDark,
    fontStyle: 'italic',
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 18,
  },
  headerButton: {
    padding: 4,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -6,
    backgroundColor: colors.error,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: colors.textWhite,
    fontSize: 11,
    fontWeight: 'bold',
  },

  // Stories
  storiesContainer: {
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
    paddingVertical: 10,
  },
  storiesScrollContainer: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    gap: 14,
  },
  addStoryCircle: {
    alignItems: 'center',
    width: 68,
  },
  addStoryButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  storyCircle: {
    alignItems: 'center',
    width: 68,
  },
  storyRing: {
    padding: 2,
    borderRadius: 34,
    borderWidth: 2.5,
    borderColor: '#E1306C',
    marginBottom: 4,
  },
  storyAvatar: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.bgWhite,
  },
  storyAvatarText: {
    fontSize: 22,
    fontWeight: '600',
    color: colors.textBody,
  },
  storyUsername: {
    fontSize: 11,
    color: colors.textBody,
    textAlign: 'center',
    width: 68,
  },

  // Feed
  feedList: {
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 16,
  },

  // Post Card
  postCard: {
    backgroundColor: colors.bgWhite,
    borderRadius: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: colors.bgDark,
    overflow: 'hidden',
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingTop: 14,
    paddingBottom: 10,
  },
  postUserInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  avatarImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
  },
  avatarLetter: {
    fontSize: 17,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  postUsername: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textDark,
  },
  postMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 1,
  },
  postTime: {
    fontSize: 12,
    color: colors.textPlaceholder,
  },
  expiryText: {
    fontSize: 11,
    color: colors.textPlaceholder,
  },

  // Post image
  postImage: {
    width: '100%',
    aspectRatio: 1,
    backgroundColor: colors.bgInputLight,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.bgDark,
  },

  // Text-only post content
  textPostContent: {
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  textPostText: {
    fontSize: 16,
    lineHeight: 23,
    color: colors.textDark,
  },

  // Action buttons
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 6,
  },
  actionsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
  },
  actionBtn: {
    padding: 4,
  },

  // Likes
  likesText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textDark,
    paddingHorizontal: 14,
    marginBottom: 4,
  },

  // Caption
  captionRow: {
    flexDirection: 'row',
    paddingHorizontal: 14,
    marginBottom: 6,
    flexWrap: 'wrap',
  },
  captionUsername: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textDark,
  },
  captionText: {
    fontSize: 14,
    color: colors.textBody,
    lineHeight: 20,
    flexShrink: 1,
  },

  // Comments
  viewComments: {
    fontSize: 13,
    color: colors.textPlaceholder,
    paddingHorizontal: 14,
    paddingBottom: 12,
  },

  // Comment Modal
  commentModalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  commentModalDismiss: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  commentModalContent: {
    backgroundColor: colors.bgWhite,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '70%',
    minHeight: '40%',
  },
  commentModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  commentModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  commentsList: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  noComments: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  noCommentsText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textMuted,
    marginTop: 10,
  },
  noCommentsSubtext: {
    fontSize: 13,
    color: colors.textPlaceholder,
    marginTop: 4,
  },
  commentItem: {
    flexDirection: 'row',
    marginBottom: 14,
  },
  commentAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 10,
  },
  commentAvatarPlaceholder: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  commentAvatarLetter: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  commentBody: {
    flex: 1,
  },
  commentUsername: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textDark,
    marginBottom: 2,
  },
  commentContent: {
    fontSize: 14,
    color: colors.textBody,
    lineHeight: 20,
  },
  commentInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    paddingBottom: 28,
    borderTopWidth: 0.5,
    borderTopColor: colors.borderLight,
    gap: 10,
  },
  commentInput: {
    flex: 1,
    backgroundColor: colors.bgInputLight,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.textDark,
    maxHeight: 80,
  },
  commentSendBtn: {
    padding: 8,
  },
  commentSendBtnDisabled: {
    opacity: 0.5,
  },
});
