import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
  ActivityIndicator,
  TextInput,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { User } from '../types';
import { getAllUsersAdmin, deleteUserCompletely } from '../services/users';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  user: User;
}

export default function UserManagementScreen({ navigation, user }: Props) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', loadUsers);
    return unsubscribe;
  }, [navigation]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await getAllUsersAdmin();
      setUsers(data);
    } catch {
      setUsers([]);
    }
    setLoading(false);
  };

  const handleDelete = (u: User) => {
    if (u.user_role === 'Admin') {
      Alert.alert('Cannot Delete', 'Admin account cannot be deleted.');
      return;
    }

    Alert.alert(
      'Delete User',
      `Permanently delete "${u.username}" and all their data (posts, chats, friend requests)?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setDeleting(u.id);
            try {
              await deleteUserCompletely(u.id);
              setUsers(prev => prev.filter(p => p.id !== u.id));
              Alert.alert('Deleted', `"${u.username}" has been removed.`);
            } catch {
              Alert.alert('Error', 'Failed to delete user');
            }
            setDeleting(null);
          },
        },
      ]
    );
  };

  const filtered = users.filter(u =>
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const studentCount = users.filter(u => u.user_role === 'Student').length;

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Users </Text>
        <TouchableOpacity onPress={loadUsers} style={styles.refreshBtn}>
          <Ionicons name="refresh-outline" size={22} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{users.length} </Text>
          <Text style={styles.statLabel}>Total </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{studentCount} </Text>
          <Text style={styles.statLabel}>Students </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{users.length - studentCount} </Text>
          <Text style={styles.statLabel}>Admins </Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Ionicons name="search-outline" size={18} color={colors.textPlaceholder} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search users..."
          placeholderTextColor={colors.textPlaceholder}
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color={colors.textPlaceholder} />
          </TouchableOpacity>
        )}
      </View>

      {/* User List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.userCard}
              onPress={() => navigation.navigate('UserDetail', { userId: item.id })}
              activeOpacity={0.7}
            >
              {item.profileImage && item.profileImage.length > 2 ? (
                <Image source={{ uri: item.profileImage }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatarPlaceholder, item.user_role === 'Admin' && { backgroundColor: colors.primary }]}>
                  <Text style={styles.avatarLetter}>
                    {item.username.charAt(0).toUpperCase()}
                   </Text>
                </View>
              )}
              <View style={styles.userInfo}>
                <View style={styles.nameRow}>
                  <Text style={styles.username} numberOfLines={1}>{item.username} </Text>
                  <View style={[styles.roleBadge, item.user_role === 'Admin' ? styles.roleBadgeAdmin : styles.roleBadgeStudent]}>
                    <Text style={styles.roleBadgeText}>{item.user_role} </Text>
                  </View>
                </View>
                <Text style={styles.email} numberOfLines={1}>{item.email} </Text>
                <Text style={styles.meta}>
                  {item.friends.length} friends · Joined {new Date(item.createdAt).toLocaleDateString()}
                 </Text>
              </View>

              <Ionicons name="chevron-forward" size={20} color={colors.textPlaceholder} />
            </TouchableOpacity>
          )}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="people-outline" size={48} color={colors.textPlaceholder} />
              <Text style={styles.emptyText}>No users found </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 52,
    paddingBottom: 12,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  backBtn: { padding: 4, marginRight: 10 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: colors.textDark, flex: 1 },
  refreshBtn: { padding: 4 },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 10,
  },
  statBox: {
    flex: 1,
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  statNumber: { fontSize: 20, fontWeight: 'bold', color: colors.primary },
  statLabel: { fontSize: 11, color: colors.textMuted, marginTop: 2 },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 10,
    backgroundColor: colors.bgInputLight,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 42,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 15, color: colors.textDark },
  list: { paddingHorizontal: 16, paddingBottom: 32 },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 14,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    marginRight: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  avatarPlaceholder: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarLetter: { fontSize: 18, fontWeight: 'bold', color: colors.textWhite },
  userInfo: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  username: { fontSize: 15, fontWeight: '700', color: colors.textDark, flexShrink: 1 },
  roleBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 2 },
  roleBadgeAdmin: { backgroundColor: colors.primary + '20' },
  roleBadgeStudent: { backgroundColor: colors.bgInputLight },
  roleBadgeText: { fontSize: 10, fontWeight: '700', color: colors.textMuted },
  email: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  meta: { fontSize: 11, color: colors.textPlaceholder, marginTop: 2 },
  deleteBtn: { padding: 8 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyContainer: { alignItems: 'center', paddingVertical: 48 },
  emptyText: { fontSize: 14, color: colors.textPlaceholder, marginTop: 10 },
});
