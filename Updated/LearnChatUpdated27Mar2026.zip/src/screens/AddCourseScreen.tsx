import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  TextInput,
  Alert,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { User } from '../types';
import { Course, Lesson, LessonStep } from '../data/courses';
import {
  createCourse,
  getCustomCourses,
  updateCourse,
  deleteCourse,
  addLessonToCourse,
  updateLessonInCourse,
  deleteLessonFromCourse,
  seedDefaultCourses,
  courseIcons,
  courseColors,
} from '../services/courseCreator';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  user: User;
}

export default function AddCourseScreen({ navigation, user }: Props) {
  const [customCourses, setCustomCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Modal states
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [showLessonModal, setShowLessonModal] = useState(false);
  const [showStepModal, setShowStepModal] = useState(false);

  // New/Edit course form
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);
  const [courseTitle, setCourseTitle] = useState('');
  const [courseDesc, setCourseDesc] = useState('');
  const [courseIcon, setCourseIcon] = useState('code-slash');
  const [courseColor, setCourseColor] = useState('#E44D26');

  // Lesson form
  const [editingLessonId, setEditingLessonId] = useState<string | null>(null);
  const [targetCourseId, setTargetCourseId] = useState('');
  const [targetCourseIsCustom, setTargetCourseIsCustom] = useState(true);
  const [lessonTitle, setLessonTitle] = useState('');
  const [lessonDuration, setLessonDuration] = useState('');
  const [lessonSteps, setLessonSteps] = useState<LessonStep[]>([]);

  // Step form
  const [editingStepIndex, setEditingStepIndex] = useState<number | null>(null);
  const [stepTitle, setStepTitle] = useState('');
  const [stepExplanation, setStepExplanation] = useState('');
  const [stepCode, setStepCode] = useState('');
  const [stepOutput, setStepOutput] = useState('');
  const [stepTip, setStepTip] = useState('');

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    setLoading(true);
    try {
      await seedDefaultCourses();
      const data = await getCustomCourses();
      setCustomCourses(data);
    } catch {}
    setLoading(false);
  };

  // ---- Create / Update Course ----
  const handleSaveCourse = async () => {
    if (!courseTitle.trim()) {
      Alert.alert('Error', 'Please enter a course title');
      return;
    }
    setSaving(true);
    try {
      if (editingCourseId) {
        // Update existing
        await updateCourse(editingCourseId, {
          title: courseTitle.trim(),
          icon: courseIcon,
          color: courseColor,
          description: courseDesc.trim() || `Learn ${courseTitle.trim()}`,
        });
        setCustomCourses(prev =>
          prev.map(c =>
            c.id === editingCourseId
              ? { ...c, title: courseTitle.trim(), icon: courseIcon, color: courseColor, description: courseDesc.trim() || c.description }
              : c
          )
        );
        Alert.alert('Updated', `"${courseTitle}" updated!`);
      } else {
        // Create new
        const newCourse = await createCourse({
          title: courseTitle.trim(),
          icon: courseIcon,
          color: courseColor,
          description: courseDesc.trim() || `Learn ${courseTitle.trim()}`,
          lessons: [],
        });
        setCustomCourses(prev => [...prev, newCourse]);
        Alert.alert('Success', `"${courseTitle}" course created!`);
      }
      setShowCourseModal(false);
      setEditingCourseId(null);
      setCourseTitle('');
      setCourseDesc('');
    } catch (e: any) {
      console.log('Save course error:', e);
      Alert.alert('Error', e.message || e.code || 'Failed to save course');
    }
    setSaving(false);
  };

  // ---- Open Edit Course ----
  const openEditCourse = (course: Course) => {
    setEditingCourseId(course.id);
    setCourseTitle(course.title);
    setCourseDesc(course.description);
    setCourseIcon(course.icon);
    setCourseColor(course.color);
    setShowCourseModal(true);
  };

  // ---- Open New Course ----
  const openNewCourse = () => {
    setEditingCourseId(null);
    setCourseTitle('');
    setCourseDesc('');
    setCourseIcon('code-slash');
    setCourseColor('#E44D26');
    setShowCourseModal(true);
  };

  // ---- Delete Course ----
  const handleDeleteCourse = (course: Course) => {
    Alert.alert('Delete Course', `Delete "${course.title}" and all its lessons?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteCourse(course.id);
            setCustomCourses(prev => prev.filter(c => c.id !== course.id));
          } catch {
            Alert.alert('Error', 'Failed to delete course');
          }
        },
      },
    ]);
  };

  // ---- Open Lesson Modal (New) ----
  const openAddLesson = (courseId: string, isCustom: boolean) => {
    setEditingLessonId(null);
    setTargetCourseId(courseId);
    setTargetCourseIsCustom(isCustom);
    setLessonTitle('');
    setLessonDuration('5 min');
    setLessonSteps([]);
    setShowLessonModal(true);
  };

  // ---- Open Lesson Modal (Edit) ----
  const openEditLesson = (courseId: string, lesson: Lesson) => {
    setEditingLessonId(lesson.id);
    setTargetCourseId(courseId);
    setTargetCourseIsCustom(true);
    setLessonTitle(lesson.title);
    setLessonDuration(lesson.duration);
    setLessonSteps([...lesson.steps]);
    setShowLessonModal(true);
  };

  // ---- Add Step ----
  const openAddStep = () => {
    setEditingStepIndex(null);
    setStepTitle('');
    setStepExplanation('');
    setStepCode('');
    setStepOutput('');
    setStepTip('');
    setShowStepModal(true);
  };

  // ---- Edit Step ----
  const openEditStep = (index: number) => {
    const step = lessonSteps[index];
    setEditingStepIndex(index);
    setStepTitle(step.title);
    setStepExplanation(step.explanation);
    setStepCode(step.code || '');
    setStepOutput(step.output || '');
    setStepTip(step.tip || '');
    setShowStepModal(true);
  };

  const handleSaveStep = () => {
    if (!stepTitle.trim() || !stepExplanation.trim()) {
      Alert.alert('Error', 'Title and explanation are required');
      return;
    }
    const step: LessonStep = {
      title: stepTitle.trim(),
      explanation: stepExplanation.trim(),
    };
    if (stepCode.trim()) step.code = stepCode.trim();
    if (stepOutput.trim()) step.output = stepOutput.trim();
    if (stepTip.trim()) step.tip = stepTip.trim();

    if (editingStepIndex !== null) {
      // Update existing step
      setLessonSteps(prev => prev.map((s, i) => i === editingStepIndex ? step : s));
    } else {
      // Add new step
      setLessonSteps(prev => [...prev, step]);
    }
    setEditingStepIndex(null);
    setShowStepModal(false);
  };

  const handleRemoveStep = (index: number) => {
    setLessonSteps(prev => prev.filter((_, i) => i !== index));
  };

  // ---- Save Lesson ----
  const handleSaveLesson = async () => {
    if (!lessonTitle.trim()) {
      Alert.alert('Error', 'Please enter a lesson title');
      return;
    }
    if (lessonSteps.length === 0) {
      Alert.alert('Error', 'Please add at least one step');
      return;
    }

    setSaving(true);
    try {
      if (editingLessonId) {
        // Update existing lesson
        const updatedLesson: Lesson = {
          id: editingLessonId,
          title: lessonTitle.trim(),
          duration: lessonDuration.trim() || '5 min',
          steps: lessonSteps,
        };
        await updateLessonInCourse(targetCourseId, updatedLesson);
        setCustomCourses(prev =>
          prev.map(c =>
            c.id === targetCourseId
              ? { ...c, lessons: c.lessons.map(l => l.id === editingLessonId ? updatedLesson : l) }
              : c
          )
        );
        Alert.alert('Updated', `Lesson "${lessonTitle}" updated!`);
      } else {
        // Create new lesson
        const lesson: Lesson = {
          id: `${targetCourseId}-${Date.now()}`,
          title: lessonTitle.trim(),
          duration: lessonDuration.trim() || '5 min',
          steps: lessonSteps,
        };
        await addLessonToCourse(targetCourseId, lesson);
        setCustomCourses(prev =>
          prev.map(c =>
            c.id === targetCourseId
              ? { ...c, lessons: [...c.lessons, lesson] }
              : c
          )
        );
        Alert.alert('Success', `Lesson "${lessonTitle}" added!`);
      }
      setShowLessonModal(false);
      setEditingLessonId(null);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to add lesson');
    }
    setSaving(false);
  };

  // ---- Delete Lesson ----
  const handleDeleteLesson = (courseId: string, lessonId: string, lessonTitle: string) => {
    Alert.alert('Delete Lesson', `Delete "${lessonTitle}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteLessonFromCourse(courseId, lessonId);
            setCustomCourses(prev =>
              prev.map(c =>
                c.id === courseId
                  ? { ...c, lessons: c.lessons.filter(l => l.id !== lessonId) }
                  : c
              )
            );
          } catch {
            Alert.alert('Error', 'Failed to delete lesson');
          }
        },
      },
    ]);
  };

  const allCourses = customCourses;

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add Text Course </Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Action Buttons */}
      <View style={styles.actionsRow}>
        <TouchableOpacity style={styles.actionBtn} onPress={openNewCourse}>
          <Ionicons name="add-circle-outline" size={20} color={colors.textWhite} />
          <Text style={styles.actionBtnText}>New Course </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.actionBtn, styles.actionBtnSecondary]}
          onPress={() => {
            if (allCourses.length === 0) {
              Alert.alert('No courses', 'Create a course first');
              return;
            }
            // Default to first custom course, or first static
            const defaultId = customCourses[0].id;
            const isCustom = customCourses.some(c => c.id === defaultId);
            openAddLesson(defaultId, isCustom);
          }}
        >
          <Ionicons name="document-text-outline" size={20} color={colors.primary} />
          <Text style={[styles.actionBtnText, { color: colors.primary }]}>Add Lesson </Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
          {/* Custom Courses */}
          {customCourses.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>All Courses ({customCourses.length}) </Text>
              {customCourses.map(course => (
                <View key={course.id} style={styles.courseCard}>
                  <View style={styles.courseCardHeader}>
                    <View style={[styles.courseIconBox, { backgroundColor: course.color + '18' }]}>
                      <Ionicons name={course.icon as any} size={24} color={course.color} />
                    </View>
                    <View style={styles.courseCardInfo}>
                      <Text style={styles.courseCardTitle}>{course.title} </Text>
                      <Text style={styles.courseCardMeta}>
                        {(course.lessons || []).length} lessons · {course.description}
                       </Text>
                    </View>
                    <TouchableOpacity onPress={() => openEditCourse(course)} style={{ marginRight: 10 }}>
                      <Ionicons name="create-outline" size={20} color={colors.primary} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => handleDeleteCourse(course)}>
                      <Ionicons name="trash-outline" size={20} color={colors.error} />
                    </TouchableOpacity>
                  </View>

                  {/* Lessons */}
                  {(course.lessons || []).map((lesson) => (
                    <View key={lesson.id} style={styles.lessonRow}>
                      <View style={styles.lessonDot} />
                      <Text style={styles.lessonRowTitle} numberOfLines={1}>{lesson.title} </Text>
                      <Text style={styles.lessonRowMeta}>{lesson.steps.length} steps </Text>
                      <TouchableOpacity onPress={() => openEditLesson(course.id, lesson)} style={{ marginRight: 6 }}>
                        <Ionicons name="create-outline" size={18} color={colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleDeleteLesson(course.id, lesson.id, lesson.title)}>
                        <Ionicons name="close-circle-outline" size={18} color={colors.error} />
                      </TouchableOpacity>
                    </View>
                  ))}

                  <TouchableOpacity
                    style={styles.addLessonBtn}
                    onPress={() => openAddLesson(course.id, true)}
                  >
                    <Ionicons name="add" size={18} color={colors.primary} />
                    <Text style={styles.addLessonBtnText}>Add Lesson </Text>
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}


          {customCourses.length === 0 && (
            <View style={styles.emptyContainer}>
              <Ionicons name="book-outline" size={48} color={colors.textPlaceholder} />
              <Text style={styles.emptyTitle}>No courses yet </Text>
              <Text style={styles.emptyText}>Loading courses or tap "New Course" to create one </Text>
            </View>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      )}

      {/* ===== Create Course Modal ===== */}
      <Modal visible={showCourseModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingCourseId ? 'Edit Course' : 'New Course'} </Text>
              <TouchableOpacity onPress={() => { setShowCourseModal(false); setEditingCourseId(null); }}>
                <Ionicons name="close" size={24} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.formLabel}>Course Title * </Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. TypeScript, Docker, Git..."
                placeholderTextColor={colors.textPlaceholder}
                value={courseTitle}
                onChangeText={setCourseTitle}
              />

              <Text style={styles.formLabel}>Description </Text>
              <TextInput
                style={styles.input}
                placeholder="Brief description..."
                placeholderTextColor={colors.textPlaceholder}
                value={courseDesc}
                onChangeText={setCourseDesc}
              />

              <Text style={styles.formLabel}>Icon </Text>
              <View style={styles.iconGrid}>
                {courseIcons.map(item => (
                  <TouchableOpacity
                    key={item.icon}
                    style={[styles.iconOption, courseIcon === item.icon && { backgroundColor: courseColor + '20', borderColor: courseColor }]}
                    onPress={() => setCourseIcon(item.icon)}
                  >
                    <Ionicons name={item.icon as any} size={22} color={courseIcon === item.icon ? courseColor : colors.textMuted} />
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.formLabel}>Color </Text>
              <View style={styles.colorGrid}>
                {courseColors.map(c => (
                  <TouchableOpacity
                    key={c}
                    style={[styles.colorOption, { backgroundColor: c }, courseColor === c && styles.colorOptionActive]}
                    onPress={() => setCourseColor(c)}
                  />
                ))}
              </View>

              <TouchableOpacity
                style={[styles.submitBtn, (!courseTitle.trim() || saving) && styles.submitBtnDisabled]}
                onPress={handleSaveCourse}
                disabled={!courseTitle.trim() || saving}
              >
                {saving ? <ActivityIndicator size="small" color={colors.textWhite} /> : null}
                <Text style={styles.submitBtnText}>{saving ? 'Saving...' : editingCourseId ? 'Update Course' : 'Create Course'} </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* ===== Add Lesson Modal ===== */}
      <Modal visible={showLessonModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '90%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingLessonId ? 'Edit Lesson' : 'Add Lesson'} </Text>
              <TouchableOpacity onPress={() => { setShowLessonModal(false); setEditingLessonId(null); }}>
                <Ionicons name="close" size={24} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Course Selector */}
              <Text style={styles.formLabel}>To Course </Text>
              <View style={styles.courseChips}>
                {allCourses.map(c => (
                  <TouchableOpacity
                    key={c.id}
                    style={[styles.courseChip, targetCourseId === c.id && { backgroundColor: c.color, borderColor: c.color }]}
                    onPress={() => {
                      setTargetCourseId(c.id);
                      setTargetCourseIsCustom(customCourses.some(cc => cc.id === c.id));
                    }}
                  >
                    <Text style={[styles.courseChipText, targetCourseId === c.id && { color: colors.textWhite }]} numberOfLines={1}>
                      {c.title}
                     </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.formLabel}>Lesson Title * </Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. Variables & Types"
                placeholderTextColor={colors.textPlaceholder}
                value={lessonTitle}
                onChangeText={setLessonTitle}
              />

              <Text style={styles.formLabel}>Duration </Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. 5 min"
                placeholderTextColor={colors.textPlaceholder}
                value={lessonDuration}
                onChangeText={setLessonDuration}
              />

              {/* Steps */}
              <View style={styles.stepsHeader}>
                <Text style={styles.formLabel}>Steps ({lessonSteps.length}) </Text>
                <TouchableOpacity style={styles.addStepBtn} onPress={openAddStep}>
                  <Ionicons name="add" size={18} color={colors.primary} />
                  <Text style={styles.addStepBtnText}>Add Step </Text>
                </TouchableOpacity>
              </View>

              {lessonSteps.map((step, i) => (
                <View key={i} style={styles.stepPreview}>
                  <View style={styles.stepPreviewHeader}>
                    <Text style={styles.stepPreviewNum}>Step {i + 1} </Text>
                    <View style={{ flexDirection: 'row', gap: 8 }}>
                      <TouchableOpacity onPress={() => openEditStep(i)}>
                        <Ionicons name="create-outline" size={18} color={colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleRemoveStep(i)}>
                        <Ionicons name="close-circle" size={18} color={colors.error} />
                      </TouchableOpacity>
                    </View>
                  </View>
                  <Text style={styles.stepPreviewTitle}>{step.title} </Text>
                  <Text style={styles.stepPreviewDesc} numberOfLines={2}>{step.explanation} </Text>
                  {step.code ? <Text style={styles.stepPreviewTag}>Has code </Text> : null}
                </View>
              ))}

              {lessonSteps.length === 0 && (
                <View style={styles.noSteps}>
                  <Text style={styles.noStepsText}>No steps yet. Add at least one step. </Text>
                </View>
              )}

              <TouchableOpacity
                style={[styles.submitBtn, { backgroundColor: colors.success }, (!lessonTitle.trim() || lessonSteps.length === 0 || saving) && styles.submitBtnDisabled]}
                onPress={handleSaveLesson}
                disabled={!lessonTitle.trim() || lessonSteps.length === 0 || saving}
              >
                {saving ? <ActivityIndicator size="small" color={colors.textWhite} /> : null}
                <Text style={styles.submitBtnText}>{saving ? 'Saving...' : editingLessonId ? 'Update Lesson' : 'Save Lesson'} </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* ===== Add Step Modal ===== */}
      <Modal visible={showStepModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '90%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editingStepIndex !== null ? 'Edit Step' : 'Add Step'} </Text>
              <TouchableOpacity onPress={() => { setShowStepModal(false); setEditingStepIndex(null); }}>
                <Ionicons name="close" size={24} color={colors.textDark} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.formLabel}>Step Title * </Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. What is HTML?"
                placeholderTextColor={colors.textPlaceholder}
                value={stepTitle}
                onChangeText={setStepTitle}
              />

              <Text style={styles.formLabel}>Explanation * </Text>
              <TextInput
                style={[styles.input, styles.inputMultiline]}
                placeholder="Explain the concept..."
                placeholderTextColor={colors.textPlaceholder}
                value={stepExplanation}
                onChangeText={setStepExplanation}
                multiline
              />

              <Text style={styles.formLabel}>Code Example (optional) </Text>
              <TextInput
                style={[styles.input, styles.inputCode]}
                placeholder="const x = 42;"
                placeholderTextColor={colors.textPlaceholder}
                value={stepCode}
                onChangeText={setStepCode}
                multiline
              />

              <Text style={styles.formLabel}>Output (optional) </Text>
              <TextInput
                style={styles.input}
                placeholder="Expected output..."
                placeholderTextColor={colors.textPlaceholder}
                value={stepOutput}
                onChangeText={setStepOutput}
              />

              <Text style={styles.formLabel}>Tip (optional) </Text>
              <TextInput
                style={styles.input}
                placeholder="Helpful tip..."
                placeholderTextColor={colors.textPlaceholder}
                value={stepTip}
                onChangeText={setStepTip}
              />

              <TouchableOpacity
                style={[styles.submitBtn, (!stepTitle.trim() || !stepExplanation.trim()) && styles.submitBtnDisabled]}
                onPress={handleSaveStep}
                disabled={!stepTitle.trim() || !stepExplanation.trim()}
              >
                <Text style={styles.submitBtnText}>{editingStepIndex !== null ? 'Update Step' : 'Add Step'} </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12, backgroundColor: colors.bgWhite, borderBottomWidth: 0.5, borderBottomColor: colors.borderLight },
  backBtn: { padding: 4, marginRight: 10 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: colors.textDark, flex: 1 },
  actionsRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 12 },
  actionBtnSecondary: { backgroundColor: colors.bgWhite, borderWidth: 1.5, borderColor: colors.primary },
  actionBtnText: { fontSize: 14, fontWeight: '700', color: colors.textWhite },
  scroll: { flex: 1, paddingHorizontal: 16 },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: colors.textDark, marginBottom: 4 },
  sectionSubtitle: { fontSize: 12, color: colors.textMuted, marginBottom: 10 },
  courseCard: { backgroundColor: colors.bgWhite, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.borderLight },
  courseCardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  courseIconBox: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  courseCardInfo: { flex: 1 },
  courseCardTitle: { fontSize: 16, fontWeight: '700', color: colors.textDark },
  courseCardMeta: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  lessonRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingLeft: 8, gap: 8, borderTopWidth: 0.5, borderTopColor: colors.borderLight },
  lessonDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.primary },
  lessonRowTitle: { flex: 1, fontSize: 14, color: colors.textBody },
  lessonRowMeta: { fontSize: 12, color: colors.textPlaceholder },
  addLessonBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, borderTopWidth: 0.5, borderTopColor: colors.borderLight, marginTop: 4 },
  addLessonBtnText: { fontSize: 13, fontWeight: '600', color: colors.primary },
  staticCourseRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: colors.bgWhite, borderRadius: 12, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: colors.borderLight },
  staticCourseTitle: { flex: 1, fontSize: 15, fontWeight: '600', color: colors.textDark },
  staticCourseMeta: { fontSize: 12, color: colors.textPlaceholder },
  emptyContainer: { alignItems: 'center', paddingVertical: 40 },
  emptyTitle: { fontSize: 16, fontWeight: '600', color: colors.textMuted, marginTop: 12 },
  emptyText: { fontSize: 13, color: colors.textPlaceholder, marginTop: 4 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: colors.bgWhite, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 36, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: colors.textDark },
  formLabel: { fontSize: 13, fontWeight: '700', color: colors.textBody, marginBottom: 6, marginTop: 12 },
  input: { backgroundColor: colors.bgInputLight, borderRadius: 12, padding: 12, fontSize: 15, color: colors.textDark, borderWidth: 1, borderColor: colors.borderLight },
  inputMultiline: { minHeight: 80, textAlignVertical: 'top' },
  inputCode: { minHeight: 80, textAlignVertical: 'top', fontFamily: 'monospace', fontSize: 13, backgroundColor: '#1E1E2E', color: '#E2E8F0', borderColor: '#1E1E2E' },
  iconGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  iconOption: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center', borderWidth: 1.5, borderColor: colors.borderLight },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  colorOption: { width: 36, height: 36, borderRadius: 18, borderWidth: 2, borderColor: 'transparent' },
  colorOptionActive: { borderColor: colors.textDark, borderWidth: 3 },
  courseChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  courseChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1.5, borderColor: colors.borderLight },
  courseChipText: { fontSize: 12, fontWeight: '600', color: colors.textBody },
  stepsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, marginBottom: 6 },
  addStepBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  addStepBtnText: { fontSize: 13, fontWeight: '600', color: colors.primary },
  stepPreview: { backgroundColor: colors.bgInputLight, borderRadius: 10, padding: 10, marginBottom: 6 },
  stepPreviewHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  stepPreviewNum: { fontSize: 11, fontWeight: '700', color: colors.primary },
  stepPreviewTitle: { fontSize: 14, fontWeight: '600', color: colors.textDark, marginTop: 2 },
  stepPreviewDesc: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  stepPreviewTag: { fontSize: 10, color: colors.success, fontWeight: '600', marginTop: 4 },
  noSteps: { alignItems: 'center', paddingVertical: 20 },
  noStepsText: { fontSize: 13, color: colors.textPlaceholder },
  submitBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 14, marginTop: 16, marginBottom: 16 },
  submitBtnDisabled: { opacity: 0.4 },
  submitBtnText: { fontSize: 15, fontWeight: '700', color: colors.textWhite },
});
