import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  orderBy,
  deleteDoc,
  doc,
  updateDoc,
  increment
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase.config';
import { Story } from '../types';

// Create a new story
export const createStory = async (
  userId: string,
  username: string,
  mediaUri: string,
  profileImage?: string
): Promise<Story> => {
  // Upload media to Firebase Storage
  const filename = `stories/${userId}/${Date.now()}.jpg`;
  const storageRef = ref(storage, filename);
  const response = await fetch(mediaUri);
  const blob = await response.blob();
  await uploadBytes(storageRef, blob);
  const mediaUrl = await getDownloadURL(storageRef);

  // Story expires in 24 hours
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

  const story: Omit<Story, 'id'> = {
    userId,
    username,
    profileImage,
    mediaUrl,
    expiresAt,
    views: 0,
    createdAt: new Date().toISOString()
  };

  const docRef = await addDoc(collection(db, 'stories'), story);

  return { ...story, id: docRef.id };
};

// Get all active stories (not expired)
export const getStories = async (): Promise<Story[]> => {
  try {
    const now = new Date().toISOString();
    const q = query(
      collection(db, 'stories'),
      where('expiresAt', '>', now),
      orderBy('expiresAt', 'desc'),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    const stories: Story[] = [];

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      stories.push({
        id: doc.id,
        userId: data.userId,
        username: data.username,
        profileImage: data.profileImage,
        mediaUrl: data.mediaUrl,
        expiresAt: data.expiresAt,
        views: data.views || 0,
        createdAt: data.createdAt
      });
    });

    return stories;
  } catch (error) {
    console.error('Error getting stories:', error);
    return [];
  }
};

// Get stories for a specific user
export const getUserStories = async (userId: string): Promise<Story[]> => {
  try {
    const now = new Date().toISOString();
    const q = query(
      collection(db, 'stories'),
      where('userId', '==', userId),
      where('expiresAt', '>', now),
      orderBy('expiresAt', 'desc'),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    const stories: Story[] = [];

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      stories.push({
        id: doc.id,
        userId: data.userId,
        username: data.username,
        profileImage: data.profileImage,
        mediaUrl: data.mediaUrl,
        expiresAt: data.expiresAt,
        views: data.views || 0,
        createdAt: data.createdAt
      });
    });

    return stories;
  } catch (error) {
    console.error('Error getting user stories:', error);
    return [];
  }
};

// Increment story view count
export const viewStory = async (storyId: string): Promise<void> => {
  const storyRef = doc(db, 'stories', storyId);
  await updateDoc(storyRef, {
    views: increment(1)
  });
};

// Delete a story
export const deleteStory = async (storyId: string): Promise<void> => {
  await deleteDoc(doc(db, 'stories', storyId));
};

// Delete expired stories (should be called by a Cloud Function or periodically)
export const deleteExpiredStories = async (): Promise<number> => {
  try {
    const now = new Date().toISOString();
    const q = query(
      collection(db, 'stories'),
      where('expiresAt', '<=', now)
    );

    const querySnapshot = await getDocs(q);
    const deletePromises = querySnapshot.docs.map(docSnapshot =>
      deleteDoc(doc(db, 'stories', docSnapshot.id))
    );

    await Promise.all(deletePromises);
    return querySnapshot.docs.length;
  } catch (error) {
    console.error('Error deleting expired stories:', error);
    return 0;
  }
};

// Group stories by user (for displaying story circles)
export const getStoriesByUser = async (): Promise<{ [userId: string]: Story[] }> => {
  const stories = await getStories();
  const storiesByUser: { [userId: string]: Story[] } = {};

  stories.forEach(story => {
    if (!storiesByUser[story.userId]) {
      storiesByUser[story.userId] = [];
    }
    storiesByUser[story.userId].push(story);
  });

  return storiesByUser;
};