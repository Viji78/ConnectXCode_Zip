import { collection, addDoc, getDocs, getDoc, updateDoc, deleteDoc, doc, setDoc, query, orderBy } from 'firebase/firestore';
import { db } from '../../firebase.config';
import { Course, Lesson, LessonStep, defaultCourses } from '../data/courses';

// Firestore collection for all courses
const COLLECTION = 'customCourses';

// Seed default courses into Firestore (skips if already exists)
export const seedDefaultCourses = async (): Promise<void> => {
  for (const course of defaultCourses) {
    const courseDoc = await getDoc(doc(db, COLLECTION, course.id));
    if (!courseDoc.exists()) {
      await setDoc(doc(db, COLLECTION, course.id), {
        title: course.title,
        icon: course.icon,
        color: course.color,
        description: course.description,
        lessons: course.lessons,
        createdAt: new Date().toISOString(),
      });
    }
  }
};

// Available icons for new courses
export const courseIcons = [
  { icon: 'code-slash', label: 'Code' },
  { icon: 'logo-html5', label: 'HTML' },
  { icon: 'logo-css3', label: 'CSS' },
  { icon: 'logo-javascript', label: 'JavaScript' },
  { icon: 'logo-python', label: 'Python' },
  { icon: 'logo-react', label: 'React' },
  { icon: 'logo-nodejs', label: 'Node.js' },
  { icon: 'server-outline', label: 'Database' },
  { icon: 'git-branch-outline', label: 'Git' },
  { icon: 'terminal-outline', label: 'Terminal' },
  { icon: 'phone-portrait-outline', label: 'Mobile' },
  { icon: 'cloud-outline', label: 'Cloud' },
  { icon: 'shield-outline', label: 'Security' },
  { icon: 'analytics-outline', label: 'Analytics' },
  { icon: 'bulb-outline', label: 'Ideas' },
  { icon: 'book-outline', label: 'Book' },
];

export const courseColors = [
  '#E44D26', '#264DE4', '#F7DF1E', '#3776AB', '#336791', '#61DAFB',
  '#68A063', '#E34F26', '#CC6699', '#FF6384', '#4BC0C0', '#9966FF',
];

export const createCourse = async (course: Omit<Course, 'id'>): Promise<Course> => {
  const data = {
    ...course,
    createdAt: new Date().toISOString(),
  };
  const docRef = await addDoc(collection(db, COLLECTION), data);
  return { id: docRef.id, ...course };
};

export const getCustomCourses = async (): Promise<Course[]> => {
  const snapshot = await getDocs(collection(db, COLLECTION));
  return snapshot.docs.map(d => {
    const data = d.data();
    return {
      id: d.id,
      title: data.title || '',
      icon: data.icon || 'book-outline',
      color: data.color || '#7C3AED',
      description: data.description || '',
      lessons: (data.lessons || []).map((l: any) => ({
        ...l,
        steps: l.steps || [],
      })),
    };
  }) as Course[];
};

export const updateCourse = async (courseId: string, data: Partial<Course>): Promise<void> => {
  await updateDoc(doc(db, COLLECTION, courseId), data as any);
};

export const deleteCourse = async (courseId: string): Promise<void> => {
  await deleteDoc(doc(db, COLLECTION, courseId));
};

export const addLessonToCourse = async (courseId: string, lesson: Lesson): Promise<void> => {
  const courseDoc = await getDoc(doc(db, COLLECTION, courseId));
  if (!courseDoc.exists()) throw new Error('Course not found');
  const lessons = courseDoc.data().lessons || [];
  lessons.push(lesson);
  await updateDoc(doc(db, COLLECTION, courseId), { lessons });
};

export const updateLessonInCourse = async (courseId: string, updatedLesson: Lesson): Promise<void> => {
  const courseDoc = await getDoc(doc(db, COLLECTION, courseId));
  if (!courseDoc.exists()) throw new Error('Course not found');
  const lessons = (courseDoc.data().lessons || []).map((l: Lesson) =>
    l.id === updatedLesson.id ? updatedLesson : l
  );
  await updateDoc(doc(db, COLLECTION, courseId), { lessons });
};

export const deleteLessonFromCourse = async (courseId: string, lessonId: string): Promise<void> => {
  const courseDoc = await getDoc(doc(db, COLLECTION, courseId));
  if (!courseDoc.exists()) throw new Error('Course not found');
  const lessons = (courseDoc.data().lessons || []).filter((l: Lesson) => l.id !== lessonId);
  await updateDoc(doc(db, COLLECTION, courseId), { lessons });
};
