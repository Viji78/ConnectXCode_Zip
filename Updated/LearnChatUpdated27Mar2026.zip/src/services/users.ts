import { collection, getDocs, getDoc, deleteDoc, doc, query, where } from 'firebase/firestore';
import { db } from '../../firebase.config';
import { User } from '../types';

export const getAllUsersAdmin = async (): Promise<User[]> => {
  const snapshot = await getDocs(collection(db, 'users'));
  const users: User[] = [];
  snapshot.forEach((docSnap) => {
    const data = docSnap.data();
    users.push({
      id: docSnap.id,
      ...data,
      friends: data.friends || [],
      user_role: data.user_role || 'Student',
    } as User);
  });
  return users.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
};

export const getUserById = async (userId: string): Promise<User | null> => {
  const docSnap = await getDoc(doc(db, 'users', userId));
  if (!docSnap.exists()) return null;
  const data = docSnap.data();
  return {
    id: docSnap.id,
    ...data,
    friends: data.friends || [],
    user_role: data.user_role || 'Student',
  } as User;
};

export const deleteUserCompletely = async (userId: string): Promise<void> => {
  // Delete user's posts
  const postsQuery = query(collection(db, 'posts'), where('userId', '==', userId));
  const postsSnap = await getDocs(postsQuery);
  for (const d of postsSnap.docs) {
    await deleteDoc(d.ref);
  }

  // Delete user's friend requests
  const sentReqs = query(collection(db, 'friendRequests'), where('fromUserId', '==', userId));
  const sentSnap = await getDocs(sentReqs);
  for (const d of sentSnap.docs) {
    await deleteDoc(d.ref);
  }

  const recvReqs = query(collection(db, 'friendRequests'), where('toUserId', '==', userId));
  const recvSnap = await getDocs(recvReqs);
  for (const d of recvSnap.docs) {
    await deleteDoc(d.ref);
  }

  // Delete user's chats
  const chatsQuery = query(collection(db, 'chats'), where('participants', 'array-contains', userId));
  const chatsSnap = await getDocs(chatsQuery);
  for (const d of chatsSnap.docs) {
    await deleteDoc(d.ref);
  }

  // Delete user document
  await deleteDoc(doc(db, 'users', userId));
};
