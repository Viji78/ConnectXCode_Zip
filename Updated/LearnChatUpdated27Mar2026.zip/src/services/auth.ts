import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, setDoc, getDoc, collection, getDocs, query, where, updateDoc, arrayUnion, increment } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth, db } from '../../firebase.config';
import { User } from '../types';

const ADMIN_EMAIL = 'testingappviji@gmail.com';
const SESSION_KEY = '@learn_chat_session_token';

// Generate unique session token
const generateSessionToken = (): string => {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
};

// Save session token locally
const saveSessionLocal = async (token: string): Promise<void> => {
  await AsyncStorage.setItem(SESSION_KEY, token);
};

// Get local session token
const getLocalSession = async (): Promise<string | null> => {
  return await AsyncStorage.getItem(SESSION_KEY);
};

// Clear local session token
const clearLocalSession = async (): Promise<void> => {
  await AsyncStorage.removeItem(SESSION_KEY);
};

// Save session token to Firestore
const saveSessionToFirestore = async (userId: string, token: string): Promise<void> => {
  await updateDoc(doc(db, 'users', userId), { sessionToken: token });
};

const autoFriendWithAdmin = async (newUserId: string): Promise<void> => {
  try {
    const q = query(collection(db, 'users'), where('user_role', '==', 'Admin'));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return;

    const adminDoc = snapshot.docs[0];
    const adminId = adminDoc.id;
    if (adminId === newUserId) return;

    await updateDoc(doc(db, 'users', adminId), {
      friends: arrayUnion(newUserId),
      followers: increment(1),
      following: increment(1),
    });
    await updateDoc(doc(db, 'users', newUserId), {
      friends: arrayUnion(adminId),
      followers: increment(1),
      following: increment(1),
    });
  } catch {}
};

const adminFriendAllUsers = async (adminId: string): Promise<void> => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    for (const userDoc of snapshot.docs) {
      const userId = userDoc.id;
      if (userId === adminId) continue;

      await updateDoc(doc(db, 'users', adminId), {
        friends: arrayUnion(userId),
        followers: increment(1),
        following: increment(1),
      });
      await updateDoc(doc(db, 'users', userId), {
        friends: arrayUnion(adminId),
        followers: increment(1),
        following: increment(1),
      });
    }
  } catch {}
};

export const signUp = async (
  email: string,
  password: string,
  username: string,
  country: string,
  countryCode: string,
  phoneNumber: string,
  dateOfBirth: string
): Promise<User> => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  const isAdmin = email.toLowerCase() === ADMIN_EMAIL;
  const sessionToken = generateSessionToken();

  const user: User = {
    id: firebaseUser.uid,
    username,
    email,
    country,
    countryCode,
    phoneNumber,
    dateOfBirth,
    bio: 'New user on Learn & Chat',
    followers: 0,
    following: 0,
    friends: [],
    user_role: isAdmin ? 'Admin' : 'Student',
    sessionToken,
    createdAt: new Date().toISOString()
  };

  await setDoc(doc(db, 'users', firebaseUser.uid), user);
  await saveSessionLocal(sessionToken);

  if (isAdmin) {
    await adminFriendAllUsers(firebaseUser.uid);
  } else {
    await autoFriendWithAdmin(firebaseUser.uid);
  }

  const updatedDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
  if (updatedDoc.exists()) {
    return updatedDoc.data() as User;
  }

  return user;
};

export const signIn = async (
  email: string,
  password: string
): Promise<User> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));

  if (!userDoc.exists()) {
    throw new Error('User data not found');
  }

  const userData = userDoc.data() as User;

  if (!userData.user_role) {
    const role = email.toLowerCase() === ADMIN_EMAIL ? 'Admin' : 'Student';
    await updateDoc(doc(db, 'users', firebaseUser.uid), { user_role: role });
    userData.user_role = role;
  }

  // Generate new session token — invalidates any other device
  const sessionToken = generateSessionToken();
  await saveSessionToFirestore(firebaseUser.uid, sessionToken);
  await saveSessionLocal(sessionToken);
  userData.sessionToken = sessionToken;

  return userData;
};

// Validate session: returns user if valid, null if logged in on another device
export const validateSession = async (firebaseUser: FirebaseUser): Promise<User | null> => {
  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
  if (!userDoc.exists()) return null;

  const data = userDoc.data();
  const userData = { ...data, friends: data.friends || [] } as User;

  if (!userData.user_role) {
    const email = firebaseUser.email || '';
    const role = email.toLowerCase() === ADMIN_EMAIL ? 'Admin' : 'Student';
    await updateDoc(doc(db, 'users', firebaseUser.uid), { user_role: role });
    userData.user_role = role;
  }

  // Check session token
  const localToken = await getLocalSession();
  const serverToken = userData.sessionToken;

  if (serverToken && localToken !== serverToken) {
    // Mismatch — logged in on another device, force logout here
    await firebaseSignOut(auth);
    await clearLocalSession();
    return null;
  }

  return userData;
};

export const signOut = async (): Promise<void> => {
  const firebaseUser = auth.currentUser;
  if (firebaseUser) {
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), { sessionToken: '' });
    } catch {}
  }
  await clearLocalSession();
  await firebaseSignOut(auth);
};

// getCurrentUser now validates session
export const getCurrentUser = async (
  firebaseUser: FirebaseUser
): Promise<User | null> => {
  return validateSession(firebaseUser);
};
