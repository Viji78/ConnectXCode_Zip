import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  query,
  where,

  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';
import { db } from '../../firebase.config';
import { Chat, Message } from '../types';
import { getUserPushToken, sendPushNotification } from './notifications';

// Get all chats for a user
export const getChats = async (userId: string): Promise<Chat[]> => {
  try {
    // Single where, sort in code to avoid composite index
    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', userId)
    );
    const querySnapshot = await getDocs(q);
    const chats: Chat[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      chats.push({
        id: docSnap.id,
        participants: data.participants || [],
        participantNames: data.participantNames || {},
        lastMessage: data.lastMessage || '',
        lastMessageTime: data.lastMessageTime || new Date().toISOString(),
        unreadCount: data.unreadCount || {},
        createdAt: data.createdAt || new Date().toISOString(),
      });
    });
    // Sort by latest message first
    chats.sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());
    return chats;
  } catch (error) {
    console.error('Error getting chats:', error);
    return [];
  }
};

// Get messages for a chat — deletes messages read > 24hrs ago
export const getMessages = async (chatId: string): Promise<Message[]> => {
  try {
    // Single where, sort in code to avoid composite index
    const q = query(
      collection(db, 'messages'),
      where('chatId', '==', chatId)
    );
    const querySnapshot = await getDocs(q);
    const messages: Message[] = [];
    const now = new Date().getTime();
    const expiredIds: string[] = [];

    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      // If message was read and readAt is > 24hrs ago, mark for deletion
      if (data.readAt) {
        const readTime = new Date(data.readAt).getTime();
        if (now - readTime > 24 * 60 * 60 * 1000) {
          expiredIds.push(docSnap.id);
          return; // skip adding to list
        }
      }
      messages.push({
        id: docSnap.id,
        chatId: data.chatId,
        senderId: data.senderId,
        senderName: data.senderName,
        content: data.content,
        mediaUrl: data.mediaUrl,
        createdAt: data.createdAt || new Date().toISOString(),
        read: data.read || false,
        readAt: data.readAt,
      });
    });

    // Delete expired messages in background
    for (const id of expiredIds) {
      try { await deleteDoc(doc(db, 'messages', id)); } catch {}
    }

    // Sort by time
    messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    return messages;
  } catch (error) {
    console.error('Error getting messages:', error);
    return [];
  }
};

// Send a message
export const sendMessage = async (
  chatId: string,
  senderId: string,
  senderName: string,
  content: string
): Promise<Message> => {
  const msgData: any = {
    chatId,
    senderId,
    senderName,
    content,
    createdAt: new Date().toISOString(),
    read: false,
  };

  const docRef = await addDoc(collection(db, 'messages'), msgData);

  // Update chat's last message + increment unread for other participant
  const chatRef = doc(db, 'chats', chatId);
  const chatSnap = await getDoc(chatRef);
  const chatData = chatSnap.data();
  const otherUserId = chatData?.participants?.find((id: string) => id !== senderId);

  const updates: any = {
    lastMessage: content,
    lastMessageTime: new Date().toISOString(),
  };
  if (otherUserId) {
    const currentUnread = chatData?.unreadCount?.[otherUserId] || 0;
    updates[`unreadCount.${otherUserId}`] = currentUnread + 1;
  }
  await updateDoc(chatRef, updates);

  // // // // --------- Notify post owner / Send push notification---Send push notification to the other user
  if (otherUserId) {
    const token = await getUserPushToken(otherUserId);
    if (token) {
      await sendPushNotification(
        token,
        `${senderName}`,
        content,
        { screen: 'Chat', params: { chatId, friendName: senderName } }
      );
    }
  }

  return { ...msgData, id: docRef.id };
};

// Create a new chat between two friends
export const createChat = async (
  participants: string[],
  participantNames: { [userId: string]: string }
): Promise<Chat> => {
  const chat: any = {
    participants,
    participantNames,
    lastMessage: '',
    lastMessageTime: new Date().toISOString(),
    unreadCount: {},
    createdAt: new Date().toISOString(),
  };
  const docRef = await addDoc(collection(db, 'chats'), chat);
  return { ...chat, id: docRef.id };
};

// Find existing chat between two users
export const findChat = async (userId1: string, userId2: string): Promise<Chat | null> => {
  try {
    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', userId1)
    );
    const snapshot = await getDocs(q);
    let found: Chat | null = null;
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.participants?.includes(userId2)) {
        found = {
          id: docSnap.id,
          participants: data.participants,
          participantNames: data.participantNames || {},
          lastMessage: data.lastMessage || '',
          lastMessageTime: data.lastMessageTime || '',
          unreadCount: data.unreadCount || {},
          createdAt: data.createdAt || '',
        };
      }
    });
    return found;
  } catch {
    return null;
  }
};

// Listen to messages in real-time
export const subscribeToMessages = (
  chatId: string,
  callback: (messages: Message[]) => void
) => {
  // Single where, sort in code to avoid composite index
  const q = query(
    collection(db, 'messages'),
    where('chatId', '==', chatId)
  );

  return onSnapshot(q, (querySnapshot) => {
    const messages: Message[] = [];
    const now = new Date().getTime();
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      // Skip expired read messages
      if (data.readAt) {
        const readTime = new Date(data.readAt).getTime();
        if (now - readTime > 24 * 60 * 60 * 1000) return;
      }
      messages.push({
        id: docSnap.id,
        chatId: data.chatId,
        senderId: data.senderId,
        senderName: data.senderName,
        content: data.content,
        mediaUrl: data.mediaUrl,
        createdAt: data.createdAt || new Date().toISOString(),
        read: data.read || false,
        readAt: data.readAt,
      });
    });
    // Sort by time
    messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    callback(messages);
  });
};

// Mark messages as read — sets readAt timestamp (24hr expiry starts now)
// Uses single where + filter in code to avoid composite index
export const markMessagesAsRead = async (
  chatId: string,
  userId: string
): Promise<void> => {
  try {
    const q = query(
      collection(db, 'messages'),
      where('chatId', '==', chatId)
    );
    const snapshot = await getDocs(q);
    const now = new Date().toISOString();

    const updates = snapshot.docs
      .filter((d) => d.data().senderId !== userId && !d.data().read)
      .map((docSnap) =>
        updateDoc(doc(db, 'messages', docSnap.id), { read: true, readAt: now })
      );

    await Promise.all(updates);

    const chatRef = doc(db, 'chats', chatId);
    await updateDoc(chatRef, { [`unreadCount.${userId}`]: 0 });
  } catch (error) {
    console.error('Error marking messages as read:', error);
  }
};
