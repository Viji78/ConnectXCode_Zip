import { collection, addDoc, getDocs, getDoc, deleteDoc, doc, query, where } from 'firebase/firestore';
import { db } from '../../firebase.config';
import { CoursePdf } from '../types';

export const uploadPdf = async (
  courseId: string,
  fileName: string,
  fileSize: number,
  base64Data: string,
  uploadedBy: string
): Promise<CoursePdf> => {
  const pdfData = {
    courseId,
    fileName,
    fileSize,
    base64Data,
    uploadedBy,
    uploadedAt: new Date().toISOString(),
  };

  const docRef = await addDoc(collection(db, 'coursePdfs'), pdfData);

  return { id: docRef.id, ...pdfData };
};

export const getCoursePdfs = async (courseId: string): Promise<CoursePdf[]> => {
  const q = query(
    collection(db, 'coursePdfs'),
    where('courseId', '==', courseId)
  );

  const snapshot = await getDocs(q);
  const pdfs = snapshot.docs.map(d => ({
    id: d.id,
    ...d.data(),
  })) as CoursePdf[];

  // Sort newest first (client-side to avoid composite index)
  return pdfs.sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt));
};

export const getPdfById = async (pdfId: string): Promise<CoursePdf | null> => {
  const docSnap = await getDoc(doc(db, 'coursePdfs', pdfId));
  if (!docSnap.exists()) return null;
  return { id: docSnap.id, ...docSnap.data() } as CoursePdf;
};

export const deletePdf = async (pdfId: string): Promise<void> => {
  await deleteDoc(doc(db, 'coursePdfs', pdfId));
};

export const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
};
