import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/common';

interface Props {
  navigation: any;
  active: 'Home' | 'Feed' | 'Search' | 'Create' | 'Messages' | 'Profile';
}

export default function BottomNav({ navigation, active }: Props) {
  const tabs = [
    { key: 'Home' as const, icon: 'book', iconOutline: 'book-outline', screen: 'Home' },
    { key: 'Feed' as const, icon: 'newspaper', iconOutline: 'newspaper-outline', screen: 'Feed' },
    { key: 'Create' as const, icon: 'add', iconOutline: 'add', screen: 'CreatePost' },
    { key: 'Search' as const, icon: 'search', iconOutline: 'search-outline', screen: 'Search' },
    { key: 'Messages' as const, icon: 'chatbubble', iconOutline: 'chatbubble-outline', screen: 'Messages' },
    { key: 'Profile' as const, icon: 'person', iconOutline: 'person-outline', screen: 'Profile' },
  ];

  return (
    <View style={styles.bottomNav}>
      {tabs.map((tab) => {
        const isActive = active === tab.key;
        const isCreate = tab.key === 'Create';

        return (
          <TouchableOpacity
            key={tab.key}
            style={styles.navItem}
            onPress={() => {
              if (tab.screen && !isActive) navigation.navigate(tab.screen);
            }}
          >
            {isCreate ? (
              <View style={styles.createBtn}>
                <Ionicons name="add" size={28} color={colors.textWhite} />
              </View>
            ) : (
              <Ionicons
                name={(isActive ? tab.icon : tab.iconOutline) as any}
                size={26}
                color={isActive ? colors.textDark : colors.textMuted}
              />
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: colors.bgWhite,
    borderTopWidth: 0.5,
    borderTopColor: colors.borderLight,
    paddingVertical: 8,
    paddingBottom: 24,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
  },
  createBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: colors.textDark,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
