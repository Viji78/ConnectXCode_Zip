import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  StyleSheet,
  Modal,
  Dimensions,
  ActivityIndicator,
  StatusBar,
  Platform,
  PanResponder,
  GestureResponderEvent,
  PanResponderGestureState,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImageManipulator from 'expo-image-manipulator';

const { width: SW, height: SH } = Dimensions.get('window');
const SB = Platform.OS === 'ios' ? 54 : (StatusBar.currentHeight || 30);
const HDR = 56;
const TBR = 120;
const AH = SH - SB - HDR - TBR; // available height for image area
const MIN_CROP = 80;
const HANDLE_SIZE = 40; // touch target for corners

type Mode = 'none' | 'move' | 'tl' | 'tr' | 'bl' | 'br';

interface Props {
  visible: boolean;
  imageUri: string;
  onDone: (uri: string) => void;
  onCancel: () => void;
  squareOnly?: boolean;
}

export default function ImageCropModal({ visible, imageUri, onDone, onCancel, squareOnly = true }: Props) {
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [imgSize, setImgSize] = useState({ w: 1, h: 1 });

  // Image display area (image fitted into available space)
  const [imgArea, setImgArea] = useState({ x: 0, y: 0, w: SW, h: AH });

  // Crop box (relative to cropContainer, not imgArea)
  const [crop, setCrop] = useState({ x: 0, y: 0, w: 200, h: 200 });

  const modeRef = useRef<Mode>('none');
  const startCrop = useRef({ x: 0, y: 0, w: 0, h: 0 });
  const cropRef = useRef({ x: 0, y: 0, w: 200, h: 200 });
  const imgAreaRef = useRef({ x: 0, y: 0, w: SW, h: AH });
  const squareRef = useRef(squareOnly);

  useEffect(() => { squareRef.current = squareOnly; }, [squareOnly]);

  useEffect(() => {
    if (imageUri && visible) {
      Image.getSize(imageUri, (w, h) => {
        setImgSize({ w, h });
        initLayout(w, h, 0);
      }, () => {});
    }
  }, [imageUri, visible]);

  const initLayout = (iw: number, ih: number, rot: number) => {
    const isR = rot === 90 || rot === 270;
    const sw = isR ? ih : iw;
    const sh = isR ? iw : ih;
    const IMG_PAD = 20;
    const scale = Math.min((SW - IMG_PAD * 2) / sw, (AH - IMG_PAD * 2) / sh);
    const dw = sw * scale;
    const dh = sh * scale;
    const dx = (SW - dw) / 2;
    const dy = (AH - dh) / 2;

    const area = { x: dx, y: dy, w: dw, h: dh };
    setImgArea(area);
    imgAreaRef.current = area;

    // Initial crop with padding (16px inset from image edges)
    const PAD = 16;
    let cx: number, cy: number, cw: number, ch: number;
    if (squareRef.current) {
      const s = Math.min(dw, dh) - PAD * 2;
      cx = dx + (dw - s) / 2;
      cy = dy + (dh - s) / 2;
      cw = s;
      ch = s;
    } else {
      cx = dx + PAD;
      cy = dy + PAD;
      cw = dw - PAD * 2;
      ch = dh - PAD * 2;
    }
    const c = { x: cx, y: cy, w: cw, h: ch };
    setCrop(c);
    cropRef.current = c;
    setRotation(rot);
    setFlipH(false);
    setFlipV(false);
  };

  const resetAll = () => {
    initLayout(imgSize.w, imgSize.h, 0);
  };

  // Determine gesture mode from touch position
  const getMode = (px: number, py: number): Mode => {
    const c = cropRef.current;
    const nearTL = Math.abs(px - c.x) < HANDLE_SIZE && Math.abs(py - c.y) < HANDLE_SIZE;
    const nearTR = Math.abs(px - (c.x + c.w)) < HANDLE_SIZE && Math.abs(py - c.y) < HANDLE_SIZE;
    const nearBL = Math.abs(px - c.x) < HANDLE_SIZE && Math.abs(py - (c.y + c.h)) < HANDLE_SIZE;
    const nearBR = Math.abs(px - (c.x + c.w)) < HANDLE_SIZE && Math.abs(py - (c.y + c.h)) < HANDLE_SIZE;

    if (nearTL) return 'tl';
    if (nearTR) return 'tr';
    if (nearBL) return 'bl';
    if (nearBR) return 'br';

    // Inside crop box = move
    if (px >= c.x && px <= c.x + c.w && py >= c.y && py <= c.y + c.h) return 'move';

    return 'none';
  };

  const clampCrop = (nx: number, ny: number, nw: number, nh: number) => {
    const a = imgAreaRef.current;
    let x = Math.max(a.x, Math.min(nx, a.x + a.w - MIN_CROP));
    let y = Math.max(a.y, Math.min(ny, a.y + a.h - MIN_CROP));
    let w = Math.max(MIN_CROP, Math.min(nw, a.x + a.w - x));
    let h = Math.max(MIN_CROP, Math.min(nh, a.y + a.h - y));

    if (squareRef.current) {
      const s = Math.min(w, h);
      w = s;
      h = s;
    }
    return { x, y, w, h };
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt: GestureResponderEvent) => {
        const { locationX, locationY } = evt.nativeEvent;
        modeRef.current = getMode(locationX, locationY);
        startCrop.current = { ...cropRef.current };
      },
      onPanResponderMove: (_: GestureResponderEvent, g: PanResponderGestureState) => {
        const s = startCrop.current;
        const a = imgAreaRef.current;
        let nc = { ...s };

        switch (modeRef.current) {
          case 'move': {
            let nx = s.x + g.dx;
            let ny = s.y + g.dy;
            nx = Math.max(a.x, Math.min(nx, a.x + a.w - s.w));
            ny = Math.max(a.y, Math.min(ny, a.y + a.h - s.h));
            nc = { ...s, x: nx, y: ny };
            break;
          }
          case 'br': {
            let nw = s.w + g.dx;
            let nh = s.h + g.dy;
            if (squareRef.current) {
              const d = Math.max(g.dx, g.dy);
              nw = s.w + d;
              nh = s.h + d;
            }
            nc = clampCrop(s.x, s.y, nw, nh);
            break;
          }
          case 'bl': {
            let dx = g.dx;
            let nw = s.w - dx;
            let nh = s.h + g.dy;
            if (squareRef.current) {
              const d = Math.max(-dx, g.dy);
              nw = s.w + d;
              nh = s.h + d;
              dx = -d;
            }
            const nx = s.x + (s.w - nw);
            nc = clampCrop(nx, s.y, nw, nh);
            break;
          }
          case 'tl': {
            let dx = g.dx;
            let dy = g.dy;
            let nw = s.w - dx;
            let nh = s.h - dy;
            if (squareRef.current) {
              const d = Math.max(-dx, -dy);
              nw = s.w + d;
              nh = s.h + d;
              dx = -d;
              dy = -d;
            }
            const nx = s.x + (s.w - nw);
            const ny = s.y + (s.h - nh);
            nc = clampCrop(nx, ny, nw, nh);
            break;
          }
          case 'tr': {
            let dy = g.dy;
            let nw = s.w + g.dx;
            let nh = s.h - dy;
            if (squareRef.current) {
              const d = Math.max(g.dx, -dy);
              nw = s.w + d;
              nh = s.h + d;
              dy = -d;
            }
            const ny = s.y + (s.h - nh);
            nc = clampCrop(s.x, ny, nw, nh);
            break;
          }
          default:
            return;
        }
        cropRef.current = nc;
        setCrop(nc);
      },
      onPanResponderRelease: () => {
        modeRef.current = 'none';
      },
    })
  ).current;

  const handleRotate = () => {
    const nr = (rotation + 90) % 360;
    initLayout(imgSize.w, imgSize.h, nr);
  };

  const handleFlipH = () => setFlipH(p => !p);
  const handleFlipV = () => setFlipV(p => !p);

  const handleDone = async () => {
    setProcessing(true);
    try {
      const actions: ImageManipulator.Action[] = [];
      if (rotation !== 0) actions.push({ rotate: rotation });
      if (flipH) actions.push({ flip: ImageManipulator.FlipType.Horizontal });
      if (flipV) actions.push({ flip: ImageManipulator.FlipType.Vertical });

      const t = await ImageManipulator.manipulateAsync(imageUri, actions, { compress: 1 });
      const { width: iw, height: ih } = t;

      // Convert crop box from screen coords to image pixel coords
      const a = imgArea;
      const scaleX = iw / a.w;
      const scaleY = ih / a.h;

      const ox = (crop.x - a.x) * scaleX;
      const oy = (crop.y - a.y) * scaleY;
      const cw = crop.w * scaleX;
      const ch = crop.h * scaleY;

      // Clamp to image bounds
      const originX = Math.max(0, Math.min(ox, iw - 1));
      const originY = Math.max(0, Math.min(oy, ih - 1));
      const width = Math.min(cw, iw - originX);
      const height = Math.min(ch, ih - originY);

      const cropActions: ImageManipulator.Action[] = [
        { crop: { originX, originY, width, height } },
      ];
      if (squareOnly) {
        cropActions.push({ resize: { width: 500 } });
      } else if (width > 1200) {
        cropActions.push({ resize: { width: 1200 } });
      }

      const result = await ImageManipulator.manipulateAsync(t.uri, cropActions, {
        compress: 0.7,
        format: ImageManipulator.SaveFormat.JPEG,
      });
      onDone(result.uri);
    } catch (e) {
      console.error('Crop error:', e);
      onDone(imageUri);
    } finally {
      setProcessing(false);
      resetAll();
    }
  };

  const handleCancel = () => {
    resetAll();
    onCancel();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={handleCancel}>
      <View style={styles.container}>
        {/* White Header */}
        <View style={styles.statusBar} />
        <View style={styles.header}>
          <TouchableOpacity onPress={handleCancel} style={styles.headerBtn}>
            <Ionicons name="close" size={26} color="#222" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Crop Photo</Text>
          {processing ? (
            <ActivityIndicator size="small" color="#4F46E5" style={{ marginRight: 8 }} />
          ) : (
            <TouchableOpacity onPress={handleDone} style={styles.doneBtn}>
              <Ionicons name="checkmark" size={20} color="#FFF" />
              <Text style={styles.doneBtnText}>Done</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Image + crop area */}
        <View style={styles.cropContainer}>
          {/* Full image */}
          <Image
            source={{ uri: imageUri }}
            style={{
              position: 'absolute',
              left: imgArea.x,
              top: imgArea.y,
              width: imgArea.w,
              height: imgArea.h,
              transform: [
                { rotate: `${rotation}deg` },
                { scaleX: flipH ? -1 : 1 },
                { scaleY: flipV ? -1 : 1 },
              ],
            }}
            resizeMode="contain"
          />

          {/* Dark overlays around crop box */}
          <View style={[styles.ov, { top: 0, left: 0, right: 0, height: crop.y }]} pointerEvents="none" />
          <View style={[styles.ov, { top: crop.y + crop.h, left: 0, right: 0, bottom: 0 }]} pointerEvents="none" />
          <View style={[styles.ov, { top: crop.y, left: 0, width: crop.x, height: crop.h }]} pointerEvents="none" />
          <View style={[styles.ov, { top: crop.y, left: crop.x + crop.w, right: 0, height: crop.h }]} pointerEvents="none" />

          {/* Crop box border + grid */}
          <View style={[styles.cropBox, { top: crop.y, left: crop.x, width: crop.w, height: crop.h }]} pointerEvents="none">
            <View style={[styles.gridH, { top: '33.33%' }]} />
            <View style={[styles.gridH, { top: '66.66%' }]} />
            <View style={[styles.gridV, { left: '33.33%' }]} />
            <View style={[styles.gridV, { left: '66.66%' }]} />
          </View>

          {/* Corner handles (visible) */}
          <View style={[styles.handleVis, { top: crop.y - 2, left: crop.x - 2 }]} pointerEvents="none" />
          <View style={[styles.handleVis, { top: crop.y - 2, left: crop.x + crop.w - 18 }]} pointerEvents="none" />
          <View style={[styles.handleVis, { top: crop.y + crop.h - 18, left: crop.x - 2 }]} pointerEvents="none" />
          <View style={[styles.handleVis, { top: crop.y + crop.h - 18, left: crop.x + crop.w - 18 }]} pointerEvents="none" />

          {/* Touch layer on top */}
          <View style={styles.touchLayer} {...panResponder.panHandlers} />
        </View>

        {/* White Toolbar */}
        <View style={styles.toolbar}>
          <TouchableOpacity style={styles.toolBtn} onPress={handleRotate}>
            <View style={[styles.toolIcon, rotation !== 0 && styles.toolIconOn]}>
              <Ionicons name="refresh-outline" size={22} color={rotation !== 0 ? '#FFF' : '#333'} />
            </View>
            <Text style={[styles.toolLabel, rotation !== 0 && styles.toolLabelOn]}>Rotate</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.toolBtn} onPress={handleFlipH}>
            <View style={[styles.toolIcon, flipH && styles.toolIconOn]}>
              <Ionicons name="swap-horizontal-outline" size={22} color={flipH ? '#FFF' : '#333'} />
            </View>
            <Text style={[styles.toolLabel, flipH && styles.toolLabelOn]}>Flip H</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.toolBtn} onPress={handleFlipV}>
            <View style={[styles.toolIcon, flipV && styles.toolIconOn]}>
              <Ionicons name="swap-vertical-outline" size={22} color={flipV ? '#FFF' : '#333'} />
            </View>
            <Text style={[styles.toolLabel, flipV && styles.toolLabelOn]}>Flip V</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.toolBtn} onPress={resetAll}>
            <View style={styles.toolIcon}>
              <Ionicons name="refresh-circle-outline" size={22} color="#333" />
            </View>
            <Text style={styles.toolLabel}>Reset</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF' },
  statusBar: { height: SB, backgroundColor: '#FFF' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 12, height: HDR, backgroundColor: '#FFF',
    borderBottomWidth: 1, borderBottomColor: '#E5E7EB',
  },
  headerBtn: { padding: 8 },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#222' },
  doneBtn: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#4F46E5',
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8, gap: 4,
  },
  doneBtnText: { color: '#FFF', fontWeight: '700', fontSize: 14 },

  cropContainer: {
    width: SW, height: AH, backgroundColor: '#111', overflow: 'hidden',
  },
  touchLayer: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'transparent',
  },
  ov: { position: 'absolute', backgroundColor: 'rgba(0,0,0,0.55)' },
  cropBox: { position: 'absolute', borderWidth: 1.5, borderColor: '#FFF' },
  gridH: { position: 'absolute', left: 0, right: 0, height: 0.5, backgroundColor: 'rgba(255,255,255,0.35)' },
  gridV: { position: 'absolute', top: 0, bottom: 0, width: 0.5, backgroundColor: 'rgba(255,255,255,0.35)' },

  handleVis: {
    position: 'absolute', width: 20, height: 20,
    borderColor: '#FFF', borderWidth: 3, backgroundColor: 'transparent',
  },

  toolbar: {
    flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center',
    paddingTop: 14, paddingBottom: 40, backgroundColor: '#FFF',
    borderTopWidth: 1, borderTopColor: '#E5E7EB', height: TBR,
  },
  toolBtn: { alignItems: 'center', gap: 5 },
  toolIcon: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: '#F3F4F6',
    justifyContent: 'center', alignItems: 'center',
  },
  toolIconOn: { backgroundColor: '#4F46E5' },
  toolLabel: { fontSize: 11, color: '#666', fontWeight: '500' },
  toolLabelOn: { color: '#4F46E5', fontWeight: '700' },
});
