import { StyleSheet } from 'react-native';

// App color palette
export const colors = {
  // Primary
  primary: '#7C3AED',
  primaryLight: '#8B5CF6',
  primaryDark: '#1A0536',
  primaryFaded: 'rgba(139,92,246,0.4)',

  // Backgrounds
  bgDark: '#1A0536',
  bgLight: '#F9FAFB',
  bgWhite: '#FFFFFF',
  bgCard: '#FFFFFF',
  bgModal: '#2D1B69',
  bgInput: 'rgba(255,255,255,0.12)',
  bgInputLight: '#F3F4F6',

  // Borders
  borderLight: '#E5E7EB',
  borderInput: 'rgba(255,255,255,0.2)',

  // Text
  textWhite: '#FFFFFF',
  textDark: '#111827',
  textBody: '#374151',
  textMuted: '#6B7280',
  textPlaceholder: '#9CA3AF',
  textPlaceholderDark: 'rgba(255,255,255,0.45)',
  textWhiteMuted: 'rgba(255,255,255,0.6)',
  textWhiteSoft: 'rgba(255,255,255,0.8)',
  textWhiteLabel: 'rgba(255,255,255,0.9)',

  // Status
  error: '#EF4444',
  errorLight: '#FCA5A5',
  success: '#10B981',
  info: '#3B82F6',

  // Overlay
  overlay: 'rgba(0,0,0,0.7)',
  overlayLight: 'rgba(0,0,0,0.3)',
};

// Common reusable styles
const common = StyleSheet.create({
  // Containers
  screenContainer: {
    flex: 1,
    backgroundColor: colors.bgLight,
  },
  screenContainerDark: {
    flex: 1,
    backgroundColor: colors.bgDark,
  },
  centeredContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    paddingTop: 50,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textDark,
  },
  headerBackButton: {
    fontSize: 28,
    color: colors.textBody,
  },

  // Bottom Navigation
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: colors.bgWhite,
    borderTopWidth: 1,
    borderTopColor: colors.borderLight,
    paddingVertical: 8,
    paddingBottom: 20,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  navItemActive: {},
  navIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  navLabel: {
    fontSize: 12,
    color: colors.textMuted,
  },
  navLabelActive: {
    color: colors.primary,
    fontWeight: '600',
  },

  // Buttons
  buttonPrimary: {
    backgroundColor: colors.primaryLight,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonPrimaryText: {
    color: colors.textWhite,
    fontSize: 14,
    fontWeight: 'bold',
  },

  // Inputs (dark theme - auth screen)
  inputDark: {
    backgroundColor: colors.bgInput,
    padding: 11,
    borderRadius: 8,
    marginBottom: 8,
    fontSize: 14,
    color: colors.textWhite,
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  passwordContainerDark: {
    flexDirection: 'row',
    backgroundColor: colors.bgInput,
    borderRadius: 8,
    marginBottom: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  passwordInputDark: {
    flex: 1,
    padding: 11,
    fontSize: 14,
    color: colors.textWhite,
  },
  eyeButton: {
    paddingHorizontal: 10,
    paddingVertical: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Inputs (light theme)
  inputLight: {
    backgroundColor: colors.bgWhite,
    padding: 12,
    borderRadius: 12,
    fontSize: 16,
    color: colors.textDark,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },

  // Text
  errorText: {
    color: colors.error,
    fontSize: 13,
    marginBottom: 8,
    textAlign: 'center',
  },
  warningText: {
    color: colors.errorLight,
    fontSize: 11,
    marginTop: -5,
    marginBottom: 6,
    marginLeft: 4,
  },
  fieldLabel: {
    color: colors.textWhiteLabel,
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
    marginTop: 2,
  },

  // Empty state
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textDark,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    marginBottom: 24,
  },

  // Loading
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.bgLight,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: colors.textMuted,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.overlayLight,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Modal (dark theme)
  modalOverlay: {
    flex: 1,
    backgroundColor: colors.overlay,
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: colors.bgModal,
    borderRadius: 16,
    padding: 20,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textWhite,
    marginBottom: 15,
    textAlign: 'center',
  },
  modalCloseBtn: {
    padding: 14,
    alignItems: 'center',
    marginTop: 10,
  },
  modalCloseBtnText: {
    fontSize: 16,
    color: colors.textWhiteMuted,
    fontWeight: '600',
  },
});

export default common;
