# Learn & Chat - Mobile Application

## Overview
Learn & Chat is a React Native (Expo) mobile application that combines a structured learning platform with social features. It supports two user roles: **Admin** and **Student**.

**Admin Email:** testingappviji@gmail.com

---

## Tech Stack
- **Framework:** React Native with Expo SDK 54
- **Language:** TypeScript
- **Backend:** Firebase (Auth + Firestore)
- **Navigation:** React Navigation (Stack + Drawer)
- **State:** React useState/useEffect
- **Storage:** AsyncStorage (local), Firestore (cloud)

---

## Features

### For All Users (Students & Admin)

#### Learning Platform (Home Tab)
- Course catalog with progress tracking
- Step-by-step lessons with code examples, output, and tips
- Progress dots, animated transitions between steps
- Course Materials (PDFs) viewable per course
- Search courses by name or description

#### Social Feed (Feed Tab)
- Create posts with text and/or images (Gallery/Camera)
- Posts auto-expire after 24 hours
- Like, comment, share posts
- Pull-to-refresh feed
- Comment modal with real-time updates

#### Search & Friends
- Search users by username or email
- Send/receive friend requests
- Accept/reject requests

#### Messaging
- Real-time 1-on-1 chat
- Friends list with quick chat start
- Unread message count badges
- Search conversations

#### Profile
- Profile image upload
- Edit bio, view follower/following counts
- View own posts
- Logout

---

### Admin-Only Features

#### Drawer Navigation
- Hamburger menu on Learn screen (Admin only)
- Quick access to all modules + admin screens
- Profile header with Admin badge

#### Admin Course PDF Upload (AdminCoursePdfScreen)
- Upload PDFs to any course (max 700KB per file)
- Select course, pick PDF, set display name
- View all uploaded PDFs grouped by course
- Delete PDFs

#### Add Text Course (AddCourseScreen)
- Create new courses with custom icon and color
- Full CRUD: Create, Read, Update, Delete courses
- Add/Edit/Delete lessons within courses
- Add/Edit/Delete steps within lessons (title, explanation, code, output, tip)
- Default courses (HTML, CSS, JS, Python, SQL, React) auto-seeded to Firestore

#### User Management
- View all registered users with stats
- Search users by name or email
- View complete user details (all fields)
- Delete users permanently (removes user + posts + chats + friend requests)
- Admin account protected from deletion

#### Post Moderation
- Delete any user's post from the feed

---

## User Roles

| Feature | Student | Admin |
|---------|---------|-------|
| View courses & lessons | Yes | Yes |
| View PDFs | Yes | Yes |
| Create/like/comment posts | Yes | Yes |
| Send messages | Yes | Yes |
| Drawer navigation | No | Yes |
| Upload PDFs | No | Yes |
| Create/Edit/Delete courses | No | Yes |
| Manage users | No | Yes |
| Delete any post | No | Yes |

---

## Firebase Collections

| Collection | Purpose |
|-----------|---------|
| `users` | User profiles, roles, friends |
| `posts` | Social feed posts (24hr expiry) |
| `chats` | Chat metadata |
| `messages` | Chat messages |
| `friendRequests` | Friend request tracking |
| `stories` | Story posts |
| `coursePdfs` | Uploaded PDF files (base64) |
| `customCourses` | All courses (seeded defaults + admin-created) |

---

## Firebase Security Rules

- **users:** Any auth user reads, own user creates/updates, Admin or self deletes
- **posts:** Any auth user reads/creates, owner or Admin updates/deletes
- **coursePdfs:** Any auth user reads, Admin only writes
- **customCourses:** Any auth user reads, Admin only writes
- **messages/chats/friendRequests/stories:** Any auth user reads/writes

---

## Permissions (Android & iOS)

### Android
- CAMERA - Take photos for posts/profile
- READ_EXTERNAL_STORAGE - Select images from gallery
- WRITE_EXTERNAL_STORAGE - Save images to gallery
- READ_MEDIA_IMAGES - Android 13+ media access
- INTERNET - Firebase connectivity
- ACCESS_NETWORK_STATE - Network status

### iOS
- NSCameraUsageDescription - Camera access
- NSPhotoLibraryUsageDescription - Photo library read
- NSPhotoLibraryAddUsageDescription - Photo library write
- UIFileSharingEnabled - File sharing support
- LSSupportsOpeningDocumentsInPlace - Document access

---

## Project Structure

```
CXAp/
  App.tsx                    # Root component with navigation
  firebase.config.ts         # Firebase initialization with auth persistence
  babel.config.js            # Babel config with reanimated plugin
  app.json                   # Expo config, permissions, plugins
  index.ts                   # Entry point
  src/
    components/
      BottomNav.tsx           # Bottom tab navigation (6 tabs)
      AdminDrawerContent.tsx  # Admin drawer menu
    data/
      courses.ts              # Default course data + types
    screens/
      AuthScreen.tsx           # Login/Register with date picker
      LearnScreen.tsx          # Home - Course catalog
      CourseScreen.tsx          # Lessons list + PDFs per course
      LessonScreen.tsx          # Step-by-step lesson viewer
      FeedScreen.tsx            # Social post feed
      CreatePostScreen.tsx      # Create new post
      SearchScreen.tsx          # Search users + friend requests
      MessagesScreen.tsx        # Chat list
      ChatScreen.tsx            # 1-on-1 chat
      ProfileScreen.tsx         # User profile
      AdminCoursePdfScreen.tsx  # Admin: PDF upload management
      AddCourseScreen.tsx       # Admin: Course/Lesson/Step CRUD
      UserManagementScreen.tsx  # Admin: User list
      UserDetailScreen.tsx      # Admin: User detail + delete
    services/
      auth.ts                  # Auth (signup, signin, role assignment, auto-friend)
      posts.ts                 # Post CRUD with Firestore timestamps
      messages.ts              # Chat & message functions
      friends.ts               # Friend requests, search (hides admin from students)
      stories.ts               # Story functions
      users.ts                 # Admin: user management (getAll, delete)
      coursePdfCreater.ts      # PDF upload/fetch/delete
      courseCreator.ts          # Course CRUD, lesson CRUD, seed defaults
    styles/
      common.ts                # Shared styles & color palette
    types/
      index.ts                 # TypeScript interfaces (User, Post, Chat, CoursePdf, etc.)
```

---

## Setup Instructions

1. Clone/unzip the project
2. Run `yarn install` or `npm install`
3. Run `npx expo start`
4. Scan QR with Expo Go app

### Firebase Setup
1. Create Firebase project
2. Enable Authentication (Email/Password)
3. Enable Firestore Database
4. Copy Firebase config to `firebase.config.ts`
5. Deploy Firestore security rules

### First Admin Login
1. Register with `testingappviji@gmail.com`
2. Role automatically set to "Admin"
3. Default courses auto-seeded to Firestore on first load
4. All other users automatically get "Student" role + friended with Admin

---

## Build APK

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Build APK
eas build -p android --profile preview
```






<!-- 
Just comment out getUserPushToken these blocks:

1. src/services/friends.ts line 123-132 getUserPushToken — Friend request notification

2. src/services/posts.ts — Two places:

Like notification — search for // Notify post owner after likePost function
Comment notification — search for // Notify post owner after addComment function
3. src/services/messages.ts line ~135-145 — Message notification (keep this one enabled)

So comment out the blocks in friends.ts and posts.ts only. The messages.ts one stays active since you want message notifications.

Each block looks like:


// Notify post owner / Send push notification
const token = await getUserPushToken(...);
if (token) {
  await sendPushNotification(token, ...);
}
 -->