// import { initializeApp } from 'firebase/app';
// import { getAuth } from 'firebase/auth';
// import { getFirestore } from 'firebase/firestore';
// import { getStorage } from 'firebase/storage';

// // Replace with your Firebase config
// const firebaseConfig = {
//   apiKey: "YOUR_API_KEY",
//   authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
//   projectId: "YOUR_PROJECT_ID",
//   storageBucket: "YOUR_PROJECT_ID.appspot.com",
//   messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
//   appId: "YOUR_APP_ID"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);

// // Initialize services
// export const auth = getAuth(app);
// export const db = getFirestore(app);
// export const storage = getStorage(app);

// export default app;




// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyCOAMq4CLTpOhg1_6O-BMgU75_QWzVzDVM",
//   authDomain: "connectxapp-bd5bd.firebaseapp.com",
//   projectId: "connectxapp-bd5bd",
//   storageBucket: "connectxapp-bd5bd.firebasestorage.app",
//   messagingSenderId: "242588085076",
//   appId: "1:242588085076:web:c9a6ebef8f537d960276c1",
//   measurementId: "G-167PHX1YVP"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);



import { initializeApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 🔥 REPLACE WITH YOUR FIREBASE CONFIG
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCOAMq4CLTpOhg1_6O-BMgU75_QWzVzDVM",
  authDomain: "connectxapp-bd5bd.firebaseapp.com",
  projectId: "connectxapp-bd5bd",
  storageBucket: "connectxapp-bd5bd.firebasestorage.app",
  messagingSenderId: "242588085076",
  appId: "1:242588085076:web:c9a6ebef8f537d960276c1",
  measurementId: "G-167PHX1YVP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services with auth persistence
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;

/*
HOW TO GET YOUR FIREBASE CONFIG:
1. Go to https://console.firebase.google.com/
2. Select your project
3. Click the gear icon (⚙️) → Project Settings
4. Scroll down to "Your apps"
5. Click on your Android app (or add one if you haven't)
6. Copy the firebaseConfig object
7. Paste it above replacing the placeholder values

EXAMPLE:
const firebaseConfig = {
  apiKey: "AIzaSyC1234567890abcdefghijklmnop",
  authDomain: "connectxapp-12345.firebaseapp.com",
  projectId: "connectxapp-12345",
  storageBucket: "connectxapp-12345.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:android:abcdef1234567890"
};
*/