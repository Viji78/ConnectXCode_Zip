import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { User, CoursePdf } from '../types';
import { courses, Course, Lesson } from '../data/courses';
import { getCoursePdfs, formatFileSize } from '../services/coursePdfCreater';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  route: any;
  user: User;
}

export default function CourseScreen({ navigation, route, user }: Props) {
  const { courseId } = route.params;
  const course = courses.find((c) => c.id === courseId) as Course;
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [pdfs, setPdfs] = useState<CoursePdf[]>([]);

  useEffect(() => {
    loadCompleted();
    loadPdfs();
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadCompleted();
      loadPdfs();
    });
    return unsubscribe;
  }, [navigation]);

  const loadCompleted = async () => {
    try {
      const stored = await AsyncStorage.getItem(`completed_${user.id}_${courseId}`);
      if (stored) setCompletedLessons(JSON.parse(stored));
    } catch {}
  };

  const loadPdfs = async () => {
    try {
      const data = await getCoursePdfs(courseId);
      setPdfs(data);
    } catch (e) {
      console.log('Failed to load PDFs:', e);
      setPdfs([]);
    }
  };

  const handleOpenPdf = async (pdf: CoursePdf) => {
    try {
      const base64 = pdf.base64Data.replace(/^data:application\/pdf;base64,/, '');
      const fileUri = FileSystem.cacheDirectory + pdf.fileName;
      await FileSystem.writeAsStringAsync(fileUri, base64, {
        encoding: FileSystem.EncodingType.Base64,
      });
      await Sharing.shareAsync(fileUri, {
        mimeType: 'application/pdf',
        dialogTitle: pdf.fileName,
      });
    } catch {
      Alert.alert('Error', 'Could not open PDF');
    }
  };

  const percent = Math.round((completedLessons.length / course.lessons.length) * 100);

  const renderLesson = ({ item, index }: { item: Lesson; index: number }) => {
    const isCompleted = completedLessons.includes(item.id);
    const isNext = !isCompleted && index === completedLessons.length;

    return (
      <TouchableOpacity
        style={[styles.lessonCard, isNext && styles.lessonCardActive]}
        onPress={() => navigation.navigate('Lesson', { courseId, lessonId: item.id })}
        activeOpacity={0.7}
      >
        <View style={[
          styles.lessonNumber,
          isCompleted && { backgroundColor: colors.success },
          isNext && { backgroundColor: course.color },
        ]}>
          {isCompleted ? (
            <Ionicons name="checkmark" size={18} color={colors.textWhite} />
          ) : (
            <Text style={[styles.lessonNumberText, (isNext) && { color: colors.textWhite }]}>
              {index + 1}
            </Text>
          )}
        </View>
        <View style={styles.lessonInfo}>
          <Text style={styles.lessonTitle}>{item.title}</Text>
          <View style={styles.lessonMeta}>
            <Ionicons name="time-outline" size={14} color={colors.textPlaceholder} />
            <Text style={styles.lessonDuration}>{item.duration}</Text>
            <Text style={styles.lessonSteps}>{item.steps.length} steps</Text>
          </View>
        </View>
        <Ionicons
          name={isCompleted ? 'checkmark-circle' : isNext ? 'play-circle' : 'chevron-forward'}
          size={24}
          color={isCompleted ? colors.success : isNext ? course.color : colors.textPlaceholder}
        />
      </TouchableOpacity>
    );
  };

  const PdfFooter = () => {
    if (pdfs.length === 0) return null;

    return (
      <View style={styles.pdfSection}>
        <View style={styles.pdfSectionHeader}>
          <Ionicons name="document-text-outline" size={20} color={course.color} />
          <Text style={styles.pdfSectionTitle}>Course Materials ({pdfs.length})</Text>
        </View>
        {pdfs.map((pdf) => (
          <TouchableOpacity
            key={pdf.id}
            style={styles.pdfCard}
            onPress={() => handleOpenPdf(pdf)}
            activeOpacity={0.7}
          >
            <View style={[styles.pdfIcon, { backgroundColor: course.color + '18' }]}>
              <Ionicons name="document-text" size={22} color={course.color} />
            </View>
            <View style={styles.pdfInfo}>
              <Text style={styles.pdfName} numberOfLines={1}>{pdf.fileName}</Text>
              <Text style={styles.pdfMeta}>{formatFileSize(pdf.fileSize)}</Text>
            </View>
            <Ionicons name="open-outline" size={20} color={colors.textPlaceholder} />
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={[styles.headerBg, { backgroundColor: course.color }]}>
        <View style={styles.headerTop}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={colors.textWhite} />
          </TouchableOpacity>
        </View>
        <View style={styles.headerContent}>
          <Ionicons name={course.icon as any} size={48} color={colors.textWhite} />
          <Text style={styles.headerTitle}>{course.title}</Text>
          <Text style={styles.headerDesc}>{course.description}</Text>
          <View style={styles.headerProgress}>
            <View style={styles.headerProgressBarBg}>
              <View style={[styles.headerProgressBarFill, { width: `${percent}%` }]} />
            </View>
            <Text style={styles.headerProgressText}>
              {completedLessons.length}/{course.lessons.length} lessons · {percent}%
            </Text>
          </View>
        </View>
      </View>

      {/* Lessons + PDFs */}
      <FlatList
        data={course.lessons}
        keyExtractor={(item) => item.id}
        renderItem={renderLesson}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListFooterComponent={<PdfFooter />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  headerBg: {
    paddingTop: 50,
    paddingBottom: 24,
  },
  headerTop: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  backBtn: {
    padding: 4,
  },
  headerContent: {
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.textWhite,
    marginTop: 8,
  },
  headerDesc: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 4,
  },
  headerProgress: {
    width: '100%',
    marginTop: 16,
  },
  headerProgressBarBg: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  headerProgressBarFill: {
    height: 8,
    backgroundColor: colors.textWhite,
    borderRadius: 4,
  },
  headerProgressText: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 6,
    textAlign: 'center',
  },
  list: {
    padding: 16,
    paddingBottom: 32,
  },
  lessonCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  lessonCardActive: {
    borderColor: colors.primary,
    borderWidth: 1.5,
  },
  lessonNumber: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  lessonNumberText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textMuted,
  },
  lessonInfo: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textDark,
  },
  lessonMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  lessonDuration: {
    fontSize: 12,
    color: colors.textPlaceholder,
  },
  lessonSteps: {
    fontSize: 12,
    color: colors.textPlaceholder,
    marginLeft: 8,
  },
  // PDF Section
  pdfSection: {
    marginTop: 10,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.borderLight,
  },
  pdfSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  pdfSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textDark,
  },
  pdfCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  pdfIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  pdfInfo: {
    flex: 1,
  },
  pdfName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textDark,
  },
  pdfMeta: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
});
