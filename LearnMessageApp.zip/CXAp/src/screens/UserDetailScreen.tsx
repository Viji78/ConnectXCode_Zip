import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { User } from '../types';
import { getUserById, deleteUserCompletely } from '../services/users';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  route: any;
  user: User;
}

export default function UserDetailScreen({ navigation, route, user }: Props) {
  const { userId } = route.params;
  const [userData, setUserData] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    setLoading(true);
    try {
      const data = await getUserById(userId);
      setUserData(data);
    } catch {}
    setLoading(false);
  };

  const handleDelete = () => {
    if (!userData) return;
    if (userData.user_role === 'Admin') {
      Alert.alert('Cannot Delete', 'Admin account cannot be deleted.');
      return;
    }

    Alert.alert(
      'Delete User',
      `Permanently delete "${userData.username}" and all their data?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteUserCompletely(userData.id);
              Alert.alert('Deleted', `"${userData.username}" removed.`);
              navigation.goBack();
            } catch {
              Alert.alert('Error', 'Failed to delete user');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={common.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!userData) {
    return (
      <View style={common.loadingContainer}>
        <Text style={{ color: colors.textMuted }}>User not found</Text>
      </View>
    );
  }

  const fields = [
    { label: 'User ID', value: userData.id, icon: 'finger-print-outline' },
    { label: 'Username', value: userData.username, icon: 'person-outline' },
    { label: 'Email', value: userData.email, icon: 'mail-outline' },
    { label: 'Role', value: userData.user_role, icon: 'shield-outline' },
    { label: 'Country', value: `${userData.country} (${userData.countryCode})`, icon: 'globe-outline' },
    { label: 'Phone', value: userData.phoneNumber, icon: 'call-outline' },
    { label: 'Date of Birth', value: userData.dateOfBirth, icon: 'calendar-outline' },
    { label: 'Bio', value: userData.bio || 'No bio', icon: 'document-text-outline' },
    { label: 'Followers', value: String(userData.followers), icon: 'people-outline' },
    { label: 'Following', value: String(userData.following), icon: 'person-add-outline' },
    { label: 'Friends', value: `${userData.friends.length} friends`, icon: 'heart-outline' },
    { label: 'Joined', value: new Date(userData.createdAt).toLocaleString(), icon: 'time-outline' },
  ];

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>User Details</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Profile Card */}
        <View style={styles.profileCard}>
          {userData.profileImage && userData.profileImage.length > 2 ? (
            <Image source={{ uri: userData.profileImage }} style={styles.profileImage} />
          ) : (
            <View style={[styles.profileImagePlaceholder, userData.user_role === 'Admin' && { backgroundColor: colors.primary }]}>
              <Text style={styles.profileImageLetter}>
                {userData.username.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
          <Text style={styles.profileName}>{userData.username}</Text>
          <View style={[styles.roleBadge, userData.user_role === 'Admin' ? styles.roleBadgeAdmin : styles.roleBadgeStudent]}>
            <Ionicons
              name={userData.user_role === 'Admin' ? 'shield-checkmark' : 'school-outline'}
              size={14}
              color={userData.user_role === 'Admin' ? colors.primary : colors.textMuted}
            />
            <Text style={[styles.roleBadgeText, userData.user_role === 'Admin' && { color: colors.primary }]}>
              {userData.user_role}
            </Text>
          </View>
        </View>

        {/* Data Fields */}
        <View style={styles.fieldsContainer}>
          {fields.map((field, index) => (
            <View key={index} style={styles.fieldRow}>
              <View style={styles.fieldIconBox}>
                <Ionicons name={field.icon as any} size={18} color={colors.primary} />
              </View>
              <View style={styles.fieldContent}>
                <Text style={styles.fieldLabel}>{field.label}</Text>
                <Text style={styles.fieldValue} selectable>{field.value}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Friends List */}
        {userData.friends.length > 0 && (
          <View style={styles.friendsSection}>
            <Text style={styles.sectionTitle}>Friend IDs ({userData.friends.length})</Text>
            {userData.friends.map((fId, i) => (
              <TouchableOpacity
                key={i}
                style={styles.friendIdRow}
                onPress={() => {
                  if (fId !== userId) {
                    navigation.push('UserDetail', { userId: fId });
                  }
                }}
              >
                <Ionicons name="person-circle-outline" size={18} color={colors.textMuted} />
                <Text style={styles.friendIdText} selectable>{fId}</Text>
                <Ionicons name="chevron-forward" size={16} color={colors.textPlaceholder} />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Delete Button */}
        {userData.user_role !== 'Admin' && (
          <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
            <Ionicons name="trash" size={20} color={colors.textWhite} />
            <Text style={styles.deleteButtonText}>Delete User Permanently</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 52,
    paddingBottom: 12,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  backBtn: { padding: 4, marginRight: 10 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: colors.textDark, flex: 1 },
  deleteHeaderBtn: { padding: 4 },
  scroll: { flex: 1 },
  profileCard: {
    alignItems: 'center',
    paddingVertical: 24,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: colors.borderLight,
  },
  profileImagePlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.bgInputLight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImageLetter: { fontSize: 32, fontWeight: 'bold', color: colors.textWhite },
  profileName: { fontSize: 22, fontWeight: 'bold', color: colors.textDark, marginTop: 10 },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  roleBadgeAdmin: { backgroundColor: colors.primary + '15' },
  roleBadgeStudent: { backgroundColor: colors.bgInputLight },
  roleBadgeText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  fieldsContainer: { padding: 16 },
  fieldRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.bgWhite,
    borderRadius: 12,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  fieldIconBox: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: colors.primary + '12',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  fieldContent: { flex: 1 },
  fieldLabel: { fontSize: 11, fontWeight: '600', color: colors.textPlaceholder, textTransform: 'uppercase' },
  fieldValue: { fontSize: 15, color: colors.textDark, marginTop: 2 },
  friendsSection: { paddingHorizontal: 16, marginBottom: 16 },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: colors.textBody, marginBottom: 8 },
  friendIdRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.bgWhite,
    borderRadius: 10,
    padding: 10,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  friendIdText: { flex: 1, fontSize: 12, color: colors.textMuted, fontFamily: 'monospace' },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.error,
    borderRadius: 12,
    paddingVertical: 14,
    marginHorizontal: 16,
  },
  deleteButtonText: { fontSize: 15, fontWeight: '700', color: colors.textWhite },
});
