import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';
import { courses, LessonStep } from '../data/courses';
import common, { colors } from '../styles/common';

interface Props {
  navigation: any;
  route: any;
  user: User;
}

export default function LessonScreen({ navigation, route, user }: Props) {
  const { courseId, lessonId } = route.params;
  const course = courses.find((c) => c.id === courseId)!;
  const lesson = course.lessons.find((l) => l.id === lessonId)!;
  const [currentStep, setCurrentStep] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const step = lesson.steps[currentStep];
  const isFirst = currentStep === 0;
  const isLast = currentStep === lesson.steps.length - 1;

  const animateTransition = (next: number) => {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
    setTimeout(() => {
      setCurrentStep(next);
      scrollRef.current?.scrollTo({ y: 0, animated: false });
    }, 120);
  };

  const handleNext = () => {
    if (!isLast) {
      animateTransition(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (!isFirst) {
      animateTransition(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    try {
      // Save lesson as completed
      const key = `completed_${user.id}_${courseId}`;
      const stored = await AsyncStorage.getItem(key);
      const completed: string[] = stored ? JSON.parse(stored) : [];
      if (!completed.includes(lessonId)) {
        completed.push(lessonId);
        await AsyncStorage.setItem(key, JSON.stringify(completed));
      }
      // Update course progress count
      const progressKey = `learn_progress_${user.id}`;
      const progressStored = await AsyncStorage.getItem(progressKey);
      const progress: { [id: string]: number } = progressStored ? JSON.parse(progressStored) : {};
      progress[courseId] = completed.length;
      await AsyncStorage.setItem(progressKey, JSON.stringify(progress));
    } catch {}
    navigation.goBack();
  };

  const renderStep = (s: LessonStep) => (
    <Animated.View style={[styles.stepContent, { opacity: fadeAnim }]}>
      <Text style={styles.stepTitle}>{s.title}</Text>
      <Text style={styles.stepExplanation}>{s.explanation}</Text>

      {s.code && (
        <View style={styles.codeBlock}>
          <View style={styles.codeHeader}>
            <Ionicons name="code-slash" size={14} color={colors.textPlaceholder} />
            <Text style={styles.codeHeaderText}>Example</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Text style={styles.codeText}>{s.code}</Text>
          </ScrollView>
        </View>
      )}

      {s.output && (
        <View style={styles.outputBlock}>
          <View style={styles.codeHeader}>
            <Ionicons name="terminal-outline" size={14} color={colors.success} />
            <Text style={[styles.codeHeaderText, { color: colors.success }]}>Output</Text>
          </View>
          <Text style={styles.outputText}>{s.output}</Text>
        </View>
      )}

      {s.tip && (
        <View style={styles.tipBox}>
          <Ionicons name="bulb-outline" size={18} color="#F59E0B" />
          <Text style={styles.tipText}>{s.tip}</Text>
        </View>
      )}
    </Animated.View>
  );

  return (
    <View style={common.screenContainer}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={colors.textDark} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle} numberOfLines={1}>{lesson.title}</Text>
          <Text style={styles.headerSub}>
            Step {currentStep + 1} of {lesson.steps.length}
          </Text>
        </View>
        <View style={{ width: 32 }} />
      </View>

      {/* Step Progress Dots */}
      <View style={styles.dotsRow}>
        {lesson.steps.map((_, i) => (
          <View
            key={i}
            style={[
              styles.dot,
              i <= currentStep && { backgroundColor: course.color },
              i === currentStep && styles.dotActive,
            ]}
          />
        ))}
      </View>

      {/* Step Content */}
      <ScrollView
        ref={scrollRef}
        style={styles.scrollContent}
        contentContainerStyle={styles.scrollInner}
        showsVerticalScrollIndicator={false}
      >
        {renderStep(step)}
      </ScrollView>

      {/* Navigation Buttons */}
      <View style={styles.navBar}>
        <TouchableOpacity
          style={[styles.navBtn, isFirst && styles.navBtnDisabled]}
          onPress={handlePrev}
          disabled={isFirst}
        >
          <Ionicons name="arrow-back" size={20} color={isFirst ? colors.textPlaceholder : colors.textDark} />
          <Text style={[styles.navBtnText, isFirst && styles.navBtnTextDisabled]}>Previous</Text>
        </TouchableOpacity>

        {isLast ? (
          <TouchableOpacity
            style={[styles.navBtn, styles.completeBtn]}
            onPress={handleComplete}
          >
            <Ionicons name="checkmark-circle" size={20} color={colors.textWhite} />
            <Text style={styles.completeBtnText}>Complete</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={[styles.navBtn, styles.nextBtn]} onPress={handleNext}>
            <Text style={styles.nextBtnText}>Next</Text>
            <Ionicons name="arrow-forward" size={20} color={colors.textWhite} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 52,
    paddingBottom: 10,
    backgroundColor: colors.bgWhite,
    borderBottomWidth: 0.5,
    borderBottomColor: colors.borderLight,
  },
  backBtn: {
    padding: 4,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textDark,
  },
  headerSub: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 1,
  },
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 6,
    backgroundColor: colors.bgWhite,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.borderLight,
  },
  dotActive: {
    width: 24,
    borderRadius: 4,
  },
  scrollContent: {
    flex: 1,
  },
  scrollInner: {
    padding: 20,
    paddingBottom: 32,
  },
  stepContent: {},
  stepTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.textDark,
    marginBottom: 12,
  },
  stepExplanation: {
    fontSize: 16,
    lineHeight: 24,
    color: colors.textBody,
    marginBottom: 16,
  },
  codeBlock: {
    backgroundColor: '#1E1E2E',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 14,
  },
  codeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  codeHeaderText: {
    fontSize: 12,
    color: colors.textPlaceholder,
    fontWeight: '600',
  },
  codeText: {
    fontFamily: 'monospace',
    fontSize: 14,
    lineHeight: 22,
    color: '#E2E8F0',
    padding: 14,
  },
  outputBlock: {
    backgroundColor: '#0F2A1A',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 14,
  },
  outputText: {
    fontFamily: 'monospace',
    fontSize: 14,
    lineHeight: 22,
    color: '#6EE7B7',
    padding: 14,
  },
  tipBox: {
    flexDirection: 'row',
    backgroundColor: '#FFFBEB',
    borderRadius: 12,
    padding: 14,
    gap: 10,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 21,
    color: '#92400E',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    paddingBottom: 28,
    backgroundColor: colors.bgWhite,
    borderTopWidth: 0.5,
    borderTopColor: colors.borderLight,
    gap: 12,
  },
  navBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: colors.bgInputLight,
  },
  navBtnDisabled: {
    opacity: 0.5,
  },
  navBtnText: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textDark,
  },
  navBtnTextDisabled: {
    color: colors.textPlaceholder,
  },
  nextBtn: {
    backgroundColor: colors.primary,
    flex: 1,
    justifyContent: 'center',
  },
  nextBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
  completeBtn: {
    backgroundColor: colors.success,
    flex: 1,
    justifyContent: 'center',
  },
  completeBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textWhite,
  },
});
