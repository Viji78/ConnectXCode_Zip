import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Modal,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { signUp, signIn } from '../services/auth';
import common, { colors } from '../styles/common';

const COUNTRIES = [
  { name: 'India', code: '+91', flag: '🇮🇳' },
  { name: 'United States', code: '+1', flag: '🇺🇸' },
  { name: 'United Kingdom', code: '+44', flag: '🇬🇧' },
  { name: 'Canada', code: '+1', flag: '🇨🇦' },
  { name: 'Australia', code: '+61', flag: '🇦🇺' },
  { name: 'Germany', code: '+49', flag: '🇩🇪' },
  { name: 'France', code: '+33', flag: '🇫🇷' },
  { name: 'Japan', code: '+81', flag: '🇯🇵' },
  { name: 'China', code: '+86', flag: '🇨🇳' },
  { name: 'Brazil', code: '+55', flag: '🇧🇷' },
  { name: 'South Korea', code: '+82', flag: '🇰🇷' },
  { name: 'Mexico', code: '+52', flag: '🇲🇽' },
  { name: 'Italy', code: '+39', flag: '🇮🇹' },
  { name: 'Spain', code: '+34', flag: '🇪🇸' },
  { name: 'Russia', code: '+7', flag: '🇷🇺' },
  { name: 'South Africa', code: '+27', flag: '🇿🇦' },
  { name: 'Nigeria', code: '+234', flag: '🇳🇬' },
  { name: 'Saudi Arabia', code: '+966', flag: '🇸🇦' },
  { name: 'UAE', code: '+971', flag: '🇦🇪' },
  { name: 'Singapore', code: '+65', flag: '🇸🇬' },
  { name: 'Malaysia', code: '+60', flag: '🇲🇾' },
  { name: 'Indonesia', code: '+62', flag: '🇮🇩' },
  { name: 'Pakistan', code: '+92', flag: '🇵🇰' },
  { name: 'Bangladesh', code: '+880', flag: '🇧🇩' },
  { name: 'Sri Lanka', code: '+94', flag: '🇱🇰' },
  { name: 'Nepal', code: '+977', flag: '🇳🇵' },
  { name: 'Thailand', code: '+66', flag: '🇹🇭' },
  { name: 'Philippines', code: '+63', flag: '🇵🇭' },
  { name: 'New Zealand', code: '+64', flag: '🇳🇿' },
  { name: 'Argentina', code: '+54', flag: '🇦🇷' },
];

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

function getDaysInMonth(month: number, year: number): number {
  return new Date(year, month + 1, 0).getDate();
}

function generateYears(): number[] {
  const currentYear = new Date().getFullYear();
  const years: number[] = [];
  for (let y = currentYear - 13; y >= currentYear - 100; y--) {
    years.push(y);
  }
  return years;
}

export default function AuthScreen({ onAuthSuccess }: any) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Country picker
  const [selectedCountry, setSelectedCountry] = useState(COUNTRIES[0]);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');

  // Date of birth picker
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(0);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear() - 18);
  const [selectedDay, setSelectedDay] = useState(1);
  const [dateOfBirth, setDateOfBirth] = useState('');

  // Password visibility
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Date picker sub-view
  const [datePickerView, setDatePickerView] = useState<'main' | 'month' | 'year'>('main');

  const filteredCountries = COUNTRIES.filter((c) =>
    c.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
    c.code.includes(countrySearch)
  );

  const handleAuth = async () => {
    setErrorMessage('');

    if (!email || !password) {
      setErrorMessage('Please fill all fields');
      return;
    }

    if (isSignUp) {
      if (!username) {
        setErrorMessage('Please enter a username');
        return;
      }
      if (!phoneNumber || phoneNumber.length !== 10) {
        setErrorMessage('Please enter a valid 10-digit mobile number');
        return;
      }
      if (!dateOfBirth) {
        setErrorMessage('Please select your date of birth');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMessage('Passwords do not match');
        return;
      }
      if (password.length < 6) {
        setErrorMessage('Password must be at least 6 characters');
        return;
      }
    }

    setLoading(true);

    try {
      if (isSignUp) {
        const user = await signUp(
          email,
          password,
          username,
          selectedCountry.name,
          selectedCountry.code,
          phoneNumber,
          dateOfBirth
        );
        onAuthSuccess(user);
      } else {
        const user = await signIn(email, password);
        onAuthSuccess(user);
      }
    } catch (error: any) {
      const code = error.code || '';
      const msg = error.message || 'Something went wrong';
      if (code === 'auth/user-not-found') {
        setErrorMessage('This email is not registered. Please sign up.');
      } else if (code === 'auth/wrong-password') {
        setErrorMessage('Incorrect password. Please try again.');
      } else if (code === 'auth/invalid-credential') {
        if (!isSignUp) {
          setErrorMessage('Email not registered or incorrect password.');
        } else {
          setErrorMessage('Invalid credentials. Please try again.');
        }
      } else if (code === 'auth/email-already-in-use') {
        setErrorMessage('This email is already registered.');
      } else if (code === 'auth/invalid-email') {
        setErrorMessage('Please enter a valid email address.');
      } else if (code === 'auth/too-many-requests') {
        setErrorMessage('Too many attempts. Please try again later.');
      } else {
        setErrorMessage(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  const confirmDate = () => {
    const daysInMonth = getDaysInMonth(selectedMonth, selectedYear);
    const day = Math.min(selectedDay, daysInMonth);
    const formatted = `${String(day).padStart(2, '0')}/${String(selectedMonth + 1).padStart(2, '0')}/${selectedYear}`;
    setDateOfBirth(formatted);
    setShowDatePicker(false);
    setDatePickerView('main');
  };

  const daysInCurrentMonth = getDaysInMonth(selectedMonth, selectedYear);
  const days = Array.from({ length: daysInCurrentMonth }, (_, i) => i + 1);
  const years = generateYears();

  return (
    <ScrollView
      contentContainerStyle={styles.scrollContainer}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.container}>
        <Text style={styles.logo}>🚀</Text>
        <Text style={styles.title}>Learn & Chat</Text>
        <Text style={styles.subtitle}>Learn, share & connect with friends</Text>

        <View style={styles.form}>
          {isSignUp && (
            <>
              {/* Username */}
              <TextInput
                style={common.inputDark}
                placeholder="Username"
                placeholderTextColor={colors.textPlaceholderDark}
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
              />

              {/* Email */}
              <TextInput
                style={common.inputDark}
                placeholder="Email Address"
                placeholderTextColor={colors.textPlaceholderDark}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              {/* Country + Phone */}
              <Text style={common.fieldLabel}>Country & Mobile Number</Text>
              <TouchableOpacity
                style={styles.countrySelector}
                onPress={() => setShowCountryPicker(true)}
              >
                <Text style={styles.countrySelectorText}>
                  {selectedCountry.flag} {selectedCountry.name} ({selectedCountry.code})
                </Text>
                <Text style={styles.dropdownArrow}>▼</Text>
              </TouchableOpacity>

              <View style={styles.phoneRow}>
                <View style={styles.phoneCodeBox}>
                  <Text style={styles.phoneCodeText}>{selectedCountry.code}</Text>
                </View>
                <TextInput
                  style={styles.phoneInput}
                  placeholder="Mobile Number"
                  placeholderTextColor={colors.textPlaceholderDark}
                  value={phoneNumber}
                  onChangeText={(text) => {
                    const digits = text.replace(/[^0-9]/g, '');
                    if (digits.length <= 10) setPhoneNumber(digits);
                  }}
                  keyboardType="phone-pad"
                  maxLength={10}
                />
              </View>

              {/* Date of Birth */}
              <Text style={common.fieldLabel}>Date of Birth</Text>
              <TouchableOpacity
                style={styles.dateSelector}
                onPress={() => setShowDatePicker(true)}
              >
                <Text style={dateOfBirth ? styles.dateText : styles.datePlaceholder}>
                  {dateOfBirth || 'Select Date of Birth'}
                </Text>
                <Text style={styles.calendarIcon}>📅</Text>
              </TouchableOpacity>

              {/* Password */}
              <View style={common.passwordContainerDark}>
                <TextInput
                  style={common.passwordInputDark}
                  placeholder="Password"
                  placeholderTextColor={colors.textPlaceholderDark}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                />
                <TouchableOpacity
                  style={common.eyeButton}
                  onPress={() => setShowPassword(!showPassword)}
                >
                  <Ionicons name={showPassword ? 'eye-off' : 'eye'} size={22} color={colors.textWhiteMuted} />
                </TouchableOpacity>
              </View>

              {/* Confirm Password */}
              <View style={common.passwordContainerDark}>
                <TextInput
                  style={common.passwordInputDark}
                  placeholder="Confirm Password"
                  placeholderTextColor={colors.textPlaceholderDark}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showConfirmPassword}
                />
                <TouchableOpacity
                  style={common.eyeButton}
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  <Ionicons name={showConfirmPassword ? 'eye' : 'eye-off'} size={22} color={colors.textWhiteMuted} />
                </TouchableOpacity>
              </View>
              {confirmPassword.length > 0 && password !== confirmPassword && (
                <Text style={common.warningText}>Passwords do not match</Text>
              )}
            </>
          )}

          {!isSignUp && (
            <>
              <TextInput
                style={common.inputDark}
                placeholder="Email"
                placeholderTextColor={colors.textPlaceholderDark}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
              <View style={common.passwordContainerDark}>
                <TextInput
                  style={common.passwordInputDark}
                  placeholder="Password"
                  placeholderTextColor={colors.textPlaceholderDark}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                />
                <TouchableOpacity
                  style={common.eyeButton}
                  onPress={() => setShowPassword(!showPassword)}
                >
                  <Ionicons name={showPassword ? 'eye-off' : 'eye'} size={22} color={colors.textWhiteMuted} />
                </TouchableOpacity>
              </View>
            </>
          )}

          {errorMessage !== '' && (
            <Text style={common.errorText}>{errorMessage}</Text>
          )}

          <TouchableOpacity
            style={common.buttonPrimary}
            onPress={handleAuth}
            disabled={loading}
          >
            <Text style={common.buttonPrimaryText}>
              {loading ? 'Loading...' : isSignUp ? 'Sign Up' : 'Login'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => { setIsSignUp(!isSignUp); setErrorMessage(''); }}>
            <Text style={styles.switchText}>
              {isSignUp
                ? 'Already have an account? Login'
                : "Don't have an account? Sign Up"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Country Picker Modal */}
        <Modal visible={showCountryPicker} animationType="slide" transparent>
          <View style={common.modalOverlay}>
            <View style={common.modalContent}>
              <Text style={common.modalTitle}>Select Country</Text>
              <TextInput
                style={styles.searchInput}
                placeholder="Search country..."
                placeholderTextColor={colors.textPlaceholderDark}
                value={countrySearch}
                onChangeText={setCountrySearch}
              />
              <FlatList
                data={filteredCountries}
                keyExtractor={(item) => item.name}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={[
                      styles.listItem,
                      item.name === selectedCountry.name && styles.listItemSelected,
                    ]}
                    onPress={() => {
                      setSelectedCountry(item);
                      setShowCountryPicker(false);
                      setCountrySearch('');
                    }}
                  >
                    <Text style={styles.listItemText}>
                      {item.flag}  {item.name} ({item.code})
                    </Text>
                  </TouchableOpacity>
                )}
              />
              <TouchableOpacity
                style={common.modalCloseBtn}
                onPress={() => {
                  setShowCountryPicker(false);
                  setCountrySearch('');
                }}
              >
                <Text style={common.modalCloseBtnText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Date Picker Modal */}
        <Modal visible={showDatePicker} animationType="slide" transparent>
          <View style={common.modalOverlay}>
            <View style={common.modalContent}>
              <Text style={common.modalTitle}>Select Date of Birth</Text>

              {datePickerView === 'main' && (
                <>
                  {/* Month & Year selectors */}
                  <View style={styles.dateHeaderRow}>
                    <TouchableOpacity
                      style={styles.dateHeaderBtn}
                      onPress={() => setDatePickerView('month')}
                    >
                      <Text style={styles.dateHeaderBtnText}>
                        {MONTHS[selectedMonth]} ▼
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.dateHeaderBtn}
                      onPress={() => setDatePickerView('year')}
                    >
                      <Text style={styles.dateHeaderBtnText}>
                        {selectedYear} ▼
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {/* Day labels */}
                  <View style={styles.dayLabelsRow}>
                    {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                      <Text key={d} style={styles.dayLabel}>{d}</Text>
                    ))}
                  </View>

                  {/* Day grid */}
                  <View style={styles.daysGrid}>
                    {Array.from(
                      { length: new Date(selectedYear, selectedMonth, 1).getDay() },
                      (_, i) => (
                        <View key={`empty-${i}`} style={styles.dayCell} />
                      )
                    )}
                    {days.map((day) => (
                      <TouchableOpacity
                        key={day}
                        style={[
                          styles.dayCell,
                          day === selectedDay && styles.dayCellSelected,
                        ]}
                        onPress={() => setSelectedDay(day)}
                      >
                        <Text
                          style={[
                            styles.dayCellText,
                            day === selectedDay && styles.dayCellTextSelected,
                          ]}
                        >
                          {day}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <View style={styles.dateActionRow}>
                    <TouchableOpacity
                      style={common.modalCloseBtn}
                      onPress={() => {
                        setShowDatePicker(false);
                        setDatePickerView('main');
                      }}
                    >
                      <Text style={common.modalCloseBtnText}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.dateConfirmBtn}
                      onPress={confirmDate}
                    >
                      <Text style={styles.dateConfirmBtnText}>Confirm</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}

              {datePickerView === 'month' && (
                <FlatList
                  data={MONTHS}
                  keyExtractor={(item) => item}
                  renderItem={({ item, index }) => (
                    <TouchableOpacity
                      style={[
                        styles.listItem,
                        index === selectedMonth && styles.listItemSelected,
                      ]}
                      onPress={() => {
                        setSelectedMonth(index);
                        setDatePickerView('main');
                      }}
                    >
                      <Text style={styles.listItemText}>{item}</Text>
                    </TouchableOpacity>
                  )}
                />
              )}

              {datePickerView === 'year' && (
                <FlatList
                  data={years}
                  keyExtractor={(item) => String(item)}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      style={[
                        styles.listItem,
                        item === selectedYear && styles.listItemSelected,
                      ]}
                      onPress={() => {
                        setSelectedYear(item);
                        setDatePickerView('main');
                      }}
                    >
                      <Text style={styles.listItemText}>{item}</Text>
                    </TouchableOpacity>
                  )}
                />
              )}
            </View>
          </View>
        </Modal>
      </View>
    </ScrollView>
  );
}

// Screen-specific styles only
const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    backgroundColor: colors.bgDark,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    paddingTop: 50,
    paddingBottom: 30,
  },
  logo: {
    fontSize: 44,
    marginBottom: 6,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: colors.textWhite,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: colors.textWhiteSoft,
    marginBottom: 18,
  },
  form: {
    width: '100%',
    maxWidth: 400,
  },
  countrySelector: {
    backgroundColor: colors.bgInput,
    padding: 11,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  countrySelectorText: {
    fontSize: 14,
    color: colors.textWhite,
  },
  dropdownArrow: {
    fontSize: 10,
    color: colors.textWhiteMuted,
  },
  phoneRow: {
    flexDirection: 'row',
    marginBottom: 8,
    gap: 6,
  },
  phoneCodeBox: {
    backgroundColor: 'rgba(167,139,250,0.3)',
    padding: 11,
    borderRadius: 8,
    justifyContent: 'center',
    minWidth: 55,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(167,139,250,0.5)',
  },
  phoneCodeText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textWhite,
  },
  phoneInput: {
    flex: 1,
    backgroundColor: colors.bgInput,
    padding: 11,
    borderRadius: 8,
    fontSize: 14,
    color: colors.textWhite,
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  dateSelector: {
    backgroundColor: colors.bgInput,
    padding: 11,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  dateText: {
    fontSize: 14,
    color: colors.textWhite,
  },
  datePlaceholder: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.5)',
  },
  calendarIcon: {
    fontSize: 16,
  },
  switchText: {
    color: colors.textWhite,
    textAlign: 'center',
    fontSize: 13,
    marginTop: 8,
  },
  // Modal list items
  searchInput: {
    backgroundColor: colors.bgInput,
    padding: 12,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 10,
    color: colors.textWhite,
    borderWidth: 1,
    borderColor: colors.borderInput,
  },
  listItem: {
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  listItemSelected: {
    backgroundColor: colors.primaryFaded,
  },
  listItemText: {
    fontSize: 16,
    color: colors.textWhite,
  },
  // Date picker
  dateHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 15,
  },
  dateHeaderBtn: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  dateHeaderBtnText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textWhite,
  },
  dayLabelsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 8,
  },
  dayLabel: {
    width: 40,
    textAlign: 'center',
    fontSize: 13,
    fontWeight: '600',
    color: colors.textWhiteMuted,
  },
  daysGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  dayCell: {
    width: `${100 / 7}%`,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dayCellSelected: {
    backgroundColor: colors.primaryLight,
    borderRadius: 20,
  },
  dayCellText: {
    fontSize: 15,
    color: colors.textWhite,
  },
  dayCellTextSelected: {
    color: colors.textWhite,
    fontWeight: 'bold',
  },
  dateActionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  dateConfirmBtn: {
    backgroundColor: colors.primaryLight,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 10,
  },
  dateConfirmBtnText: {
    color: colors.textWhite,
    fontSize: 16,
    fontWeight: '600',
  },
});
