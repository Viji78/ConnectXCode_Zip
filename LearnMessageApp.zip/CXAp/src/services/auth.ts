import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, setDoc, getDoc, collection, getDocs, query, where, updateDoc, arrayUnion, increment } from 'firebase/firestore';
import { auth, db } from '../../firebase.config';
import { User } from '../types';

const ADMIN_EMAIL = 'testingappviji@gmail.com';

const autoFriendWithAdmin = async (newUserId: string): Promise<void> => {
  try {
    const q = query(collection(db, 'users'), where('user_role', '==', 'Admin'));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return;

    const adminDoc = snapshot.docs[0];
    const adminId = adminDoc.id;
    if (adminId === newUserId) return;

    await updateDoc(doc(db, 'users', adminId), {
      friends: arrayUnion(newUserId),
      followers: increment(1),
      following: increment(1),
    });
    await updateDoc(doc(db, 'users', newUserId), {
      friends: arrayUnion(adminId),
      followers: increment(1),
      following: increment(1),
    });
  } catch {}
};

const adminFriendAllUsers = async (adminId: string): Promise<void> => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    for (const userDoc of snapshot.docs) {
      const userId = userDoc.id;
      if (userId === adminId) continue;

      await updateDoc(doc(db, 'users', adminId), {
        friends: arrayUnion(userId),
        followers: increment(1),
        following: increment(1),
      });
      await updateDoc(doc(db, 'users', userId), {
        friends: arrayUnion(adminId),
        followers: increment(1),
        following: increment(1),
      });
    }
  } catch {}
};

export const signUp = async (
  email: string,
  password: string,
  username: string,
  country: string,
  countryCode: string,
  phoneNumber: string,
  dateOfBirth: string
): Promise<User> => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  const isAdmin = email.toLowerCase() === ADMIN_EMAIL;

  const user: User = {
    id: firebaseUser.uid,
    username,
    email,
    country,
    countryCode,
    phoneNumber,
    dateOfBirth,
    bio: 'New user on Learn & Chat',
    followers: 0,
    following: 0,
    friends: [],
    user_role: isAdmin ? 'Admin' : 'Student',
    createdAt: new Date().toISOString()
  };

  await setDoc(doc(db, 'users', firebaseUser.uid), user);

  if (isAdmin) {
    await adminFriendAllUsers(firebaseUser.uid);
  } else {
    await autoFriendWithAdmin(firebaseUser.uid);
  }

  // Re-fetch to get updated friends list
  const updatedDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
  if (updatedDoc.exists()) {
    return updatedDoc.data() as User;
  }

  return user;
};

export const signIn = async (
  email: string,
  password: string
): Promise<User> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const firebaseUser = userCredential.user;

  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));

  if (!userDoc.exists()) {
    throw new Error('User data not found');
  }

  const userData = userDoc.data() as User;

  // Ensure role is set for existing users
  if (!userData.user_role) {
    const role = email.toLowerCase() === ADMIN_EMAIL ? 'Admin' : 'Student';
    await updateDoc(doc(db, 'users', firebaseUser.uid), { user_role: role });
    userData.user_role = role;
  }

  return userData;
};

export const signOut = async (): Promise<void> => {
  await firebaseSignOut(auth);
};

export const getCurrentUser = async (
  firebaseUser: FirebaseUser
): Promise<User | null> => {
  const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));

  if (!userDoc.exists()) {
    return null;
  }

  const data = userDoc.data();
  const userData = { ...data, friends: data.friends || [] } as User;

  // Set role if missing (for existing users before role system)
  if (!data.user_role) {
    const email = firebaseUser.email || '';
    const role = email.toLowerCase() === ADMIN_EMAIL ? 'Admin' : 'Student';
    await updateDoc(doc(db, 'users', firebaseUser.uid), { user_role: role });
    userData.user_role = role;
  } else {
    userData.user_role = data.user_role;
  }

  return userData;
};
