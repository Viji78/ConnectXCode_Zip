import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DrawerContentScrollView } from '@react-navigation/drawer';
import { User } from '../types';
import { colors } from '../styles/common';

interface Props {
  navigation: any;
  user: User;
  onLogout: () => void;
}

const menuItems = [
  { label: 'Learn', icon: 'book-outline', screen: 'Home' },
  { label: 'Feed', icon: 'newspaper-outline', screen: 'Feed' },
  { label: 'Create Post', icon: 'add-circle-outline', screen: 'CreatePost' },
  { label: 'Search', icon: 'search-outline', screen: 'Search' },
  { label: 'Messages', icon: 'chatbubble-outline', screen: 'Messages' },
  { label: 'Profile', icon: 'person-outline', screen: 'Profile' },
  { divider: true },
  { label: 'Admin Panel (PDFs)', icon: 'cloud-upload-outline', screen: 'AdminPanel' },
  { label: 'User Management', icon: 'people-outline', screen: 'UserManagement' },
];

export default function AdminDrawerContent({ navigation, user, onLogout, ...props }: Props & any) {
  const handleNavigate = (screen: string) => {
    navigation.closeDrawer();
    // Small delay to let drawer close, then navigate in the nested stack
    setTimeout(() => {
      navigation.navigate('AdminMain', { screen });
    }, 100);
  };
  return (
    <View style={styles.container}>
      {/* Profile Header */}
      <View style={styles.profileSection}>
        {user.profileImage && user.profileImage.length > 2 ? (
          <Image source={{ uri: user.profileImage }} style={styles.avatar} />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarLetter}>{user.username.charAt(0).toUpperCase()}</Text>
          </View>
        )}
        <Text style={styles.username}>{user.username}</Text>
        <View style={styles.adminBadge}>
          <Ionicons name="shield-checkmark" size={12} color={colors.textWhite} />
          <Text style={styles.adminBadgeText}>Admin</Text>
        </View>
        <Text style={styles.email}>{user.email}</Text>
      </View>

      {/* Menu Items */}
      <DrawerContentScrollView style={styles.menuScroll} contentContainerStyle={styles.menuContent}>
        {menuItems.map((item: any, index) => {
          if (item.divider) {
            return <View key={index} style={styles.divider} />;
          }
          return (
            <TouchableOpacity
              key={index}
              style={styles.menuItem}
              onPress={() => handleNavigate(item.screen)}
            >
              <Ionicons name={item.icon} size={22} color={colors.textBody} />
              <Text style={styles.menuLabel}>{item.label}</Text>
            </TouchableOpacity>
          );
        })}
      </DrawerContentScrollView>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutBtn} onPress={onLogout}>
        <Ionicons name="log-out-outline" size={22} color={colors.error} />
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgWhite,
  },
  profileSection: {
    paddingTop: 56,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: colors.bgDark,
    alignItems: 'center',
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: colors.primaryLight,
  },
  avatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarLetter: {
    fontSize: 26,
    fontWeight: 'bold',
    color: colors.textWhite,
  },
  username: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textWhite,
    marginTop: 10,
  },
  adminBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.primary,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 3,
    marginTop: 6,
  },
  adminBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.textWhite,
  },
  email: {
    fontSize: 12,
    color: colors.textWhiteMuted,
    marginTop: 4,
  },
  menuScroll: {
    flex: 1,
  },
  menuContent: {
    paddingTop: 8,
    paddingBottom: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 20,
    paddingVertical: 14,
  },
  menuLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: colors.textDark,
  },
  divider: {
    height: 1,
    backgroundColor: colors.borderLight,
    marginHorizontal: 20,
    marginVertical: 8,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: colors.borderLight,
    marginBottom: 20,
  },
  logoutText: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.error,
  },
});
